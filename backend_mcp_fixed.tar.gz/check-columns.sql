SELECT column_name FROM information_schema.columns WHERE table_name = 'market_monitors';
