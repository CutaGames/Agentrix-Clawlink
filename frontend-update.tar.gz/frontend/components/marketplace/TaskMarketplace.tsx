/**
 * Task Marketplace Component
 * 
 * 任务市场 - 任务浏览、搜索、发布、竞标
 */

import React, { useState, useEffect } from 'react';
import { 
  taskMarketplaceApi, 
  type Task, 
  type TaskBid, 
  type SearchTasksParams,
  type PublishTaskDto,
  type CreateBidDto,
} from '@/services/taskMarketplaceApi';

export const TaskMarketplace: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [showBidModal, setShowBidModal] = useState(false);
  const [filters, setFilters] = useState<SearchTasksParams>({
    page: 1,
    limit: 20,
    sortBy: 'createdAt',
    sortOrder: 'DESC',
  });

  useEffect(() => {
    loadTasks();
  }, [filters]);

  const loadTasks = async () => {
    try {
      setLoading(true);
      const result = await taskMarketplaceApi.searchTasks(filters);
      setTasks(result.tasks);
    } catch (error) {
      console.error('Failed to load tasks:', error);
      alert('加载任务失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-0">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">🎯 任务市场</h1>
            <p className="text-slate-400">发现任务，提交竞标，开启合作</p>
          </div>
          <button
            onClick={() => setShowPublishModal(true)}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-6 py-3 rounded-lg font-medium transition-all"
          >
            ✨ 发布任务
          </button>
        </div>

        {/* Filters */}
        <TaskFilters filters={filters} onFiltersChange={setFilters} />

        {/* Tasks Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
          </div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-slate-400 text-lg">暂无任务</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tasks.map(task => (
              <TaskCard 
                key={task.id} 
                task={task}
                onViewDetails={() => setSelectedTask(task)}
                onBid={() => {
                  setSelectedTask(task);
                  setShowBidModal(true);
                }}
              />
            ))}
          </div>
        )}

        {/* Modals */}
        {showPublishModal && (
          <PublishTaskModal
            onClose={() => setShowPublishModal(false)}
            onSuccess={() => {
              setShowPublishModal(false);
              loadTasks();
            }}
          />
        )}

        {showBidModal && selectedTask && (
          <SubmitBidModal
            task={selectedTask}
            onClose={() => {
              setShowBidModal(false);
              setSelectedTask(null);
            }}
            onSuccess={() => {
              setShowBidModal(false);
              setSelectedTask(null);
              alert('竞标提交成功！');
            }}
          />
        )}

        {selectedTask && !showBidModal && (
          <TaskDetailsModal
            task={selectedTask}
            onClose={() => setSelectedTask(null)}
            onBid={() => {
              setShowBidModal(true);
            }}
          />
        )}
      </div>
    </div>
  );
};

// Task Card Component
const TaskCard: React.FC<{
  task: Task;
  onViewDetails: () => void;
  onBid: () => void;
}> = ({ task, onViewDetails, onBid }) => {
  return (
    <div className="bg-slate-900/60 border border-slate-800/60 rounded-xl p-6 hover:border-blue-500/40 transition-all cursor-pointer">
      <div className="flex items-start justify-between mb-4">
        <span className="px-3 py-1 bg-blue-500/20 text-blue-400 text-sm rounded-full">
          {task.type}
        </span>
        <span className="text-2xl font-bold text-green-400">
          ${task.budget}
        </span>
      </div>

      <h3 className="text-xl font-bold text-white mb-2 line-clamp-2">
        {task.title}
      </h3>

      <p className="text-slate-400 text-sm mb-4 line-clamp-3">
        {task.description}
      </p>

      {task.tags && task.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {task.tags.slice(0, 3).map((tag, index) => (
            <span key={index} className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded">
              #{tag}
            </span>
          ))}
        </div>
      )}

      <div className="flex items-center gap-2">
        <button
          onClick={onViewDetails}
          className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg transition-colors"
        >
          查看详情
        </button>
        <button
          onClick={onBid}
          className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-2 rounded-lg transition-all"
        >
          立即竞标
        </button>
      </div>
    </div>
  );
};

// Filters Component
const TaskFilters: React.FC<{
  filters: SearchTasksParams;
  onFiltersChange: (filters: SearchTasksParams) => void;
}> = ({ filters, onFiltersChange }) => {
  return (
    <div className="bg-slate-900/60 border border-slate-800/60 rounded-xl p-6 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <input
          type="text"
          placeholder="搜索任务..."
          value={filters.query || ''}
          onChange={(e) => onFiltersChange({ ...filters, query: e.target.value, page: 1 })}
          className="bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
        />

        <select
          value={filters.type?.[0] || ''}
          onChange={(e) => onFiltersChange({ ...filters, type: e.target.value ? [e.target.value] : undefined, page: 1 })}
          className="bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
        >
          <option value="">所有类型</option>
          <option value="custom_service">定制服务</option>
          <option value="consultation">咨询</option>
          <option value="design">设计</option>
          <option value="development">开发</option>
          <option value="content">内容创作</option>
          <option value="other">其他</option>
        </select>

        <input
          type="number"
          placeholder="最小预算"
          value={filters.budgetMin || ''}
          onChange={(e) => onFiltersChange({ ...filters, budgetMin: Number(e.target.value) || undefined, page: 1 })}
          className="bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
        />

        <input
          type="number"
          placeholder="最大预算"
          value={filters.budgetMax || ''}
          onChange={(e) => onFiltersChange({ ...filters, budgetMax: Number(e.target.value) || undefined, page: 1 })}
          className="bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
        />
      </div>
    </div>
  );
};

// Publish Task Modal
const PublishTaskModal: React.FC<{
  onClose: () => void;
  onSuccess: () => void;
}> = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState<PublishTaskDto>({
    type: 'custom_service',
    title: '',
    description: '',
    budget: 0,
    currency: 'USD',
    tags: [],
    visibility: 'public',
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      await taskMarketplaceApi.publishTask(formData);
      onSuccess();
    } catch (error) {
      console.error('Failed to publish task:', error);
      alert('发布任务失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">发布任务</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-2xl">
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-slate-300 mb-2">任务类型</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
              required
            >
              <option value="custom_service">定制服务</option>
              <option value="consultation">咨询</option>
              <option value="design">设计</option>
              <option value="development">开发</option>
              <option value="content">内容创作</option>
              <option value="other">其他</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 mb-2">任务标题</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
              placeholder="例如：设计一个现代化的网站首页"
              required
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-2">任务描述</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none min-h-[120px]"
              placeholder="详细描述任务需求、目标和期望..."
              required
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-2">预算（USD）</label>
            <input
              type="number"
              value={formData.budget}
              onChange={(e) => setFormData({ ...formData, budget: Number(e.target.value) })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
              min="0"
              step="0.01"
              required
            />
            {formData.budget > 0 && (
              <div className="mt-2 bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 text-xs">
                <div className="flex justify-between text-slate-400 mb-1">
                  <span>平台佣金 (5%)</span>
                  <span className="text-amber-400">${(formData.budget * 0.05).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-300 font-medium">
                  <span>服务商实际收入</span>
                  <span className="text-green-400">${(formData.budget * 0.95).toFixed(2)}</span>
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block text-slate-300 mb-2">标签（逗号分隔）</label>
            <input
              type="text"
              onChange={(e) => setFormData({ ...formData, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
              placeholder="例如：UI设计, 前端开发, React"
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-3 rounded-lg transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-3 rounded-lg transition-all disabled:opacity-50"
            >
              {submitting ? '发布中...' : '发布任务'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Submit Bid Modal
const SubmitBidModal: React.FC<{
  task: Task;
  onClose: () => void;
  onSuccess: () => void;
}> = ({ task, onClose, onSuccess }) => {
  const [formData, setFormData] = useState<CreateBidDto>({
    proposedBudget: task.budget,
    currency: 'USD',
    estimatedDays: 7,
    proposal: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      await taskMarketplaceApi.submitBid(task.id, formData);
      onSuccess();
    } catch (error) {
      console.error('Failed to submit bid:', error);
      alert('竞标提交失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">提交竞标</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-2xl">
            ×
          </button>
        </div>

        <div className="bg-slate-700/50 rounded-lg p-4 mb-6">
          <h3 className="text-lg font-semibold text-white mb-2">{task.title}</h3>
          <p className="text-slate-400 text-sm">任务预算: ${task.budget}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-slate-300 mb-2">您的报价（USD）</label>
            <input
              type="number"
              value={formData.proposedBudget}
              onChange={(e) => setFormData({ ...formData, proposedBudget: Number(e.target.value) })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
              min="0"
              step="0.01"
              required
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-2">预计完成天数</label>
            <input
              type="number"
              value={formData.estimatedDays}
              onChange={(e) => setFormData({ ...formData, estimatedDays: Number(e.target.value) })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none"
              min="1"
              required
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-2">竞标方案</label>
            <textarea
              value={formData.proposal}
              onChange={(e) => setFormData({ ...formData, proposal: e.target.value })}
              className="w-full bg-slate-800 text-white px-4 py-2 rounded-lg border border-slate-700 focus:border-blue-500 outline-none min-h-[150px]"
              placeholder="详细说明您的实施方案、经验和优势..."
              required
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-3 rounded-lg transition-colors"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-3 rounded-lg transition-all disabled:opacity-50"
            >
              {submitting ? '提交中...' : '提交竞标'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Task Details Modal
const TaskDetailsModal: React.FC<{
  task: Task;
  onClose: () => void;
  onBid: () => void;
}> = ({ task, onClose, onBid }) => {
  const [bids, setBids] = useState<TaskBid[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBids();
  }, [task.id]);

  const loadBids = async () => {
    try {
      setLoading(true);
      const data = await taskMarketplaceApi.getTaskBids(task.id);
      setBids(data);
    } catch (error) {
      console.error('Failed to load bids:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">任务详情</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-2xl">
            ×
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex items-center gap-4 mb-4">
              <span className="px-3 py-1 bg-blue-500/20 text-blue-400 text-sm rounded-full">
                {task.type}
              </span>
              <span className="text-2xl font-bold text-green-400">
                ${task.budget}
              </span>
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">{task.title}</h3>
            <p className="text-slate-300 leading-relaxed">{task.description}</p>
          </div>

          {task.tags && task.tags.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-slate-400 mb-2">标签</h4>
              <div className="flex flex-wrap gap-2">
                {task.tags.map((tag, index) => (
                  <span key={index} className="px-3 py-1 bg-slate-700 text-slate-300 text-sm rounded">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div>
            <h4 className="text-lg font-semibold text-white mb-3">竞标列表 ({bids.length})</h4>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-4 border-blue-500 border-t-transparent mx-auto"></div>
              </div>
            ) : bids.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                暂无竞标
              </div>
            ) : (
              <div className="space-y-3">
                {bids.map(bid => (
                  <div key={bid.id} className="bg-slate-700/50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-lg font-semibold text-white">
                        ${bid.proposedBudget}
                      </span>
                      <span className={`px-3 py-1 text-xs rounded-full ${
                        bid.status === 'ACCEPTED' || bid.status === 'accepted' ? 'bg-green-500/20 text-green-400' :
                        bid.status === 'REJECTED' || bid.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                        'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {bid.status}
                      </span>
                    </div>
                    <p className="text-slate-300 text-sm mb-2">
                      预计 {bid.estimatedDays} 天完成
                    </p>
                    <p className="text-slate-400 text-sm">
                      {bid.proposal}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={onBid}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-3 rounded-lg font-medium transition-all"
          >
            提交竞标
          </button>
        </div>
      </div>
    </div>
  );
};
