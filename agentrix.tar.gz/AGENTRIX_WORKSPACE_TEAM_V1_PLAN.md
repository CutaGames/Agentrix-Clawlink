# Agentrix "1+N" 团队自动化路线图 V1.0

## 1. 愿景
构建一个由 **1名人类 CEO (你)** 和 **N名特种 Agent** 组成的“一人公司”战斗矩阵。利用 Agentrix 原生的 UCP、X402 和 MCP 协议，实现从代码开发、产品出海、商户拓客到财务结算的全流程自动化。

---

## 2. 团队画像 (Agent Personas)

### 🛠️ R&D 小队 (研发与协议)
*   **Architect Agent**: 负责协议升级（ERC-8004/UCP）。
*   **Coder Agent**: 专注于 `frontend/` 和 `backend/` 的 Feature 开发、Bug 修复。
*   **QA Agent**: 24/7 运行测试套件，执行 E2E 验证。

### 📈 Growth 小队 (市场与流量)
*   **Marketing Agent**: 负责多社媒（X, Discord）内容分发，监控行业动态并自动跟进。
*   **DevRel Agent**: 维护开发者文档，解答 Issue，推广 SDK。

### 🛒 Ecosystem 小队 (商务与拓展)
*   **BD Agent**: 扫描全球 API/商户，主动发送招商信。
*   **Merchant Support**: 协助商户完成 KYC 并上架商品。

### 💰 Finance 小队 (财务与安全)
*   **CFO Agent**: 管理各 Agent 的 `spendingLimit`，执行分成清算。
*   **Compliance Agent**: 实时风控，信用评分动态调整。

---

## 3. 基础设施要求 (Infrastructure)

### Workspace 层
- 统一的 `Agentrix_Global_HQ` 工作空间。
- 独立的沙盒环境与生产环境隔离。

### 账户层
- 所有的 Agent 均持有独立的 `AgentAccount`。
- 绑定 `VIRTUAL` 或 `CUSTODIAL` 钱包以执行 M2M 支付。

### 协议层
- **MCP Server**: 作为团队的“指挥塔”，所有 Agent 通过 MCP 注册。
- **SSE Transport**: 保持长连接，实现秒级任务分发。

---

## 4. 实施阶段 (Execution Phases)

### Phase 1: 基础设施初始化 (当前阶段)
- [ ] 创建 HQ 工作空间。
- [ ] 初始化 4 个核心小队领袖 Agent 的账号。
- [ ] 分配初始运营资金 (Mock USDC)。

### Phase 2: 任务流自动化
- [ ] 建立基于 GitHub Action 和 MCP 的指令系统。
- [ ] 实现“CEO 阅读 PRD -> Architect 拆解任务 -> Coder 编写代码”的闭环。

### Phase 3: 商业闭环落地
- [ ] 开启 BD Agent 自动拓客。
- [ ] 开启 Marketing Agent 自动发帖。

---

## 5. 立即行动
运行任务：`npm run script:setup-team` (即将安装)
