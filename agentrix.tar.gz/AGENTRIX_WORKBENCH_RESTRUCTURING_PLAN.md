# Agentrix Workbench 重构方案

## 一、重构背景与目标

### 1.1 核心变更驱动
基于账户体系优化和五大用户画像，工作台需要进行以下核心重构：

| 变更项 | 当前状态 | 目标状态 |
|--------|----------|----------|
| 角色模式 | 3种 (Personal/Merchant/Developer) | 5种用户画像 + 统一入口 |
| 账户体系 | User 单一实体 | User + AgentAccount + Account + DeveloperAccount |
| 资金管理 | 分散在各模块 | 统一资金账户 (Account) |
| KYC认证 | 简单状态字段 | 完整 KYCRecord 系统 |
| 工作空间 | 无 | Workspace 多租户支持 |
| 授权体系 | Authorization 分离 | 统一授权 + AutoPay 集成 |

### 1.2 五大用户画像映射

| 用户画像 | 原角色映射 | 工作台入口 | 核心功能模块 |
|----------|-----------|-----------|-------------|
| **API 厂商** | Developer | 开发者控制台 | OpenAPI导入、技能封装、API管理 |
| **实物/服务商** | Merchant | 商户控制台 | 商品同步、订单管理、UCP协议 |
| **行业专家** | Developer/Merchant | 专家控制台 | 能力卡、SLA配置、咨询定价 |
| **数据持有方** | Developer | 数据控制台 | 数据接入、RAG索引、X402计费 |
| **全能开发者** | Developer | 开发者控制台 | Skill工厂、工作流编排、多平台分发 |

---

## 二、UI 架构重构方案

### 2.1 新版导航层级设计

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         L0: 全局顶栏 (GlobalHeader)                          │
│  ┌─────────┐  ┌──────────────────────────────────────┐  ┌───────────────┐  │
│  │ Agentrix│  │ 🔍 全局搜索 / AI 指令输入             │  │ 通知 设置 头像│  │
│  └─────────┘  └──────────────────────────────────────┘  └───────────────┘  │
├─────────────────────────────────────────────────────────────────────────────┤
│ L1: 角色/画像切换栏 (带环境色调)                                              │
│ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐         │
│ │ 个人版 │ │API厂商 │ │ 商户版 │ │ 专家版 │ │数据提供│ │开发者版│         │
│ │ 🔵蓝   │ │ 🟣紫   │ │ 🟢绿   │ │ 🟡黄   │ │ 🟠橙   │ │ ⚫灰   │         │
│ └────────┘ └────────┘ └────────┘ └────────┘ └────────┘ └────────┘         │
├─────────────────────────────────────────────────────────────────────────────┤
│        L2: 左侧功能导航              │        L3: 主内容区                   │
│ ┌──────────────────────┐            │ ┌─────────────────────────────────┐  │
│ │ 📊 控制台            │            │ │                                 │  │
│ │ 💰 统一资金账户       │ ◀── NEW   │ │     根据L1+L2动态渲染内容        │  │
│ │ 🤖 Agent账户管理     │ ◀── NEW   │ │                                 │  │
│ │ 📋 KYC认证中心       │ ◀── NEW   │ │                                 │  │
│ │ 👥 工作空间          │ ◀── NEW   │ │                                 │  │
│ │ ⚡ 技能/商品管理      │            │ │                                 │  │
│ │ 📦 订单/交易         │            │ │                                 │  │
│ │ 🔐 授权与安全        │            │ │                                 │  │
│ │ ⚙️ 设置             │            │ │                                 │  │
│ └──────────────────────┘            │ └─────────────────────────────────┘  │
├─────────────────────────────────────┴───────────────────────────────────────┤
│                   R1: AI 助手侧边栏 (UI控制器模式)                           │
│         支持语音指令控制L3内容区，如"帮我调高API限额"自动高亮对应面板         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.1.1 画像环境色调配置

```typescript
// 每个画像的主题色配置
export const personaThemes: Record<UserPersona, PersonaTheme> = {
  personal: {
    primary: '#3B82F6',      // 蓝色 - 信任、安全
    secondary: '#60A5FA',
    accent: '#2563EB',
    gradient: 'from-blue-500 to-blue-600',
    icon: 'user',
    label: { zh: '个人版', en: 'Personal' },
  },
  api_provider: {
    primary: '#8B5CF6',      // 紫色 - 极客、技术
    secondary: '#A78BFA',
    accent: '#7C3AED',
    gradient: 'from-purple-500 to-purple-600',
    icon: 'code',
    label: { zh: 'API厂商', en: 'API Provider' },
  },
  merchant: {
    primary: '#10B981',      // 绿色 - 商务、金钱
    secondary: '#34D399',
    accent: '#059669',
    gradient: 'from-emerald-500 to-emerald-600',
    icon: 'store',
    label: { zh: '商户版', en: 'Merchant' },
  },
  expert: {
    primary: '#F59E0B',      // 黄色 - 学院、专业
    secondary: '#FBBF24',
    accent: '#D97706',
    gradient: 'from-amber-500 to-amber-600',
    icon: 'graduation-cap',
    label: { zh: '专家版', en: 'Expert' },
  },
  data_provider: {
    primary: '#F97316',      // 橙色 - 数据、价值
    secondary: '#FB923C',
    accent: '#EA580C',
    gradient: 'from-orange-500 to-orange-600',
    icon: 'database',
    label: { zh: '数据提供', en: 'Data Provider' },
  },
  developer: {
    primary: '#6B7280',      // 灰色 - 极客、代码
    secondary: '#9CA3AF',
    accent: '#4B5563',
    gradient: 'from-gray-500 to-gray-600',
    icon: 'terminal',
    label: { zh: '开发者版', en: 'Developer' },
  },
};
```

### 2.1.2 移动端适配策略

```
┌─────────────────────────────────────┐
│ 移动端布局 (< 768px)                │
├─────────────────────────────────────┤
│ ┌─────────────────────────────────┐ │
│ │  L0: 顶栏 (Logo + 搜索 + 头像)  │ │
│ └─────────────────────────────────┘ │
│ ┌─────────────────────────────────┐ │
│ │  L2: 下拉菜单 (点击展开)        │ │
│ │  ▼ 控制台 > 总览                │ │
│ └─────────────────────────────────┘ │
│ ┌─────────────────────────────────┐ │
│ │                                 │ │
│ │                                 │ │
│ │        L3: 主内容区             │ │
│ │        (全屏宽度)               │ │
│ │                                 │ │
│ │                                 │ │
│ └─────────────────────────────────┘ │
│ ┌─────────────────────────────────┐ │
│ │ 🏠    🤖    💰    ⚙️    🎭      │ │
│ │ 首页  Agent 资金  设置  切换画像 │ │
│ │       L1: 底部 Tab Bar          │ │
│ └─────────────────────────────────┘ │
│ ┌─────────────────────────────────┐ │
│ │  💬 AI助手 (浮动按钮展开)       │ │
│ └─────────────────────────────────┘ │
└─────────────────────────────────────┘

移动端交互规则:
1. L1 画像切换 → 底部 Tab Bar 最右侧按钮，点击弹出画像选择器
2. L2 功能导航 → 顶部下拉菜单，显示当前位置面包屑
3. R1 AI助手 → 右下角浮动按钮，点击全屏展开
4. 手势支持:
   - 左滑返回上一级
   - 下拉刷新
   - 长按快捷操作
```

```typescript
// 移动端导航配置
export const mobileNavConfig = {
  // 底部 Tab Bar 配置
  bottomTabs: [
    { id: 'dashboard', icon: Home, label: { zh: '首页', en: 'Home' } },
    { id: 'agent-accounts', icon: Bot, label: { zh: 'Agent', en: 'Agent' } },
    { id: 'unified-account', icon: Wallet, label: { zh: '资金', en: 'Funds' } },
    { id: 'settings', icon: Settings, label: { zh: '设置', en: 'Settings' } },
    { id: 'persona-switch', icon: Users, label: { zh: '切换', en: 'Switch' } },
  ],
  
  // L2 下拉菜单层级
  dropdownBreadcrumb: true,
  dropdownMaxHeight: '60vh',
  
  // AI 助手浮动按钮
  floatingAssistant: {
    position: 'bottom-right',
    offset: { bottom: 80, right: 16 },
    expandMode: 'fullscreen',
  },
};
```

### 2.2 各画像专属导航配置

#### 2.2.1 个人版 (Personal) - 消费者视角
```typescript
const personalL2Config = {
  dashboard: ['overview', 'activity', 'recommendations'],
  'unified-account': ['balances', 'transactions', 'deposit', 'withdraw'],  // NEW
  'agent-accounts': ['my-agents', 'authorizations', 'auto-pay'],           // NEW
  kyc: ['status', 'submit', 'documents'],                                   // NEW
  workspace: ['my-spaces', 'joined', 'invitations'],                        // NEW
  skills: ['installed', 'marketplace', 'configure'],
  shopping: ['orders', 'cart', 'wishlist'],
  security: ['sessions', 'policies', 'audit-log'],
  settings: ['profile', 'notifications', 'preferences'],
};
```

#### 2.2.2 API 厂商版 (API Provider)
```typescript
const apiProviderL2Config = {
  dashboard: ['overview', 'api-calls', 'revenue'],
  'developer-account': ['profile', 'tier', 'api-keys', 'rate-limits'],     // NEW
  'unified-account': ['balances', 'earnings', 'payouts'],                   // NEW
  skills: ['my-apis', 'import-openapi', 'auto-generate'],
  testing: ['sandbox', 'mock-scenarios', 'debug-console'],
  publish: ['marketplace', 'multi-platform', 'distribution'],
  analytics: ['usage', 'performance', 'errors'],
  settings: ['webhooks', 'oauth-apps', 'team'],
};
```

#### 2.2.3 实物/服务商版 (Merchant)
```typescript
const merchantL2Config = {
  dashboard: ['overview', 'gmv', 'ai-traffic'],
  'merchant-account': ['profile', 'verification', 'settlement'],           // NEW
  'unified-account': ['balances', 'transactions', 'withdrawals'],          // NEW
  products: ['list', 'add', 'batch-import', 'ecommerce-sync', 'as-skills'],
  orders: ['all', 'pending', 'shipping', 'completed', 'refunds'],
  fulfillment: ['ucp-config', 'logistics', 'inventory'],                   // NEW
  analytics: ['sales', 'customers', 'products', 'agents'],
  settings: ['store-info', 'api-keys', 'webhooks', 'team'],
};
```

#### 2.2.4 行业专家版 (Expert)
```typescript
const expertL2Config = {
  dashboard: ['overview', 'consultations', 'earnings'],
  'expert-profile': ['capability-card', 'credentials', 'sla-config'],      // NEW
  'unified-account': ['balances', 'earnings', 'payouts'],                   // NEW
  services: ['my-services', 'create', 'pricing', 'templates'],             // NEW
  consultations: ['pending', 'in-progress', 'completed', 'disputes'],      // NEW
  analytics: ['performance', 'ratings', 'response-time'],
  settings: ['availability', 'notifications', 'team'],
};
```

#### 2.2.5 数据提供方版 (Data Provider)
```typescript
const dataProviderL2Config = {
  dashboard: ['overview', 'queries', 'revenue'],
  'developer-account': ['profile', 'tier', 'api-keys'],                    // NEW
  'unified-account': ['balances', 'earnings', 'payouts'],                   // NEW
  datasets: ['my-data', 'import', 'vectorize', 'schema'],                  // NEW
  access: ['permissions', 'anonymization', 'rate-limits'],                 // NEW
  billing: ['x402-config', 'per-query', 'subscriptions'],                  // NEW
  analytics: ['usage', 'popular-queries', 'clients'],
  settings: ['api-keys', 'webhooks', 'security'],
};
```

#### 2.2.6 全能开发者版 (Developer)
```typescript
const developerL2Config = {
  dashboard: ['overview', 'api-calls', 'revenue', 'agents'],
  'developer-account': ['profile', 'tier', 'agreement', 'api-keys'],       // NEW
  'unified-account': ['balances', 'earnings', 'payouts'],                   // NEW
  build: ['skill-factory', 'registry', 'packs', 'sandbox'],
  publish: ['marketplace', 'multi-platform', 'distribution'],
  revenue: ['earnings', 'transactions', 'pricing', 'withdrawals'],
  workspace: ['my-spaces', 'team', 'permissions'],                         // NEW
  docs: ['api-reference', 'sdk-guides', 'examples', 'changelog'],
  settings: ['webhooks', 'oauth', 'mcp-config'],
};
```

### 2.3 新增核心 UI 组件

#### 2.3.1 统一资金账户模块 (UnifiedAccountModule)
```
┌─────────────────────────────────────────────────────────────────┐
│ 统一资金账户                                          + 新建账户 │
├─────────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ 💰 待结算收益: $1,234.00                    ⏰ 3天后到账   ││
│ │ ████████████████░░░░ 周期进度 75%          [查看明细]      ││
│ └─────────────────────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────────┤
│ ┌───────────────┐ ┌───────────────┐ ┌───────────────┐          │
│ │ 主账户 (托管)  │ │ Agent专属账户 │ │ 收益结算账户  │          │
│ │ ──────────── │ │ ──────────── │ │ ──────────── │          │
│ │ $1,234.56    │ │ $456.78      │ │ $789.00      │          │
│ │ 🔷 USDC/Base │ │ 🟣 USDC/BNB  │ │ 💵 USD       │          │
│ │ ┌──────────┐ │ │ ┌──────────┐ │ │ ┌──────────┐ │          │
│ │ │ 充值 提现│ │ │ │ 转入 转出│ │ │ │ 提现     │ │          │
│ │ └──────────┘ │ │ └──────────┘ │ │ └──────────┘ │          │
│ └───────────────┘ └───────────────┘ └───────────────┘          │
│  多链状态: 🔷Base(快) 🟣BNB(中) 🟠Solana(快) 显示到账速度       │
├─────────────────────────────────────────────────────────────────┤
│ 最近交易记录                                                    │
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ ↓ Agent购买技能    -$12.00   2026-01-18 09:30  主账户 🔷   ││
│ │ ↑ 技能调用收益     +$45.00   2026-01-18 08:15  收益账户    ││
│ │ ↔ 账户间转账       $100.00   2026-01-17 18:00  主→Agent    ││
│ └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

**新增组件**:
- `PendingEarningsCountdown`: B端用户待结算收益倒计时，提升回访率
- `ChainStatusIndicator`: 多链状态图标，显示资金所在链和到账速度

#### 2.3.2 Agent 账户管理模块 (AgentAccountModule)
```
┌─────────────────────────────────────────────────────────────────┐
│ 我的 Agent 账户                                    + 创建Agent  │
├─────────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ 🤖 Shopping Assistant                            [活跃]     ││
│ │ ────────────────────────────────────────────────────────── ││
│ │ Agent ID: AGT-2026-xxxx      类型: 个人Agent                ││
│ │ 信用评分: 850/1000           风险等级: 低                   ││
│ │ ┌──────────────────────────────────────────────────────┐   ││
│ │ │ 支出限额                                              │   ││
│ │ │ 单笔: $100  │  日限: $500  │  月限: $2,000            │   ││
│ │ │ ████████░░░░ 45% 今日已用                             │   ││
│ │ └──────────────────────────────────────────────────────┘   ││
│ │ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐           ││
│ │ │ 授权管理│ │ 交易记录│ │ 限额设置│ │ 暂停/恢复│           ││
│ │ └─────────┘ └─────────┘ └─────────┘ └─────────┘           ││
│ └─────────────────────────────────────────────────────────────┘│
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ 🤖 Data Analyst Agent                            [暂停]     ││
│ │ ...                                                         ││
│ └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

#### 2.3.3 KYC 认证中心 (KYCCenterModule)
```
┌─────────────────────────────────────────────────────────────────┐
│ KYC 认证中心                                                    │
├─────────────────────────────────────────────────────────────────┤
│ 当前认证等级                                                    │
│ ┌─────────────────────────────────────────────────────────────┐│
│ │  ✓ 基础     ✓ 标准     ○ 高级      ○ 企业                   ││
│ │  BASIC     STANDARD   ADVANCED    ENTERPRISE               ││
│ │  ═══════════════●════════════════════════════              ││
│ └─────────────────────────────────────────────────────────────┘│
│                                                                 │
│ 等级权益对比                                                    │
│ ┌─────────┬───────────┬───────────┬───────────┬───────────┐   │
│ │ 权益    │ 基础      │ 标准      │ 高级      │ 企业      │   │
│ ├─────────┼───────────┼───────────┼───────────┼───────────┤   │
│ │日交易额 │ $1,000    │ $10,000   │ $100,000  │ 无限      │   │
│ │提现限额 │ $500/日   │ $5,000/日 │ $50,000/日│ 无限      │   │
│ │API调用  │ 1000/日   │ 10000/日  │ 100000/日 │ 无限      │   │
│ └─────────┴───────────┴───────────┴───────────┴───────────┘   │
│                                                                 │
│ ┌───────────────────────────────────────────────────────────┐ │
│ │                    [升级到高级认证]                        │ │
│ └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

#### 2.3.4 工作空间管理 (WorkspaceManagerModule)
```
┌─────────────────────────────────────────────────────────────────┐
│ 工作空间                                          + 创建空间    │
├─────────────────────────────────────────────────────────────────┤
│ 我的工作空间                                                    │
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ 🏠 个人空间 (Personal)                          [默认]      ││
│ │ ────────────────────────────────────────────────────────── ││
│ │ 成员: 仅自己  │  Agent: 3个  │  技能: 12个                  ││
│ └─────────────────────────────────────────────────────────────┘│
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ 🏢 AI Studio Team (Team)                       [Owner]      ││
│ │ ────────────────────────────────────────────────────────── ││
│ │ 成员: 5人     │  Agent: 8个  │  技能: 45个                  ││
│ │ ┌─────────┐ ┌─────────┐ ┌─────────┐                        ││
│ │ │ 成员管理│ │ 权限设置│ │ 切换空间│                        ││
│ │ └─────────┘ └─────────┘ └─────────┘                        ││
│ └─────────────────────────────────────────────────────────────┘│
│                                                                 │
│ 邀请加入                                                        │
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ 📩 来自 "Enterprise Corp" 的邀请     [接受] [拒绝]          ││
│ └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

#### 2.3.5 开发者账户模块 (DeveloperAccountModule)
```
┌─────────────────────────────────────────────────────────────────┐
│ 开发者账户                                                      │
├─────────────────────────────────────────────────────────────────┤
│ ┌───────────────────────────────────────────────────────────┐ │
│ │ 开发者 ID: DEV-2026-xxxx                                   │ │
│ │ 等级: Professional           状态: ✓ Active               │ │
│ │ ════════════════════════════════════════════════════════ │ │
│ │                                                            │ │
│ │ ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │ │
│ │ │ API Keys     │  │ 速率限制     │  │ 收益分成     │     │ │
│ │ │ 5/10 已用    │  │ 500 req/min  │  │ 75%          │     │ │
│ │ └──────────────┘  └──────────────┘  └──────────────┘     │ │
│ │                                                            │ │
│ │ API 调用统计                                               │ │
│ │ 今日: 12,450    本月: 345,678    累计: 2,456,789          │ │
│ │ ▁▂▃▅▇█▇▅▃▂▁▂▃▅▇█▇▅▃▂▁ (24h趋势)                         │ │
│ └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│ 开发者协议                                                      │
│ ┌───────────────────────────────────────────────────────────┐ │
│ │ ✓ 开发者服务协议 (2026-01-15 签署)                         │ │
│ │ ✓ 数据处理协议 (2026-01-15 签署)                           │ │
│ │ ○ 企业级 SLA 协议 (升级至 Enterprise 可签署)               │ │
│ └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│ ┌───────────────────────────────────────────────────────────┐ │
│ │                    [升级到 Enterprise]                     │ │
│ └───────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### 2.4 用户入驻流程 UI (Onboarding Wizard)

```
┌─────────────────────────────────────────────────────────────────┐
│                    欢迎加入 Agentrix 生态                        │
│                                                                 │
│              您是哪类生态参与者？                                │
│                                                                 │
│ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐       │
│ │   🔌       │ │   🏪       │ │   🎓       │ │   📊       │       │
│ │ API 厂商  │ │ 实物/服务 │ │ 行业专家  │ │ 数据提供  │       │
│ │           │ │ 商家      │ │ 顾问      │ │ 方        │       │
│ │ 将API转为 │ │ 商品即技能│ │ 知识资产化│ │ 数据即门票│       │
│ │ Agent技能 │ │ 零门槛入驻│ │ 专业变现  │ │ 查询即付费│       │
│ └───────────┘ └───────────┘ └───────────┘ └───────────┘       │
│                                                                 │
│ ┌───────────────────────────────────────────────────────────┐ │
│ │   💻 全能 AI 开发者                                        │ │
│ │   从技能创建到全球分发，Agentrix 解决底层支付与合规        │ │
│ └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│              我只是想使用 Agent 服务 → [个人用户入口]           │
└─────────────────────────────────────────────────────────────────┘
```

#### 2.4.1 API 厂商入驻 (极简黑客风格)
```
┌─────────────────────────────────────────────────────────────────┐
│                     🔌 API 厂商快速入驻                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                                                         │   │
│  │   📎 粘贴你的 Swagger / OpenAPI URL                     │   │
│  │                                                         │   │
│  │   https://api.example.com/openapi.json                  │   │
│  │   ─────────────────────────────────────────────────     │   │
│  │                                                         │   │
│  │   或拖拽 openapi.yaml / swagger.json 文件到此处          │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                      [🚀 开始解析]                              │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│  AI 解析中...                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░ 45%                               │   │
│  │ >>> 发现 12 个 API 端点                                 │   │
│  │ >>> 识别参数类型...                                     │   │
│  │ >>> 生成 Skill Schema...                                │   │
│  │ >>> 分析定价建议...                                     │   │
│  └─────────────────────────────────────────────────────────┘   │
│  (黑客帝国风格代码流动效果)                                      │
└─────────────────────────────────────────────────────────────────┘
```

#### 2.4.2 专家版入驻 (能力卡片构建器)
```
┌─────────────────────────────────────────────────────────────────┐
│                   🎓 专家能力卡片构建器                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  我能解决什么问题？(勾选或自定义)                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ☑️ 法律合规审查    ☑️ 合同条款分析    ☐ 知识产权咨询    │   │
│  │ ☐ 税务筹划        ☐ 企业尽调        ☑️ 争议解决方案    │   │
│  │ + 自定义: [跨境电商合规_______________]                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  我需要用户提供什么？                                            │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ ☑️ 合同文本       ☑️ 公司背景       ☐ 财务报表          │   │
│  │ ☐ 技术文档        ☑️ 具体问题描述                        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  AI 自动生成的能力描述:                                          │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ "资深法律顾问，专注于法律合规审查、合同条款分析及争议    │   │
│  │  解决方案。擅长跨境电商合规领域，可根据用户提供的合同    │   │
│  │  文本和公司背景，出具专业的法律意见书。"                 │   │
│  │                                      [✏️ 编辑] [✓ 确认] │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  定价配置:                                                      │
│  ○ 按次: $____/次   ● 按小时: $150/时   ○ 按结果(X402): $___  │
│                                                                 │
│                    [预览能力卡片] [发布到市场]                   │
└─────────────────────────────────────────────────────────────────┘
```

#### 2.4.3 入驻进度草稿箱 (支持中断续做)
```typescript
// 入驻进度持久化
interface OnboardingDraft {
  id: string;
  userId: string;
  persona: UserPersona;
  
  // 进度追踪
  currentStep: number;
  totalSteps: number;
  
  // 各步骤数据
  stepData: Record<string, any>;
  
  // AI 辅助记录
  aiAssistHistory: Array<{
    stepId: string;
    input: string;
    suggestion: string;
    accepted: boolean;
    timestamp: Date;
  }>;
  
  // 待处理事项
  pendingTasks: Array<{
    type: 'document_upload' | 'verification' | 'review';
    description: string;
    required: boolean;
  }>;
  
  lastActiveAt: Date;
  createdAt: Date;
}

// UI 展示
const OnboardingResumeBanner = () => (
  <div className="bg-amber-50 border-l-4 border-amber-400 p-4">
    <div className="flex items-center">
      <Clock className="h-5 w-5 text-amber-400" />
      <div className="ml-3">
        <p className="text-sm text-amber-700">
          您有一个未完成的入驻流程 (专家版 - 步骤 3/5)
        </p>
        <p className="text-xs text-amber-600 mt-1">
          上次 AI 帮您生成了能力描述，点击继续完成定价配置
        </p>
      </div>
      <Button variant="outline" className="ml-auto">
        继续入驻
      </Button>
    </div>
  </div>
);
```

### 2.5 AI 助手深度集成 (R1 UI控制器模式)

```typescript
// AI 助手不仅是聊天框，而是 UI 控制器
interface AIAssistantCommand {
  // 用户输入
  input: string;
  
  // AI 解析的意图
  intent: {
    action: 'navigate' | 'modify' | 'query' | 'create' | 'delete';
    target: string;           // 目标组件/面板
    params?: Record<string, any>;
  };
  
  // UI 响应
  uiResponse: {
    highlightPanel?: string;  // 高亮的面板
    scrollTo?: string;        // 滚动到的元素
    openModal?: string;       // 打开的模态框
    prefillData?: any;        // 预填充的数据
    autoExecute?: boolean;    // 是否自动执行
  };
}

// 示例指令映射
const commandExamples = [
  {
    input: "帮我把翻译 API 的限额调高到 1000",
    intent: { action: 'modify', target: 'RateLimitPanel', params: { limit: 1000 } },
    uiResponse: { highlightPanel: 'rate-limit-config', prefillData: { newLimit: 1000 } },
  },
  {
    input: "我想看看这个月的收益",
    intent: { action: 'navigate', target: 'unified-account', params: { tab: 'earnings' } },
    uiResponse: { scrollTo: 'earnings-chart' },
  },
  {
    input: "创建一个新的 Agent",
    intent: { action: 'create', target: 'agent-account' },
    uiResponse: { openModal: 'CreateAgentModal' },
  },
];
```

```
┌─────────────────────────────────────────────────────────────────┐
│  💬 AI 助手                                              [—] [×]│
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  👤 帮我把翻译 API 的限额调高                                    │
│                                                                 │
│  🤖 好的，我找到了「翻译API」的速率限制配置。                    │
│     当前限制: 500 次/分钟                                        │
│                                                                 │
│     ┌─────────────────────────────────────────────────────┐    │
│     │ 📍 已定位到面板，左侧内容区已高亮                    │    │
│     │    您想调整到多少？                                  │    │
│     │    ○ 1000/分  ○ 2000/分  ○ 自定义: [____]          │    │
│     │    [应用更改]                                        │    │
│     └─────────────────────────────────────────────────────┘    │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 输入指令或问题...                            🎤  📎  ⏎ │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 三、后端开发方案

### 3.1 已有模块 (需集成/增强)

| 模块 | 状态 | 集成点 |
|------|------|--------|
| `AgentAccountModule` | ✅ 已完成 | 需集成到前端 AgentAccountModule UI |
| `AccountModule` | ✅ 已完成 | 需集成到前端 UnifiedAccountModule UI |
| `KYCModule` | ✅ 已完成 | 需集成到前端 KYCCenterModule UI |
| `DeveloperAccountModule` | ✅ 已完成 | 需集成到前端 DeveloperAccountModule UI |
| `WorkspaceModule` | ✅ 已完成 | 需集成到前端 WorkspaceManagerModule UI |
| `AuthorizationModule` | ✅ 已增强 | AutoPay 已合并，需前端适配 |

### 3.2 需要新增的后端模块

#### 3.2.1 ExpertProfileModule (行业专家画像)
```typescript
// backend/src/modules/expert-profile/

// 实体
export interface ExpertProfile {
  id: string;
  userId: string;
  
  // 能力卡
  capabilityCard: {
    title: string;
    problemsSolved: string[];      // "我能解决什么问题"
    requiredInputs: string[];      // "我需要用户提供什么"
    outputFormats: string[];       // 输出模板 (PDF/报告等)
  };
  
  // 资质认证
  credentials: {
    type: string;                  // 律师/审计师/分析师
    licenseNumber?: string;
    verifiedAt?: Date;
    documents: string[];
  }[];
  
  // SLA 配置
  slaConfig: {
    responseTimeHours: number;     // 响应时间承诺
    accuracyThreshold: number;     // 准确率阈值
    refundPolicy: string;
  };
  
  // 定价
  pricing: {
    mode: 'per_call' | 'per_result' | 'subscription';
    basePrice: number;
    currency: string;
  };
  
  status: 'pending' | 'active' | 'suspended';
  createdAt: Date;
  updatedAt: Date;
}

// API 端点
POST   /api/expert-profiles           // 创建专家档案
GET    /api/expert-profiles/my        // 获取我的专家档案
PUT    /api/expert-profiles/:id       // 更新专家档案
POST   /api/expert-profiles/:id/verify-credential  // 验证资质
```

#### 3.2.2 DatasetModule (数据集管理)
```typescript
// backend/src/modules/dataset/

export interface Dataset {
  id: string;
  ownerId: string;
  
  // 基本信息
  name: string;
  description: string;
  category: string;
  
  // 数据源
  source: {
    type: 'upload' | 'database' | 'api' | 'google_sheet';
    config: Record<string, any>;
    lastSyncAt?: Date;
  };
  
  // 向量化配置
  vectorization: {
    enabled: boolean;
    model: string;
    dimensions: number;
    indexedAt?: Date;
  };
  
  // 字段配置
  schema: {
    fields: Array<{
      name: string;
      type: string;
      sensitive: boolean;     // 敏感字段
      anonymize: boolean;     // 脱敏
    }>;
  };
  
  // 访问控制
  accessControl: {
    summaryOnly: boolean;     // 仅返回摘要
    rateLimit: number;        // 每分钟查询限制
    allowedAgents: string[];  // 允许的 Agent ID
  };
  
  // X402 计费
  billing: {
    mode: 'per_query' | 'per_row' | 'subscription';
    pricePerUnit: number;
    currency: string;
  };
  
  status: 'draft' | 'indexing' | 'active' | 'suspended';
}

// API 端点
POST   /api/datasets                   // 创建数据集
GET    /api/datasets/my                // 获取我的数据集
PUT    /api/datasets/:id               // 更新数据集
POST   /api/datasets/:id/sync          // 同步数据源
POST   /api/datasets/:id/vectorize     // 触发向量化
GET    /api/datasets/:id/query         // 查询数据 (X402计费)
```

#### 3.2.3 ConsultationModule (咨询服务)
```typescript
// backend/src/modules/consultation/

export interface Consultation {
  id: string;
  expertId: string;
  clientId: string;
  agentId?: string;           // 发起咨询的 Agent
  
  // 咨询内容
  request: {
    type: string;
    description: string;
    attachments: string[];
  };
  
  // 状态流转
  status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'disputed' | 'refunded';
  
  // 交付物
  deliverable?: {
    format: string;           // PDF/报告/视频
    url: string;
    deliveredAt: Date;
  };
  
  // 支付
  payment: {
    amount: number;
    currency: string;
    status: 'pending' | 'escrowed' | 'released' | 'refunded';
    transactionId?: string;
  };
  
  // 评价
  rating?: {
    score: number;
    comment: string;
    ratedAt: Date;
  };
  
  createdAt: Date;
  updatedAt: Date;
}
```

#### 3.2.4 OnboardingModule (入驻引擎)
```typescript
// backend/src/modules/onboarding/

export interface OnboardingSession {
  id: string;
  userId: string;
  persona: 'api_provider' | 'merchant' | 'expert' | 'data_provider' | 'developer';
  
  // 步骤状态
  steps: Array<{
    id: string;
    name: string;
    status: 'pending' | 'in_progress' | 'completed' | 'skipped';
    data?: Record<string, any>;
    completedAt?: Date;
  }>;
  
  // AI 辅助
  aiAssist: {
    documentsAnalyzed: string[];
    generatedSkills: string[];
    suggestedPricing?: {
      mode: string;
      price: number;
      reasoning: string;
    };
  };
  
  completedAt?: Date;
  createdAt: Date;
}

// API 端点
POST   /api/onboarding/start           // 开始入驻流程
GET    /api/onboarding/my              // 获取当前入驻状态
PUT    /api/onboarding/:id/step/:stepId // 更新步骤
POST   /api/onboarding/:id/analyze     // AI 分析文档
POST   /api/onboarding/:id/complete    // 完成入驻
```

### 3.3 现有模块增强

#### 3.3.1 UserModule 增强
```typescript
// 新增字段到 User 实体
interface UserEnhancement {
  // 画像标识
  personas: Array<'personal' | 'api_provider' | 'merchant' | 'expert' | 'data_provider' | 'developer'>;
  primaryPersona: string;
  
  // 关联账户
  defaultAccountId?: string;        // 默认资金账户
  developerAccountId?: string;      // 开发者账户
  expertProfileId?: string;         // 专家档案
  
  // 状态增强 (已有)
  status: UserStatus;
  statusReason?: string;
  statusUpdatedAt?: Date;
  lastActiveAt?: Date;
}
```

#### 3.3.2 SkillModule 增强
```typescript
// 支持更多技能来源
interface SkillEnhancement {
  // 来源类型
  sourceType: 'manual' | 'openapi_import' | 'product_as_skill' | 'expert_service' | 'dataset_query';
  
  // 原始来源
  sourceRef?: {
    type: string;
    id: string;
    syncedAt?: Date;
  };
  
  // 计费配置 (X402)
  billing: {
    mode: 'free' | 'one_time' | 'per_use' | 'metered' | 'subscription';
    price?: number;
    pricingUnit?: string;
    revenueShare?: number;    // 平台分成比例
  };
}
```

---

## 四、前端开发方案

### 4.1 新增组件清单

| 组件路径 | 描述 | 优先级 |
|----------|------|--------|
| `components/account/UnifiedAccountPanel.tsx` | 统一资金账户面板 | P0 |
| `components/account/AccountCard.tsx` | 账户卡片 | P0 |
| `components/account/TransactionHistory.tsx` | 交易历史 | P0 |
| `components/account/DepositWithdrawModal.tsx` | 充值提现模态框 | P0 |
| `components/agent-account/AgentAccountPanel.tsx` | Agent账户面板 | P0 |
| `components/agent-account/AgentAccountCard.tsx` | Agent账户卡片 | P0 |
| `components/agent-account/SpendingLimitConfig.tsx` | 支出限额配置 | P0 |
| `components/agent-account/CreditScoreDisplay.tsx` | 信用评分展示 | P1 |
| `components/kyc/KYCCenterPanel.tsx` | KYC认证中心 | P0 |
| `components/kyc/KYCLevelCard.tsx` | KYC等级卡片 | P0 |
| `components/kyc/KYCUpgradeWizard.tsx` | KYC升级向导 | P1 |
| `components/developer-account/DeveloperAccountPanel.tsx` | 开发者账户面板 | P0 |
| `components/developer-account/TierUpgradeModal.tsx` | 等级升级模态框 | P1 |
| `components/developer-account/ApiKeyManager.tsx` | API密钥管理 | P0 |
| `components/workspace/WorkspacePanel.tsx` | 工作空间面板 | P1 |
| `components/workspace/WorkspaceCard.tsx` | 工作空间卡片 | P1 |
| `components/workspace/MemberManager.tsx` | 成员管理 | P1 |
| `components/workspace/InvitationList.tsx` | 邀请列表 | P1 |
| `components/onboarding/PersonaSelector.tsx` | 画像选择器 | P0 |
| `components/onboarding/OnboardingWizard.tsx` | 入驻向导 | P0 |
| `components/onboarding/ApiImportStep.tsx` | API导入步骤 | P0 |
| `components/onboarding/ProductSyncStep.tsx` | 商品同步步骤 | P0 |
| `components/onboarding/ExpertSetupStep.tsx` | 专家设置步骤 | P1 |
| `components/onboarding/DataImportStep.tsx` | 数据导入步骤 | P1 |
| `components/expert/ExpertProfilePanel.tsx` | 专家档案面板 | P2 |
| `components/expert/CapabilityCardEditor.tsx` | 能力卡编辑器 | P2 |
| `components/expert/ConsultationList.tsx` | 咨询列表 | P2 |
| `components/dataset/DatasetPanel.tsx` | 数据集面板 | P2 |
| `components/dataset/DataImportWizard.tsx` | 数据导入向导 | P2 |
| `components/dataset/SchemaEditor.tsx` | Schema编辑器 | P2 |

### 4.2 新增 API 客户端

```typescript
// lib/api/account.api.ts
export const accountApi = {
  list: () => get('/api/accounts/my'),
  getById: (id: string) => get(`/api/accounts/${id}`),
  getBalance: (id: string) => get(`/api/accounts/${id}/balance`),
  deposit: (id: string, data: DepositRequest) => post(`/api/accounts/${id}/deposit`, data),
  withdraw: (id: string, data: WithdrawRequest) => post(`/api/accounts/${id}/withdraw`, data),
  transfer: (data: TransferRequest) => post('/api/accounts/transfer', data),
  freezeBalance: (id: string, data: FreezeRequest) => post(`/api/accounts/${id}/freeze-balance`, data),
  unfreezeBalance: (id: string, data: UnfreezeRequest) => post(`/api/accounts/${id}/unfreeze-balance`, data),
};

// lib/api/agent-account.api.ts
export const agentAccountApi = {
  list: () => get('/api/agent-accounts'),
  create: (data: CreateAgentAccountRequest) => post('/api/agent-accounts', data),
  getById: (id: string) => get(`/api/agent-accounts/${id}`),
  update: (id: string, data: UpdateAgentAccountRequest) => put(`/api/agent-accounts/${id}`, data),
  activate: (id: string) => post(`/api/agent-accounts/${id}/activate`),
  suspend: (id: string) => post(`/api/agent-accounts/${id}/suspend`),
  resume: (id: string) => post(`/api/agent-accounts/${id}/resume`),
  updateCreditScore: (id: string, data: CreditScoreRequest) => post(`/api/agent-accounts/${id}/credit-score`, data),
  checkSpendingLimit: (id: string, amount: number) => get(`/api/agent-accounts/${id}/check-spending?amount=${amount}`),
  linkWallet: (id: string, data: LinkWalletRequest) => post(`/api/agent-accounts/${id}/link-wallet`, data),
};

// lib/api/kyc.api.ts
export const kycApi = {
  getMy: () => get('/api/kyc/my'),
  getActive: () => get('/api/kyc/my/active'),
  checkLevel: (level: string) => get(`/api/kyc/check/${level}`),
  submit: (data: SubmitKYCRequest) => post('/api/kyc/submit', data),
  addInfo: (id: string, data: AdditionalInfoRequest) => post(`/api/kyc/${id}/additional-info`, data),
  cancel: (id: string) => post(`/api/kyc/${id}/cancel`),
};

// lib/api/developer-account.api.ts
export const developerAccountApi = {
  getMy: () => get('/api/developer-accounts/my'),
  getDashboard: () => get('/api/developer-accounts/dashboard'),
  create: (data: CreateDeveloperAccountRequest) => post('/api/developer-accounts', data),
  update: (id: string, data: UpdateDeveloperAccountRequest) => put(`/api/developer-accounts/${id}`, data),
  signAgreement: (id: string) => post(`/api/developer-accounts/${id}/sign-agreement`),
  checkApiKeyLimit: (id: string) => get(`/api/developer-accounts/${id}/api-key-limit`),
  checkRateLimit: (id: string) => get(`/api/developer-accounts/${id}/rate-limit`),
};

// lib/api/workspace.api.ts (已有，需确认完整)
export const workspaceApi = {
  list: () => get('/api/workspaces/my'),
  create: (data: CreateWorkspaceRequest) => post('/api/workspaces', data),
  getById: (id: string) => get(`/api/workspaces/${id}`),
  update: (id: string, data: UpdateWorkspaceRequest) => put(`/api/workspaces/${id}`, data),
  delete: (id: string) => del(`/api/workspaces/${id}`),
  getMembers: (id: string) => get(`/api/workspaces/${id}/members`),
  invite: (id: string, data: InviteRequest) => post(`/api/workspaces/${id}/members/invite`, data),
  updateMember: (id: string, memberId: string, data: UpdateMemberRequest) => put(`/api/workspaces/${id}/members/${memberId}`, data),
  removeMember: (id: string, memberId: string) => del(`/api/workspaces/${id}/members/${memberId}`),
  leave: (id: string) => post(`/api/workspaces/${id}/leave`),
  transfer: (id: string, data: TransferRequest) => post(`/api/workspaces/${id}/transfer`, data),
};
```

### 4.3 Context 增强

```typescript
// contexts/AccountContext.tsx (NEW)
interface AccountContextType {
  accounts: Account[];
  defaultAccount: Account | null;
  loading: boolean;
  refreshAccounts: () => Promise<void>;
  setDefaultAccount: (id: string) => Promise<void>;
}

// contexts/AgentAccountContext.tsx (NEW)
interface AgentAccountContextType {
  agentAccounts: AgentAccount[];
  loading: boolean;
  refreshAgentAccounts: () => Promise<void>;
  createAgentAccount: (data: CreateAgentAccountRequest) => Promise<AgentAccount>;
}

// contexts/KYCContext.tsx (NEW)
interface KYCContextType {
  kycRecords: KYCRecord[];
  activeKYC: KYCRecord | null;
  currentLevel: KYCRecordLevel;
  loading: boolean;
  refreshKYC: () => Promise<void>;
  checkLevel: (level: KYCRecordLevel) => boolean;
}

// contexts/WorkbenchContext.tsx (ENHANCE)
interface WorkbenchContextType {
  // 现有
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  selection: string[];
  setSelection: (ids: string[]) => void;
  workspaceData: any;
  setWorkspaceData: (data: any) => void;
  isChatExpanded: boolean;
  setIsChatExpanded: (expanded: boolean) => void;
  
  // 新增
  currentPersona: UserPersona;
  setCurrentPersona: (persona: UserPersona) => void;
  currentWorkspace: Workspace | null;
  setCurrentWorkspace: (workspace: Workspace | null) => void;
}
```

---

## 五、现有功能保留与迁移

### 5.1 功能迁移映射

| 现有功能 | 当前位置 | 迁移后位置 | 说明 |
|----------|----------|-----------|------|
| 我的 Agent | UserModuleV2 → agents | 保留，增强 Agent 账户信息 | 增加信用评分、支出限额展示 |
| 授权管理 | UserModuleV2 → agents | 迁移至 agent-accounts | 与 AutoPay 合并 |
| 钱包管理 | UserModuleV2 → assets | 迁移至 unified-account | 作为账户的钱包关联 |
| 资产余额 | UserModuleV2 → assets | 迁移至 unified-account | 多账户余额汇总 |
| KYC 认证 | UserModuleV2 → assets | 独立为 kyc 模块 | 完整 KYC 流程 |
| 技能管理 | UserModuleV2 → skills | 保留，增强来源标识 | 标识技能来源类型 |
| 购物功能 | UserModuleV2 → shopping | 保留 | 无变化 |
| 安全策略 | UserModuleV2 → security | 保留，增强审计日志 | 增加交易限额检查日志 |
| 商品管理 | MerchantModuleV2 → products | 保留，增强技能化预览 | 自动生成 Skill Schema |
| 订单管理 | MerchantModuleV2 → orders | 保留 | 无变化 |
| 财务中心 | MerchantModuleV2 → finance | 迁移至 unified-account | 使用统一账户 |
| API 密钥 | MerchantModuleV2/DeveloperModuleV2 | 保留，增强限额展示 | 与开发者等级挂钩 |
| 技能工厂 | DeveloperModuleV2 → build | 保留，增强来源支持 | 支持多种导入方式 |
| 发布分发 | DeveloperModuleV2 → publish | 保留 | 无变化 |
| 收益管理 | DeveloperModuleV2 → revenue | 迁移至 unified-account | 使用统一账户 |

### 5.2 兼容性保障

```typescript
// 1. 角色映射兼容
const personaToMode: Record<UserPersona, 'personal' | 'merchant' | 'developer'> = {
  personal: 'personal',
  api_provider: 'developer',
  merchant: 'merchant',
  expert: 'developer',      // 复用开发者模式
  data_provider: 'developer', // 复用开发者模式
  developer: 'developer',
};

// 2. 路由兼容
// /workbench?mode=merchant 继续工作
// 新增 /workbench?persona=api_provider

// 3. API 兼容
// 现有 API 保持不变
// 新增 API 使用新路径前缀
```

---

## 六、实施计划

### 6.1 阶段划分

#### Phase 1: 核心账户体系集成 (Week 1-2)
| 任务 | 优先级 | 预估工时 | 依赖 |
|------|--------|---------|------|
| 前端 AccountContext 实现 | P0 | 4h | - |
| 前端 AgentAccountContext 实现 | P0 | 4h | - |
| 前端 KYCContext 实现 | P0 | 4h | - |
| UnifiedAccountPanel 组件开发 | P0 | 8h | AccountContext |
| AgentAccountPanel 组件开发 | P0 | 8h | AgentAccountContext |
| KYCCenterPanel 组件开发 | P0 | 6h | KYCContext |
| L2 导航配置更新 | P0 | 4h | - |
| UserModuleV2 集成新面板 | P0 | 6h | 上述组件 |

#### Phase 2: 开发者账户与工作空间 (Week 2-3)
| 任务 | 优先级 | 预估工时 | 依赖 |
|------|--------|---------|------|
| DeveloperAccountPanel 组件开发 | P0 | 8h | - |
| WorkspacePanel 组件开发 | P1 | 8h | - |
| MemberManager 组件开发 | P1 | 6h | WorkspacePanel |
| DeveloperModuleV2 集成 | P0 | 6h | DeveloperAccountPanel |
| 工作空间切换功能 | P1 | 4h | WorkspacePanel |

#### Phase 3: 用户画像与入驻流程 (Week 3-4)
| 任务 | 优先级 | 预估工时 | 依赖 |
|------|--------|---------|------|
| PersonaSelector 组件开发 | P0 | 4h | - |
| OnboardingWizard 框架开发 | P0 | 8h | PersonaSelector |
| ApiImportStep 开发 | P0 | 6h | OnboardingWizard |
| ProductSyncStep 开发 | P0 | 6h | OnboardingWizard |
| 后端 OnboardingModule 开发 | P0 | 12h | - |
| L1 导航画像切换实现 | P0 | 6h | - |

#### Phase 4: 专家与数据提供方 (Week 4-5)
| 任务 | 优先级 | 预估工时 | 依赖 |
|------|--------|---------|------|
| 后端 ExpertProfileModule 开发 | P2 | 12h | - |
| 后端 DatasetModule 开发 | P2 | 16h | - |
| ExpertProfilePanel 组件开发 | P2 | 8h | ExpertProfileModule |
| DatasetPanel 组件开发 | P2 | 10h | DatasetModule |
| ExpertSetupStep 开发 | P2 | 4h | OnboardingWizard |
| DataImportStep 开发 | P2 | 4h | OnboardingWizard |

#### Phase 5: 测试与优化 (Week 5-6)
| 任务 | 优先级 | 预估工时 | 依赖 |
|------|--------|---------|------|
| 端到端测试用例编写 | P0 | 8h | - |
| 现有功能回归测试 | P0 | 6h | - |
| 性能优化 | P1 | 8h | - |
| 文档更新 | P1 | 6h | - |
| Bug 修复缓冲 | P0 | 16h | - |

### 6.2 里程碑

| 里程碑 | 日期 | 交付物 |
|--------|------|--------|
| M1: 账户体系可用 | Week 2 End | 统一账户、Agent账户、KYC 前端可用 |
| M2: 开发者完整体验 | Week 3 End | 开发者账户、工作空间功能完成 |
| M3: 五大画像入驻 | Week 4 End | 入驻流程、画像切换完成 |
| M4: 全功能发布 | Week 6 End | 专家/数据模块、测试完成 |

---

## 七、技术风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| 现有功能回归 | 中 | 高 | 完整回归测试、渐进式发布 |
| 数据迁移复杂 | 低 | 中 | 迁移脚本预演、备份策略 |
| API 兼容性破坏 | 低 | 高 | 版本化 API、兼容层 |
| 性能下降 | 中 | 中 | 延迟加载、缓存策略 |
| 用户体验断层 | 中 | 中 | A/B 测试、用户反馈循环 |

---

## 八、附录

### 8.1 相关文档
- `AGENTRIX_账户体系优化实施报告.md` - 账户系统详细设计
- `AGENTRIX_USER_PERSONAS_ONBOARDING.md` - 用户画像定义
- `AGENTRIX_WORKBENCH_PRD_V3.md` - 工作台产品需求

### 8.2 相关代码
- `backend/src/entities/` - 账户实体定义
- `backend/src/modules/` - 后端模块实现
- `frontend/components/agent/workspace/` - 现有工作台模块
- `frontend/components/layout/` - 导航布局组件

---

**文档版本**: v1.0  
**创建日期**: 2026-01-18  
**作者**: Agentrix 技术团队
