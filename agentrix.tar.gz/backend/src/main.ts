import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { ProxyAgent, setGlobalDispatcher } from 'undici';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'path';
import * as session from 'express-session';
import { AppModule } from './app.module';
import { fixEnumTypesBeforeSync } from './config/database-pre-sync';

async function bootstrap() {
  console.log('🚀 Starting Agentrix Backend...');
  console.log('📝 Node version:', process.version);
  console.log('📁 CWD:', process.cwd());

  // 配置全局代理（针对 Node.js fetch/undici）
  const httpsProxy = process.env.HTTPS_PROXY || process.env.https_proxy || 
                     process.env.HTTP_PROXY || process.env.http_proxy;
  
  if (httpsProxy) {
    try {
      console.log(`🌐 Detected proxy: ${httpsProxy}. Setting up global agent.`);
      const proxyAgent = new ProxyAgent(httpsProxy);
      setGlobalDispatcher(proxyAgent);
    } catch (proxyError: any) {
      console.error(`⚠️ Failed to set global proxy: ${proxyError.message}`);
    }
  }
  
  // 跳过枚举类型修复以加快启动
  // try {
  //   await fixEnumTypesBeforeSync();
  // } catch (error: any) {
  //   console.warn('⚠️  枚举类型修复失败（可能表不存在，将在 synchronize 时创建）:', error.message);
  // }

  console.log('🔧 Creating NestJS application...');
  let app: NestExpressApplication;
  
  try {
    app = await NestFactory.create<NestExpressApplication>(AppModule, {
      rawBody: true,
      abortOnError: false, // 不因错误中止启动
      logger: ['error', 'warn', 'log', 'debug'], // 启用所有日志级别
    });
  } catch (error: any) {
    console.error('❌ Failed to create NestJS application:', error.message);
    console.error('Stack:', error.stack);
    
    // 如果是数据库连接错误，打印详细信息
    if (error.message?.includes('database') || error.message?.includes('connect')) {
      console.error('\n🔍 Database connection failed. Please check:');
      console.error('  1. PostgreSQL is running: sudo service postgresql status');
      console.error('  2. Database exists: PGPASSWORD=agentrix_secure_2024 psql -U agentrix -h localhost -l');
      console.error('  3. Credentials in .env or environment variables');
      console.error('  4. Database: paymind, User: agentrix, Password: agentrix_secure_2024\n');
    }
    
    process.exit(1);
  }

  // Trust proxy for secure cookies behind Nginx
  app.set('trust proxy', 1);

  // Twitter OAuth 1.0a requires session support
  app.use(
    session({
      secret: process.env.SESSION_SECRET || 'agentrix-secret-key-2025',
      resave: false,
      saveUninitialized: false,
      name: 'agentrix.sid', // Custom session cookie name
      cookie: {
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 3600000, // 1 hour
      },
    }),
  );

  app.useStaticAssets(join(process.cwd(), 'uploads'), {
    prefix: '/api/uploads/',
  });

  const corsOrigin = process.env.CORS_ORIGIN || 'http://localhost:3000';
  const corsOrigins = corsOrigin.split(',').map(origin => origin.trim());
  
  // 允许 GPTs Actions 调用（OpenAI 的服务器）
  // GPTs Actions 可能来自 OpenAI 的服务器，需要允许所有来源或特定来源
  const allowGPTs = process.env.ALLOW_GPTs === 'true' || process.env.NODE_ENV === 'production';
  
  app.enableCors({
    origin: allowGPTs ? true : corsOrigins, // 生产环境允许所有来源（GPTs 需要），开发环境限制
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key'], // 添加 X-API-Key 支持
  });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  const { HttpExceptionFilter } = await import('./common/filters/http-exception.filter');
  app.useGlobalFilters(new HttpExceptionFilter());

  const { LoggingInterceptor } = await import('./common/interceptors/logging.interceptor');
  app.useGlobalInterceptors(new LoggingInterceptor());

  // 设置全局前缀，但排除 .well-known 路径（OAuth/OIDC 标准要求根路径）
  app.setGlobalPrefix('api', {
    exclude: ['.well-known/(.*)'],
  });

  const config = new DocumentBuilder()
    .setTitle('Agentrix API')
    .setDescription('Agentrix V7.0 API Documentation - ERC-8004 Session Keys & QuickPay')
    .setVersion('7.0.0')
    .addBearerAuth()
    .addTag('wallets', '钱包管理相关接口')
    .addTag('payments', '支付相关接口')
    .addTag('payment', '支付路由与 Pre-Flight Check (V7.0)')
    .addTag('relayer', 'Relayer 服务 - QuickPay 处理 (V7.0)')
    .addTag('sessions', 'Session 管理 - ERC-8004 (V7.0)')
    .addTag('auto-pay', '自动支付相关接口')
    .addTag('products', '产品市场相关接口')
    .addTag('commissions', '分润结算相关接口')
    .addTag('orders', '订单管理相关接口')
    .addServer('http://localhost:3001', '本地开发环境（API文档）')
    .addServer('https://api.agentrix.io', '生产环境')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document, {
    swaggerOptions: {
      persistAuthorization: true,
      tagsSorter: 'alpha',
      operationsSorter: 'alpha',
    },
    customSiteTitle: 'Agentrix API V7.0',
  });

  const port = process.env.PORT || 3001;
  const host = process.env.HOST || '0.0.0.0';
  
  try {
    await app.listen(port, host);
    console.log(`🚀 Agentrix Backend is running on: http://${host}:${port}`);
    console.log(`📚 API Documentation: http://${host}:${port}/api/docs`);
  } catch (error: any) {
    console.error('❌ Failed to start server:', error.message);
    process.exit(1);
  }
}

bootstrap().catch((error) => {
  console.error('❌ Bootstrap failed:', error);
  process.exit(1);
});

