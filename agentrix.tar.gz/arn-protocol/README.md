# ARN Protocol (Alliance Rewards Network)

> x402 生态的质量与激励基础设施

## 概述

ARN (Alliance Rewards Network) 是 x402 支付协议的激励层，负责：
- 📊 收取和分配协议费用 (0.3%)
- 🏆 管理 Epoch 周期奖励分发
- ✅ 通过 Bond/Challenge 机制保证服务质量

## 架构

```
┌─────────────────────────────────────────────────────────────────┐
│                        用户支付流程                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    ArnSessionManager                             │
│              (Session Key 支付入口)                               │
│  • 验证 Session 签名                                              │
│  • 检查额度限制                                                    │
│  • 转发支付到 FeeSplitter                                         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     ArnFeeSplitter                               │
│               (核心分账合约)                                       │
│  • 扣除 0.3% 协议费 → Treasury                                    │
│  • 记录收据 → ReceiptRegistry                                     │
│  • 转发剩余 99.7% → Commission 合约                               │
└─────────────────────────────────────────────────────────────────┘
                    ┌─────────┴─────────┐
                    │                   │
                    ▼                   ▼
┌───────────────────────────┐  ┌───────────────────────────┐
│      ArnTreasury          │  │    Commission Contract    │
│    (协议费金库)            │  │     (商户分账)            │
│  • 40% Watcher            │  │  • 商户收入               │
│  • 30% Operator           │  │  • Agent 佣金             │
│  • 20% Public Goods       │  │  • 平台费用               │
│  • 10% Security Reserve   │  │  • Off-ramp 费用          │
└───────────────────────────┘  └───────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│                      EpochManager                                │
│                   (周期管理器)                                    │
│  • 7天为一个 Epoch                                               │
│  • 管理 Epoch 生命周期                                            │
│  • 触发奖励分配                                                   │
└─────────────────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│                    MerkleDistributor                             │
│                   (Merkle 分发器)                                 │
│  • 使用 Merkle 证明验证领取资格                                    │
│  • 支持多 Epoch 累积领取                                          │
│  • Gas 高效的批量分发                                             │
└─────────────────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│                  AttestationRegistry                             │
│                  (质量证明注册表)                                  │
│  • Agent 提交服务质量证明                                         │
│  • Bond 质押机制                                                  │
│  • Challenge 挑战机制                                             │
│  • Arbiter 仲裁                                                   │
└─────────────────────────────────────────────────────────────────┘
```

## 合约

| 合约 | 描述 | 状态 |
|------|------|------|
| `ArnSessionManager` | Session Key 支付管理器 | ✅ 完成 |
| `ArnFeeSplitter` | 核心分账合约 (0.3% 协议费) | ✅ 完成 |
| `ArnTreasury` | 协议费金库 (40/30/20/10 分配) | ✅ 完成 |
| `ReceiptRegistry` | 链上收据注册表 | ✅ 完成 |
| `EpochManager` | Epoch 周期管理器 | ✅ 完成 |
| `MerkleDistributor` | Merkle 树奖励分发器 | ✅ 完成 |
| `AttestationRegistry` | 质量证明 + Bond/Challenge | ✅ 完成 |

## 快速开始

### 安装依赖

```bash
cd arn-protocol
npm install
```

### 编译合约

```bash
npm run compile
```

### 运行测试

```bash
npm test
```

### 部署到 BSC Testnet

```bash
# 配置 .env 文件
cp .env.example .env
# 编辑 .env 添加私钥和 RPC URL

# 部署所有合约
npm run deploy:testnet
```

## 配置

### 环境变量

```env
# 必需
PRIVATE_KEY=0x...                    # 部署账户私钥
BSC_TESTNET_RPC_URL=https://...      # BSC Testnet RPC

# 可选
COMMISSION_CONTRACT_ADDRESS=0x...    # Commission 合约地址
BSC_TESTNET_USDC_ADDRESS=0x...       # USDT/USDC 代币地址
BSCSCAN_API_KEY=...                  # 用于合约验证
```

## 费用结构

### 协议费 (0.3%)

每笔 x402 支付扣除 0.3% 协议费，分配如下：

| 角色 | 比例 | 用途 |
|------|------|------|
| Watcher | 40% | 链上监控和预警 |
| Operator | 30% | 节点运营和维护 |
| Public Goods | 20% | 生态公共物品建设 |
| Security Reserve | 10% | 安全储备金 |

### Epoch 奖励

- **周期**: 7 天
- **分发方式**: Merkle 树证明
- **领取**: 用户通过 `claim()` 或 `claimMultiple()` 领取

## 质量激励 (Bond/Challenge)

### 流程

1. **提交证明**: Agent 提交服务质量证明 + 可选 Bond
2. **挑战期**: 7 天内其他人可以 Challenge
3. **仲裁**: 如被挑战，Arbiter 进行仲裁
4. **结果**:
   - 挑战成功: 50% Bond 给挑战者
   - 挑战失败: Agent 保留 Bond，获得验证标记

### 参数

- 最小 Bond: 10 USDT
- 挑战期: 7 天
- Slash 比例: 50%

## 测试覆盖

```
ARN Protocol
  ArnFeeSplitter
    ✔ Should split native payment correctly with 0.3% fee
    ✔ Should emit PaymentSplit event
  ArnTreasury
    ✔ Should have correct distribution ratios
    ✔ Should receive funds
  ReceiptRegistry
    ✔ Should record receipt correctly
    ✔ Should track epoch stats
  EpochManager
    ✔ Should initialize with epoch 1
    ✔ Should not advance epoch before time
    ✔ Should advance epoch after duration
    ✔ Should finalize epoch with merkle root
  MerkleDistributor
    ✔ Should set merkle root
  AttestationRegistry
    ✔ Should submit attestation without bond
    ✔ Should validate attestation after challenge period

15 passing
```

## 路线图

### Phase 1: 核心合约 ✅
- [x] ArnSessionManager
- [x] ArnFeeSplitter
- [x] ArnTreasury
- [x] ReceiptRegistry
- [x] EpochManager
- [x] MerkleDistributor
- [x] AttestationRegistry

### Phase 2: 后端服务 (进行中)
- [ ] Epoch 结算服务
- [ ] Merkle 树生成服务
- [ ] 奖励计算引擎
- [ ] 链上事件索引器

### Phase 3: 前端集成
- [ ] 奖励仪表盘
- [ ] 领取界面
- [ ] Agent 证明提交
- [ ] 挑战/仲裁界面

### Phase 4: 独立仓库
- [ ] 迁移到独立 GitHub 仓库
- [ ] NPM 包发布
- [ ] SDK 开发
- [ ] 文档站点

## 许可证

MIT

## 相关链接

- [x402 Protocol](https://x402.org)
- [Agentrix](https://agentrix.top)
- [ERC-8004 Session Keys](https://eips.ethereum.org/EIPS/eip-8004)
