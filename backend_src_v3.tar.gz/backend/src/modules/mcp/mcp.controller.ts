import { Controller, Get, Post, Body, Req, Res, Logger, UseGuards, Param } from '@nestjs/common';
import { Request, Response } from 'express';
import { McpService } from './mcp.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';

@Controller('mcp')
export class McpController {
  private readonly logger = new Logger(McpController.name);

  constructor(private readonly mcpService: McpService) {}

  /**
   * MCP SSE 端点
   * 用于 ChatGPT 等云端 AI 建立长连接
   */
  @Get('sse')
  async sse(@Req() req: Request, @Res() res: Response) {
    this.logger.log('New MCP SSE connection request');
    
    // 创建一个新的 SSE transport 并连接到 server
    // 注意：在生产环境中，可能需要管理多个 transport 实例
    const transport = new (SSEServerTransport as any)('/api/mcp/messages', res);
    await this.mcpService.connectTransport(transport);
    
    this.logger.log('MCP SSE connection established');
  }

  /**
   * 处理来自 AI 的消息
   */
  @Post('messages')
  async messages(@Req() req: Request, @Res() res: Response) {
    // 这里需要找到对应的 transport 实例来处理消息
    // 暂时使用 service 中最后连接的 transport (仅适用于单用户测试)
    const transport = (this.mcpService as any).server.transport;
    if (transport && (transport as any).handlePostMessage) {
      await (transport as any).handlePostMessage(req, res);
    } else {
      res.status(404).send('No active MCP transport found');
    }
  }

  /**
   * 获取 OpenAPI Schema
   * 用于 Gemini Extensions 或 Grok Tools
   */
  @Get('openapi.json')
  async getOpenApi() {
    return this.mcpService.getOpenApiSchema();
  }

  /**
   * REST 桥接：执行 Tool 调用
   * 用于不支持 MCP 的平台通过 REST 调用
   */
  @Post('tool/:name')
  async callTool(@Param('name') name: string, @Body() args: any) {
    return this.mcpService.callTool(name, args);
  }
}
