-- 创建初始 schema（users, wallet_connections, payments, auto_pay_grants）
-- 在服务器上执行: docker exec -i postgresql psql -U root -d paymind < scripts/create-initial-schema.sql

-- 1. 创建 users 表
CREATE TABLE IF NOT EXISTS "users" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  "agentrixId" varchar UNIQUE NOT NULL,
  "roles" varchar[] DEFAULT '{user}',
  "email" varchar,
  "passwordHash" varchar,
  "kycLevel" varchar DEFAULT 'none',
  "kycStatus" varchar DEFAULT 'none',
  "createdAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" timestamp DEFAULT CURRENT_TIMESTAMP
);

-- 2. 创建 wallet_connections 表
CREATE TABLE IF NOT EXISTS "wallet_connections" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId" uuid NOT NULL,
  "walletType" varchar NOT NULL,
  "walletAddress" varchar NOT NULL,
  "chain" varchar NOT NULL,
  "chainId" varchar,
  "isDefault" boolean DEFAULT false,
  "connectedAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  "lastUsedAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FK_wallet_connections_userId" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE
);

-- 3. 创建 payments 表
CREATE TABLE IF NOT EXISTS "payments" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId" uuid NOT NULL,
  "amount" decimal(15,2) NOT NULL,
  "currency" varchar(10) NOT NULL,
  "paymentMethod" varchar NOT NULL,
  "status" varchar DEFAULT 'pending',
  "transactionHash" varchar,
  "description" text,
  "merchantId" uuid,
  "agentId" uuid,
  "metadata" jsonb,
  "createdAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FK_payments_userId" FOREIGN KEY ("userId") REFERENCES "users"("id")
);

-- 4. 创建 auto_pay_grants 表
CREATE TABLE IF NOT EXISTS "auto_pay_grants" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  "userId" uuid NOT NULL,
  "agentId" uuid NOT NULL,
  "singleLimit" decimal(15,2) NOT NULL,
  "dailyLimit" decimal(15,2) NOT NULL,
  "usedToday" decimal(15,2) DEFAULT 0,
  "totalUsed" decimal(15,2) DEFAULT 0,
  "expiresAt" timestamp,
  "isActive" boolean DEFAULT true,
  "createdAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FK_auto_pay_grants_userId" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE
);

-- 5. 标记初始迁移为已执行
INSERT INTO migrations (timestamp, name) 
VALUES (1700000000000, 'InitialSchema1700000000000')
ON CONFLICT DO NOTHING;

-- 6. 验证表是否创建成功
SELECT 
  CASE WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users') THEN '✅ users 表创建成功' ELSE '❌ users 表创建失败' END as users_status,
  CASE WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'wallet_connections') THEN '✅ wallet_connections 表创建成功' ELSE '❌ wallet_connections 表创建失败' END as wallet_connections_status,
  CASE WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'payments') THEN '✅ payments 表创建成功' ELSE '❌ payments 表创建失败' END as payments_status,
  CASE WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'auto_pay_grants') THEN '✅ auto_pay_grants 表创建成功' ELSE '❌ auto_pay_grants 表创建失败' END as auto_pay_grants_status;

