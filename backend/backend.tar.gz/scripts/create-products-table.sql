-- 创建 products 表的 SQL 脚本
-- 在服务器上执行: docker exec -i postgresql psql -U root -d paymind < scripts/create-products-table.sql

-- 创建枚举类型
DO $$ BEGIN
  CREATE TYPE "public"."products_status_enum" AS ENUM('active', 'inactive', 'out_of_stock');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- 创建 products 表
CREATE TABLE IF NOT EXISTS "products" (
  "id" uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  "merchantId" uuid NOT NULL,
  "name" varchar NOT NULL,
  "description" text,
  "price" decimal(15,2) NOT NULL,
  "stock" integer DEFAULT 0,
  "category" varchar NOT NULL,
  "commissionRate" decimal(5,2),
  "productType" varchar(50) DEFAULT 'physical' NOT NULL,
  "fixedCommissionRate" decimal(5,4),
  "allowCommissionAdjustment" boolean DEFAULT false NOT NULL,
  "minCommissionRate" decimal(5,4),
  "maxCommissionRate" decimal(5,4),
  "status" "public"."products_status_enum" DEFAULT 'active',
  "metadata" jsonb,
  "createdAt" timestamp DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" timestamp DEFAULT CURRENT_TIMESTAMP
);

-- 创建外键（如果 users 表存在）
DO $$ 
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.table_constraints 
      WHERE constraint_name = 'FK_products_merchantId' 
      AND table_name = 'products'
    ) THEN
      ALTER TABLE "products" 
      ADD CONSTRAINT "FK_products_merchantId" 
      FOREIGN KEY ("merchantId") REFERENCES "users"("id") ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

-- 创建索引
CREATE INDEX IF NOT EXISTS "IDX_products_merchantId" ON "products"("merchantId");
CREATE INDEX IF NOT EXISTS "IDX_products_status" ON "products"("status");

-- 验证表是否创建成功
SELECT 
  CASE 
    WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'products') 
    THEN '✅ products 表创建成功'
    ELSE '❌ products 表创建失败'
  END as result;

