(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7202],{65987:function(e){"use strict";var t={single_source_shortest_paths:function(e,i,r){var n,a,l,s,c,d,u,h={},p={};p[i]=0;var g=t.PriorityQueue.make();for(g.push(i,0);!g.empty();)for(l in a=(n=g.pop()).value,s=n.cost,c=e[a]||{})c.hasOwnProperty(l)&&(d=s+c[l],u=p[l],(void 0===p[l]||u>d)&&(p[l]=d,g.push(l,d),h[l]=a));if(void 0!==r&&void 0===p[r])throw Error(["Could not find a path from ",i," to ",r,"."].join(""));return h},extract_shortest_path_from_predecessor_list:function(e,t){for(var i=[],r=t;r;)i.push(r),e[r],r=e[r];return i.reverse(),i},find_path:function(e,i,r){var n=t.single_source_shortest_paths(e,i,r);return t.extract_shortest_path_from_predecessor_list(n,r)},PriorityQueue:{make:function(e){var i,r=t.PriorityQueue,n={};for(i in e=e||{},r)r.hasOwnProperty(i)&&(n[i]=r[i]);return n.queue=[],n.sorter=e.sorter||r.default_sorter,n},default_sorter:function(e,t){return e.cost-t.cost},push:function(e,t){this.queue.push({value:e,cost:t}),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return 0===this.queue.length}}};e.exports=t},62378:function(e){"use strict";e.exports=function(e){for(var t=[],i=e.length,r=0;r<i;r++){var n=e.charCodeAt(r);if(n>=55296&&n<=56319&&i>r+1){var a=e.charCodeAt(r+1);a>=56320&&a<=57343&&(n=(n-55296)*1024+a-56320+65536,r+=1)}if(n<128){t.push(n);continue}if(n<2048){t.push(n>>6|192),t.push(63&n|128);continue}if(n<55296||n>=57344&&n<65536){t.push(n>>12|224),t.push(n>>6&63|128),t.push(63&n|128);continue}if(n>=65536&&n<=1114111){t.push(n>>18|240),t.push(n>>12&63|128),t.push(n>>6&63|128),t.push(63&n|128);continue}t.push(239,191,189)}return new Uint8Array(t).buffer}},92592:function(e,t,i){let r=i(47138),n=i(95115),a=i(6907),l=i(93776);function renderCanvas(e,t,i,a,l){let s=[].slice.call(arguments,1),c=s.length,d="function"==typeof s[c-1];if(!d&&!r())throw Error("Callback required as last argument");if(d){if(c<2)throw Error("Too few arguments provided");2===c?(l=i,i=t,t=a=void 0):3===c&&(t.getContext&&void 0===l?(l=a,a=void 0):(l=a,a=i,i=t,t=void 0))}else{if(c<1)throw Error("Too few arguments provided");return 1===c?(i=t,t=a=void 0):2!==c||t.getContext||(a=i,i=t,t=void 0),new Promise(function(r,l){try{let l=n.create(i,a);r(e(l,t,a))}catch(e){l(e)}})}try{let r=n.create(i,a);l(null,e(r,t,a))}catch(e){l(e)}}t.create=n.create,t.toCanvas=renderCanvas.bind(null,a.render),t.toDataURL=renderCanvas.bind(null,a.renderToDataURL),t.toString=renderCanvas.bind(null,function(e,t,i){return l.render(e,i)})},47138:function(e){e.exports=function(){return"function"==typeof Promise&&Promise.prototype&&Promise.prototype.then}},21845:function(e,t,i){let r=i(10242).getSymbolSize;t.getRowColCoords=function(e){if(1===e)return[];let t=Math.floor(e/7)+2,i=r(e),n=145===i?26:2*Math.ceil((i-13)/(2*t-2)),a=[i-7];for(let e=1;e<t-1;e++)a[e]=a[e-1]-n;return a.push(6),a.reverse()},t.getPositions=function(e){let i=[],r=t.getRowColCoords(e),n=r.length;for(let e=0;e<n;e++)for(let t=0;t<n;t++)(0!==e||0!==t)&&(0!==e||t!==n-1)&&(e!==n-1||0!==t)&&i.push([r[e],r[t]]);return i}},8260:function(e,t,i){let r=i(76910),n=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function AlphanumericData(e){this.mode=r.ALPHANUMERIC,this.data=e}AlphanumericData.getBitsLength=function(e){return 11*Math.floor(e/2)+6*(e%2)},AlphanumericData.prototype.getLength=function(){return this.data.length},AlphanumericData.prototype.getBitsLength=function(){return AlphanumericData.getBitsLength(this.data.length)},AlphanumericData.prototype.write=function(e){let t;for(t=0;t+2<=this.data.length;t+=2){let i=45*n.indexOf(this.data[t]);i+=n.indexOf(this.data[t+1]),e.put(i,11)}this.data.length%2&&e.put(n.indexOf(this.data[t]),6)},e.exports=AlphanumericData},97245:function(e){function BitBuffer(){this.buffer=[],this.length=0}BitBuffer.prototype={get:function(e){return(this.buffer[Math.floor(e/8)]>>>7-e%8&1)==1},put:function(e,t){for(let i=0;i<t;i++)this.putBit((e>>>t-i-1&1)==1)},getLengthInBits:function(){return this.length},putBit:function(e){let t=Math.floor(this.length/8);this.buffer.length<=t&&this.buffer.push(0),e&&(this.buffer[t]|=128>>>this.length%8),this.length++}},e.exports=BitBuffer},73280:function(e){function BitMatrix(e){if(!e||e<1)throw Error("BitMatrix size must be defined and greater than 0");this.size=e,this.data=new Uint8Array(e*e),this.reservedBit=new Uint8Array(e*e)}BitMatrix.prototype.set=function(e,t,i,r){let n=e*this.size+t;this.data[n]=i,r&&(this.reservedBit[n]=!0)},BitMatrix.prototype.get=function(e,t){return this.data[e*this.size+t]},BitMatrix.prototype.xor=function(e,t,i){this.data[e*this.size+t]^=i},BitMatrix.prototype.isReserved=function(e,t){return this.reservedBit[e*this.size+t]},e.exports=BitMatrix},60362:function(e,t,i){let r=i(62378),n=i(76910);function ByteData(e){this.mode=n.BYTE,"string"==typeof e&&(e=r(e)),this.data=new Uint8Array(e)}ByteData.getBitsLength=function(e){return 8*e},ByteData.prototype.getLength=function(){return this.data.length},ByteData.prototype.getBitsLength=function(){return ByteData.getBitsLength(this.data.length)},ByteData.prototype.write=function(e){for(let t=0,i=this.data.length;t<i;t++)e.put(this.data[t],8)},e.exports=ByteData},35393:function(e,t,i){let r=i(64908),n=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],a=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];t.getBlocksCount=function(e,t){switch(t){case r.L:return n[(e-1)*4+0];case r.M:return n[(e-1)*4+1];case r.Q:return n[(e-1)*4+2];case r.H:return n[(e-1)*4+3];default:return}},t.getTotalCodewordsCount=function(e,t){switch(t){case r.L:return a[(e-1)*4+0];case r.M:return a[(e-1)*4+1];case r.Q:return a[(e-1)*4+2];case r.H:return a[(e-1)*4+3];default:return}}},64908:function(e,t){t.L={bit:1},t.M={bit:0},t.Q={bit:3},t.H={bit:2},t.isValid=function(e){return e&&void 0!==e.bit&&e.bit>=0&&e.bit<4},t.from=function(e,i){if(t.isValid(e))return e;try{return function(e){if("string"!=typeof e)throw Error("Param is not a string");let i=e.toLowerCase();switch(i){case"l":case"low":return t.L;case"m":case"medium":return t.M;case"q":case"quartile":return t.Q;case"h":case"high":return t.H;default:throw Error("Unknown EC Level: "+e)}}(e)}catch(e){return i}}},76526:function(e,t,i){let r=i(10242).getSymbolSize;t.getPositions=function(e){let t=r(e);return[[0,0],[t-7,0],[0,t-7]]}},61642:function(e,t,i){let r=i(10242),n=r.getBCHDigit(1335);t.getEncodedBits=function(e,t){let i=e.bit<<3|t,a=i<<10;for(;r.getBCHDigit(a)-n>=0;)a^=1335<<r.getBCHDigit(a)-n;return(i<<10|a)^21522}},69729:function(e,t){let i=new Uint8Array(512),r=new Uint8Array(256);!function(){let e=1;for(let t=0;t<255;t++)i[t]=e,r[e]=t,256&(e<<=1)&&(e^=285);for(let e=255;e<512;e++)i[e]=i[e-255]}(),t.log=function(e){if(e<1)throw Error("log("+e+")");return r[e]},t.exp=function(e){return i[e]},t.mul=function(e,t){return 0===e||0===t?0:i[r[e]+r[t]]}},35442:function(e,t,i){let r=i(76910),n=i(10242);function KanjiData(e){this.mode=r.KANJI,this.data=e}KanjiData.getBitsLength=function(e){return 13*e},KanjiData.prototype.getLength=function(){return this.data.length},KanjiData.prototype.getBitsLength=function(){return KanjiData.getBitsLength(this.data.length)},KanjiData.prototype.write=function(e){let t;for(t=0;t<this.data.length;t++){let i=n.toSJIS(this.data[t]);if(i>=33088&&i<=40956)i-=33088;else if(i>=57408&&i<=60351)i-=49472;else throw Error("Invalid SJIS character: "+this.data[t]+"\nMake sure your charset is UTF-8");i=(i>>>8&255)*192+(255&i),e.put(i,13)}},e.exports=KanjiData},27126:function(e,t){t.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};let i={N1:3,N2:3,N3:40,N4:10};t.isValid=function(e){return null!=e&&""!==e&&!isNaN(e)&&e>=0&&e<=7},t.from=function(e){return t.isValid(e)?parseInt(e,10):void 0},t.getPenaltyN1=function(e){let t=e.size,r=0,n=0,a=0,l=null,s=null;for(let c=0;c<t;c++){n=a=0,l=s=null;for(let d=0;d<t;d++){let t=e.get(c,d);t===l?n++:(n>=5&&(r+=i.N1+(n-5)),l=t,n=1),(t=e.get(d,c))===s?a++:(a>=5&&(r+=i.N1+(a-5)),s=t,a=1)}n>=5&&(r+=i.N1+(n-5)),a>=5&&(r+=i.N1+(a-5))}return r},t.getPenaltyN2=function(e){let t=e.size,r=0;for(let i=0;i<t-1;i++)for(let n=0;n<t-1;n++){let t=e.get(i,n)+e.get(i,n+1)+e.get(i+1,n)+e.get(i+1,n+1);(4===t||0===t)&&r++}return r*i.N2},t.getPenaltyN3=function(e){let t=e.size,r=0,n=0,a=0;for(let i=0;i<t;i++){n=a=0;for(let l=0;l<t;l++)n=n<<1&2047|e.get(i,l),l>=10&&(1488===n||93===n)&&r++,a=a<<1&2047|e.get(l,i),l>=10&&(1488===a||93===a)&&r++}return r*i.N3},t.getPenaltyN4=function(e){let t=0,r=e.data.length;for(let i=0;i<r;i++)t+=e.data[i];let n=Math.abs(Math.ceil(100*t/r/5)-10);return n*i.N4},t.applyMask=function(e,i){let r=i.size;for(let n=0;n<r;n++)for(let a=0;a<r;a++)i.isReserved(a,n)||i.xor(a,n,function(e,i,r){switch(e){case t.Patterns.PATTERN000:return(i+r)%2==0;case t.Patterns.PATTERN001:return i%2==0;case t.Patterns.PATTERN010:return r%3==0;case t.Patterns.PATTERN011:return(i+r)%3==0;case t.Patterns.PATTERN100:return(Math.floor(i/2)+Math.floor(r/3))%2==0;case t.Patterns.PATTERN101:return i*r%2+i*r%3==0;case t.Patterns.PATTERN110:return(i*r%2+i*r%3)%2==0;case t.Patterns.PATTERN111:return(i*r%3+(i+r)%2)%2==0;default:throw Error("bad maskPattern:"+e)}}(e,a,n))},t.getBestMask=function(e,i){let r=Object.keys(t.Patterns).length,n=0,a=1/0;for(let l=0;l<r;l++){i(l),t.applyMask(l,e);let r=t.getPenaltyN1(e)+t.getPenaltyN2(e)+t.getPenaltyN3(e)+t.getPenaltyN4(e);t.applyMask(l,e),r<a&&(a=r,n=l)}return n}},76910:function(e,t,i){let r=i(43114),n=i(7007);t.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},t.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},t.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},t.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},t.MIXED={bit:-1},t.getCharCountIndicator=function(e,t){if(!e.ccBits)throw Error("Invalid mode: "+e);if(!r.isValid(t))throw Error("Invalid version: "+t);return t>=1&&t<10?e.ccBits[0]:t<27?e.ccBits[1]:e.ccBits[2]},t.getBestModeForData=function(e){return n.testNumeric(e)?t.NUMERIC:n.testAlphanumeric(e)?t.ALPHANUMERIC:n.testKanji(e)?t.KANJI:t.BYTE},t.toString=function(e){if(e&&e.id)return e.id;throw Error("Invalid mode")},t.isValid=function(e){return e&&e.bit&&e.ccBits},t.from=function(e,i){if(t.isValid(e))return e;try{return function(e){if("string"!=typeof e)throw Error("Param is not a string");let i=e.toLowerCase();switch(i){case"numeric":return t.NUMERIC;case"alphanumeric":return t.ALPHANUMERIC;case"kanji":return t.KANJI;case"byte":return t.BYTE;default:throw Error("Unknown mode: "+e)}}(e)}catch(e){return i}}},41085:function(e,t,i){let r=i(76910);function NumericData(e){this.mode=r.NUMERIC,this.data=e.toString()}NumericData.getBitsLength=function(e){return 10*Math.floor(e/3)+(e%3?e%3*3+1:0)},NumericData.prototype.getLength=function(){return this.data.length},NumericData.prototype.getBitsLength=function(){return NumericData.getBitsLength(this.data.length)},NumericData.prototype.write=function(e){let t,i;for(t=0;t+3<=this.data.length;t+=3)i=parseInt(this.data.substr(t,3),10),e.put(i,10);let r=this.data.length-t;r>0&&(i=parseInt(this.data.substr(t),10),e.put(i,3*r+1))},e.exports=NumericData},26143:function(e,t,i){let r=i(69729);t.mul=function(e,t){let i=new Uint8Array(e.length+t.length-1);for(let n=0;n<e.length;n++)for(let a=0;a<t.length;a++)i[n+a]^=r.mul(e[n],t[a]);return i},t.mod=function(e,t){let i=new Uint8Array(e);for(;i.length-t.length>=0;){let e=i[0];for(let n=0;n<t.length;n++)i[n]^=r.mul(t[n],e);let n=0;for(;n<i.length&&0===i[n];)n++;i=i.slice(n)}return i},t.generateECPolynomial=function(e){let i=new Uint8Array([1]);for(let n=0;n<e;n++)i=t.mul(i,new Uint8Array([1,r.exp(n)]));return i}},95115:function(e,t,i){let r=i(10242),n=i(64908),a=i(97245),l=i(73280),s=i(21845),c=i(76526),d=i(27126),u=i(35393),h=i(52882),p=i(23103),g=i(61642),w=i(76910),m=i(16130);function setupFormatInfo(e,t,i){let r,n;let a=e.size,l=g.getEncodedBits(t,i);for(r=0;r<15;r++)n=(l>>r&1)==1,r<6?e.set(r,8,n,!0):r<8?e.set(r+1,8,n,!0):e.set(a-15+r,8,n,!0),r<8?e.set(8,a-r-1,n,!0):r<9?e.set(8,15-r-1+1,n,!0):e.set(8,15-r-1,n,!0);e.set(a-8,8,1,!0)}t.create=function(e,t){let i,g;if(void 0===e||""===e)throw Error("No input text");let b=n.M;return void 0!==t&&(b=n.from(t.errorCorrectionLevel,n.M),i=p.from(t.version),g=d.from(t.maskPattern),t.toSJISFunc&&r.setToSJISFunction(t.toSJISFunc)),function(e,t,i,n){let g;if(Array.isArray(e))g=m.fromArray(e);else if("string"==typeof e){let r=t;if(!r){let t=m.rawSplit(e);r=p.getBestVersionForData(t,i)}g=m.fromString(e,r||40)}else throw Error("Invalid data");let b=p.getBestVersionForData(g,i);if(!b)throw Error("The amount of data is too big to be stored in a QR Code");if(t){if(t<b)throw Error("\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: "+b+".\n")}else t=b;let y=function(e,t,i){let n=new a;i.forEach(function(t){n.put(t.mode.bit,4),n.put(t.getLength(),w.getCharCountIndicator(t.mode,e)),t.write(n)});let l=r.getSymbolTotalCodewords(e),s=u.getTotalCodewordsCount(e,t),c=(l-s)*8;for(n.getLengthInBits()+4<=c&&n.put(0,4);n.getLengthInBits()%8!=0;)n.putBit(0);let d=(c-n.getLengthInBits())/8;for(let e=0;e<d;e++)n.put(e%2?17:236,8);return function(e,t,i){let n,a;let l=r.getSymbolTotalCodewords(t),s=u.getTotalCodewordsCount(t,i),c=l-s,d=u.getBlocksCount(t,i),p=l%d,g=d-p,w=Math.floor(l/d),m=Math.floor(c/d),b=m+1,y=w-m,_=new h(y),v=0,C=Array(d),x=Array(d),$=0,k=new Uint8Array(e.buffer);for(let e=0;e<d;e++){let t=e<g?m:b;C[e]=k.slice(v,v+t),x[e]=_.encode(C[e]),v+=t,$=Math.max($,t)}let R=new Uint8Array(l),E=0;for(n=0;n<$;n++)for(a=0;a<d;a++)n<C[a].length&&(R[E++]=C[a][n]);for(n=0;n<y;n++)for(a=0;a<d;a++)R[E++]=x[a][n];return R}(n,e,t)}(t,i,g),_=r.getSymbolSize(t),v=new l(_);return function(e,t){let i=e.size,r=c.getPositions(t);for(let t=0;t<r.length;t++){let n=r[t][0],a=r[t][1];for(let t=-1;t<=7;t++)if(!(n+t<=-1)&&!(i<=n+t))for(let r=-1;r<=7;r++)a+r<=-1||i<=a+r||(t>=0&&t<=6&&(0===r||6===r)||r>=0&&r<=6&&(0===t||6===t)||t>=2&&t<=4&&r>=2&&r<=4?e.set(n+t,a+r,!0,!0):e.set(n+t,a+r,!1,!0))}}(v,t),function(e){let t=e.size;for(let i=8;i<t-8;i++){let t=i%2==0;e.set(i,6,t,!0),e.set(6,i,t,!0)}}(v),function(e,t){let i=s.getPositions(t);for(let t=0;t<i.length;t++){let r=i[t][0],n=i[t][1];for(let t=-2;t<=2;t++)for(let i=-2;i<=2;i++)-2===t||2===t||-2===i||2===i||0===t&&0===i?e.set(r+t,n+i,!0,!0):e.set(r+t,n+i,!1,!0)}}(v,t),setupFormatInfo(v,i,0),t>=7&&function(e,t){let i,r,n;let a=e.size,l=p.getEncodedBits(t);for(let t=0;t<18;t++)i=Math.floor(t/3),r=t%3+a-8-3,n=(l>>t&1)==1,e.set(i,r,n,!0),e.set(r,i,n,!0)}(v,t),function(e,t){let i=e.size,r=-1,n=i-1,a=7,l=0;for(let s=i-1;s>0;s-=2)for(6===s&&s--;;){for(let i=0;i<2;i++)if(!e.isReserved(n,s-i)){let r=!1;l<t.length&&(r=(t[l]>>>a&1)==1),e.set(n,s-i,r),-1==--a&&(l++,a=7)}if((n+=r)<0||i<=n){n-=r,r=-r;break}}}(v,y),isNaN(n)&&(n=d.getBestMask(v,setupFormatInfo.bind(null,v,i))),d.applyMask(n,v),setupFormatInfo(v,i,n),{modules:v,version:t,errorCorrectionLevel:i,maskPattern:n,segments:g}}(e,i,b,g)}},52882:function(e,t,i){let r=i(26143);function ReedSolomonEncoder(e){this.genPoly=void 0,this.degree=e,this.degree&&this.initialize(this.degree)}ReedSolomonEncoder.prototype.initialize=function(e){this.degree=e,this.genPoly=r.generateECPolynomial(this.degree)},ReedSolomonEncoder.prototype.encode=function(e){if(!this.genPoly)throw Error("Encoder not initialized");let t=new Uint8Array(e.length+this.degree);t.set(e);let i=r.mod(t,this.genPoly),n=this.degree-i.length;if(n>0){let e=new Uint8Array(this.degree);return e.set(i,n),e}return i},e.exports=ReedSolomonEncoder},7007:function(e,t){let i="[0-9]+",r="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";r=r.replace(/u/g,"\\u");let n="(?:(?![A-Z0-9 $%*+\\-./:]|"+r+")(?:.|[\r\n]))+";t.KANJI=RegExp(r,"g"),t.BYTE_KANJI=RegExp("[^A-Z0-9 $%*+\\-./:]+","g"),t.BYTE=RegExp(n,"g"),t.NUMERIC=RegExp(i,"g"),t.ALPHANUMERIC=RegExp("[A-Z $%*+\\-./:]+","g");let a=RegExp("^"+r+"$"),l=RegExp("^"+i+"$"),s=RegExp("^[A-Z0-9 $%*+\\-./:]+$");t.testKanji=function(e){return a.test(e)},t.testNumeric=function(e){return l.test(e)},t.testAlphanumeric=function(e){return s.test(e)}},16130:function(e,t,i){let r=i(76910),n=i(41085),a=i(8260),l=i(60362),s=i(35442),c=i(7007),d=i(10242),u=i(65987);function getStringByteLength(e){return unescape(encodeURIComponent(e)).length}function getSegments(e,t,i){let r;let n=[];for(;null!==(r=e.exec(i));)n.push({data:r[0],index:r.index,mode:t,length:r[0].length});return n}function getSegmentsFromString(e){let t,i;let n=getSegments(c.NUMERIC,r.NUMERIC,e),a=getSegments(c.ALPHANUMERIC,r.ALPHANUMERIC,e);d.isKanjiModeEnabled()?(t=getSegments(c.BYTE,r.BYTE,e),i=getSegments(c.KANJI,r.KANJI,e)):(t=getSegments(c.BYTE_KANJI,r.BYTE,e),i=[]);let l=n.concat(a,t,i);return l.sort(function(e,t){return e.index-t.index}).map(function(e){return{data:e.data,mode:e.mode,length:e.length}})}function getSegmentBitsLength(e,t){switch(t){case r.NUMERIC:return n.getBitsLength(e);case r.ALPHANUMERIC:return a.getBitsLength(e);case r.KANJI:return s.getBitsLength(e);case r.BYTE:return l.getBitsLength(e)}}function buildSingleSegment(e,t){let i;let c=r.getBestModeForData(e);if((i=r.from(t,c))!==r.BYTE&&i.bit<c.bit)throw Error('"'+e+'" cannot be encoded with mode '+r.toString(i)+".\n Suggested mode is: "+r.toString(c));switch(i!==r.KANJI||d.isKanjiModeEnabled()||(i=r.BYTE),i){case r.NUMERIC:return new n(e);case r.ALPHANUMERIC:return new a(e);case r.KANJI:return new s(e);case r.BYTE:return new l(e)}}t.fromArray=function(e){return e.reduce(function(e,t){return"string"==typeof t?e.push(buildSingleSegment(t,null)):t.data&&e.push(buildSingleSegment(t.data,t.mode)),e},[])},t.fromString=function(e,i){let n=getSegmentsFromString(e,d.isKanjiModeEnabled()),a=function(e){let t=[];for(let i=0;i<e.length;i++){let n=e[i];switch(n.mode){case r.NUMERIC:t.push([n,{data:n.data,mode:r.ALPHANUMERIC,length:n.length},{data:n.data,mode:r.BYTE,length:n.length}]);break;case r.ALPHANUMERIC:t.push([n,{data:n.data,mode:r.BYTE,length:n.length}]);break;case r.KANJI:t.push([n,{data:n.data,mode:r.BYTE,length:getStringByteLength(n.data)}]);break;case r.BYTE:t.push([{data:n.data,mode:r.BYTE,length:getStringByteLength(n.data)}])}}return t}(n),l=function(e,t){let i={},n={start:{}},a=["start"];for(let l=0;l<e.length;l++){let s=e[l],c=[];for(let e=0;e<s.length;e++){let d=s[e],u=""+l+e;c.push(u),i[u]={node:d,lastCount:0},n[u]={};for(let e=0;e<a.length;e++){let l=a[e];i[l]&&i[l].node.mode===d.mode?(n[l][u]=getSegmentBitsLength(i[l].lastCount+d.length,d.mode)-getSegmentBitsLength(i[l].lastCount,d.mode),i[l].lastCount+=d.length):(i[l]&&(i[l].lastCount=d.length),n[l][u]=getSegmentBitsLength(d.length,d.mode)+4+r.getCharCountIndicator(d.mode,t))}}a=c}for(let e=0;e<a.length;e++)n[a[e]].end=0;return{map:n,table:i}}(a,i),s=u.find_path(l.map,"start","end"),c=[];for(let e=1;e<s.length-1;e++)c.push(l.table[s[e]].node);return t.fromArray(c.reduce(function(e,t){let i=e.length-1>=0?e[e.length-1]:null;return i&&i.mode===t.mode?e[e.length-1].data+=t.data:e.push(t),e},[]))},t.rawSplit=function(e){return t.fromArray(getSegmentsFromString(e,d.isKanjiModeEnabled()))}},10242:function(e,t){let i;let r=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];t.getSymbolSize=function(e){if(!e)throw Error('"version" cannot be null or undefined');if(e<1||e>40)throw Error('"version" should be in range from 1 to 40');return 4*e+17},t.getSymbolTotalCodewords=function(e){return r[e]},t.getBCHDigit=function(e){let t=0;for(;0!==e;)t++,e>>>=1;return t},t.setToSJISFunction=function(e){if("function"!=typeof e)throw Error('"toSJISFunc" is not a valid function.');i=e},t.isKanjiModeEnabled=function(){return void 0!==i},t.toSJIS=function(e){return i(e)}},43114:function(e,t){t.isValid=function(e){return!isNaN(e)&&e>=1&&e<=40}},23103:function(e,t,i){let r=i(10242),n=i(35393),a=i(64908),l=i(76910),s=i(43114),c=r.getBCHDigit(7973);function getReservedBitsCount(e,t){return l.getCharCountIndicator(e,t)+4}t.from=function(e,t){return s.isValid(e)?parseInt(e,10):t},t.getCapacity=function(e,t,i){if(!s.isValid(e))throw Error("Invalid QR Code version");void 0===i&&(i=l.BYTE);let a=r.getSymbolTotalCodewords(e),c=n.getTotalCodewordsCount(e,t),d=(a-c)*8;if(i===l.MIXED)return d;let u=d-getReservedBitsCount(i,e);switch(i){case l.NUMERIC:return Math.floor(u/10*3);case l.ALPHANUMERIC:return Math.floor(u/11*2);case l.KANJI:return Math.floor(u/13);case l.BYTE:default:return Math.floor(u/8)}},t.getBestVersionForData=function(e,i){let r;let n=a.from(i,a.M);if(Array.isArray(e)){if(e.length>1)return function(e,i){for(let r=1;r<=40;r++){let n=function(e,t){let i=0;return e.forEach(function(e){let r=getReservedBitsCount(e.mode,t);i+=r+e.getBitsLength()}),i}(e,r);if(n<=t.getCapacity(r,i,l.MIXED))return r}}(e,n);if(0===e.length)return 1;r=e[0]}else r=e;return function(e,i,r){for(let n=1;n<=40;n++)if(i<=t.getCapacity(n,r,e))return n}(r.mode,r.getLength(),n)},t.getEncodedBits=function(e){if(!s.isValid(e)||e<7)throw Error("Invalid QR Code version");let t=e<<12;for(;r.getBCHDigit(t)-c>=0;)t^=7973<<r.getBCHDigit(t)-c;return e<<12|t}},6907:function(e,t,i){let r=i(89653);t.render=function(e,t,i){var n;let a=i,l=t;void 0!==a||t&&t.getContext||(a=t,t=void 0),t||(l=function(){try{return document.createElement("canvas")}catch(e){throw Error("You need to specify a canvas element")}}()),a=r.getOptions(a);let s=r.getImageWidth(e.modules.size,a),c=l.getContext("2d"),d=c.createImageData(s,s);return r.qrToImageData(d.data,e,a),n=l,c.clearRect(0,0,n.width,n.height),n.style||(n.style={}),n.height=s,n.width=s,n.style.height=s+"px",n.style.width=s+"px",c.putImageData(d,0,0),l},t.renderToDataURL=function(e,i,r){let n=r;void 0!==n||i&&i.getContext||(n=i,i=void 0),n||(n={});let a=t.render(e,i,n),l=n.type||"image/png",s=n.rendererOpts||{};return a.toDataURL(l,s.quality)}},93776:function(e,t,i){let r=i(89653);function getColorAttrib(e,t){let i=e.a/255,r=t+'="'+e.hex+'"';return i<1?r+" "+t+'-opacity="'+i.toFixed(2).slice(1)+'"':r}function svgCmd(e,t,i){let r=e+t;return void 0!==i&&(r+=" "+i),r}t.render=function(e,t,i){let n=r.getOptions(t),a=e.modules.size,l=e.modules.data,s=a+2*n.margin,c=n.color.light.a?"<path "+getColorAttrib(n.color.light,"fill")+' d="M0 0h'+s+"v"+s+'H0z"/>':"",d="<path "+getColorAttrib(n.color.dark,"stroke")+' d="'+function(e,t,i){let r="",n=0,a=!1,l=0;for(let s=0;s<e.length;s++){let c=Math.floor(s%t),d=Math.floor(s/t);c||a||(a=!0),e[s]?(l++,s>0&&c>0&&e[s-1]||(r+=a?svgCmd("M",c+i,.5+d+i):svgCmd("m",n,0),n=0,a=!1),c+1<t&&e[s+1]||(r+=svgCmd("h",l),l=0)):n++}return r}(l,a,n.margin)+'"/>',u=n.width?'width="'+n.width+'" height="'+n.width+'" ':"",h='<svg xmlns="http://www.w3.org/2000/svg" '+u+('viewBox="0 0 '+s)+" "+s+'" shape-rendering="crispEdges">'+c+d+"</svg>\n";return"function"==typeof i&&i(null,h),h}},89653:function(e,t){function hex2rgba(e){if("number"==typeof e&&(e=e.toString()),"string"!=typeof e)throw Error("Color should be defined as hex string");let t=e.slice().replace("#","").split("");if(t.length<3||5===t.length||t.length>8)throw Error("Invalid hex color: "+e);(3===t.length||4===t.length)&&(t=Array.prototype.concat.apply([],t.map(function(e){return[e,e]}))),6===t.length&&t.push("F","F");let i=parseInt(t.join(""),16);return{r:i>>24&255,g:i>>16&255,b:i>>8&255,a:255&i,hex:"#"+t.slice(0,6).join("")}}t.getOptions=function(e){e||(e={}),e.color||(e.color={});let t=void 0===e.margin||null===e.margin||e.margin<0?4:e.margin,i=e.width&&e.width>=21?e.width:void 0,r=e.scale||4;return{width:i,scale:i?4:r,margin:t,color:{dark:hex2rgba(e.color.dark||"#000000ff"),light:hex2rgba(e.color.light||"#ffffffff")},type:e.type,rendererOpts:e.rendererOpts||{}}},t.getScale=function(e,t){return t.width&&t.width>=e+2*t.margin?t.width/(e+2*t.margin):t.scale},t.getImageWidth=function(e,i){let r=t.getScale(e,i);return Math.floor((e+2*i.margin)*r)},t.qrToImageData=function(e,i,r){let n=i.modules.size,a=i.modules.data,l=t.getScale(n,r),s=Math.floor((n+2*r.margin)*l),c=r.margin*l,d=[r.color.light,r.color.dark];for(let t=0;t<s;t++)for(let i=0;i<s;i++){let u=(t*s+i)*4,h=r.color.light;if(t>=c&&i>=c&&t<s-c&&i<s-c){let e=Math.floor((t-c)/l),r=Math.floor((i-c)/l);h=d[a[e*n+r]?1:0]}e[u++]=h.r,e[u++]=h.g,e[u++]=h.b,e[u]=h.a}}},97202:function(e,t,i){"use strict";i.r(t),i.d(t,{W3mAllWalletsView:function(){return eN},W3mConnectingWcBasicView:function(){return eu},W3mDownloadsView:function(){return eU}});var r=i(19064),n=i(39527),a=i(59655),l=i(4159),s=i(47582),c=i(12143),d=i(59987);i(93580);var u=i(47543),h=i(5680),p=i(65579),g=i(62335),w=i(70837),m=i(39192);i(19742);var __decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let b=class extends r.oi{constructor(){super(),this.unsubscribe=[],this.tabIdx=void 0,this.connectors=p.ConnectorController.state.connectors,this.count=s.ApiController.state.count,this.filteredCount=s.ApiController.state.filteredWallets.length,this.isFetchingRecommendedWallets=s.ApiController.state.isFetchingRecommendedWallets,this.unsubscribe.push(p.ConnectorController.subscribeKey("connectors",e=>this.connectors=e),s.ApiController.subscribeKey("count",e=>this.count=e),s.ApiController.subscribeKey("filteredWallets",e=>this.filteredCount=e.length),s.ApiController.subscribeKey("isFetchingRecommendedWallets",e=>this.isFetchingRecommendedWallets=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){let e=this.connectors.find(e=>"walletConnect"===e.id),{allWallets:t}=l.OptionsController.state;if(!e||"HIDE"===t||"ONLY_MOBILE"===t&&!a.j.isMobile())return null;let i=s.ApiController.state.featured.length,n=this.count+i,c=this.filteredCount>0?this.filteredCount:n<10?n:10*Math.floor(n/10),d=`${c}`;this.filteredCount>0?d=`${this.filteredCount}`:c<n&&(d=`${c}+`);let p=g.ConnectionController.hasAnyConnection(h.b.CONNECTOR_ID.WALLET_CONNECT);return r.dy`
      <wui-list-wallet
        name="Search Wallet"
        walletIcon="search"
        showAllWallets
        @click=${this.onAllWallets.bind(this)}
        tagLabel=${d}
        tagVariant="info"
        data-testid="all-wallets"
        tabIdx=${(0,u.o)(this.tabIdx)}
        .loading=${this.isFetchingRecommendedWallets}
        ?disabled=${p}
        size="sm"
      ></wui-list-wallet>
    `}onAllWallets(){w.X.sendEvent({type:"track",event:"CLICK_ALL_WALLETS"}),m.RouterController.push("AllWallets",{redirectView:m.RouterController.state.data?.redirectView})}};__decorate([(0,n.Cb)()],b.prototype,"tabIdx",void 0),__decorate([(0,n.SB)()],b.prototype,"connectors",void 0),__decorate([(0,n.SB)()],b.prototype,"count",void 0),__decorate([(0,n.SB)()],b.prototype,"filteredCount",void 0),__decorate([(0,n.SB)()],b.prototype,"isFetchingRecommendedWallets",void 0),b=__decorate([(0,d.Mo)("w3m-all-wallets-widget")],b);var y=i(11573),_=i(81320),v=i(78262),C=i(43391),x=d.iv`
  :host {
    margin-top: ${({spacing:e})=>e["1"]};
  }
  wui-separator {
    margin: ${({spacing:e})=>e["3"]} calc(${({spacing:e})=>e["3"]} * -1)
      ${({spacing:e})=>e["2"]} calc(${({spacing:e})=>e["3"]} * -1);
    width: calc(100% + ${({spacing:e})=>e["3"]} * 2);
  }
`,w3m_connector_list_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let $=class extends r.oi{constructor(){super(),this.unsubscribe=[],this.connectors=p.ConnectorController.state.connectors,this.recommended=s.ApiController.state.recommended,this.featured=s.ApiController.state.featured,this.explorerWallets=s.ApiController.state.explorerWallets,this.connections=g.ConnectionController.state.connections,this.connectorImages=y.W.state.connectorImages,this.loadingTelegram=!1,this.unsubscribe.push(p.ConnectorController.subscribeKey("connectors",e=>this.connectors=e),g.ConnectionController.subscribeKey("connections",e=>this.connections=e),y.W.subscribeKey("connectorImages",e=>this.connectorImages=e),s.ApiController.subscribeKey("recommended",e=>this.recommended=e),s.ApiController.subscribeKey("featured",e=>this.featured=e),s.ApiController.subscribeKey("explorerFilteredWallets",e=>{this.explorerWallets=e?.length?e:s.ApiController.state.explorerWallets}),s.ApiController.subscribeKey("explorerWallets",e=>{this.explorerWallets?.length||(this.explorerWallets=e)})),a.j.isTelegram()&&a.j.isIos()&&(this.loadingTelegram=!g.ConnectionController.state.wcUri,this.unsubscribe.push(g.ConnectionController.subscribeKey("wcUri",e=>this.loadingTelegram=!e)))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return r.dy`
      <wui-flex flexDirection="column" gap="2"> ${this.connectorListTemplate()} </wui-flex>
    `}mapConnectorsToExplorerWallets(e,t){return e.map(e=>{if("MULTI_CHAIN"===e.type&&e.connectors){let i=e.connectors.map(e=>e.id),r=e.connectors.map(e=>e.name),n=e.connectors.map(e=>e.info?.rdns),a=t?.find(e=>i.includes(e.id)||r.includes(e.name)||e.rdns&&(n.includes(e.rdns)||i.includes(e.rdns)));return e.explorerWallet=a??e.explorerWallet,e}let i=t?.find(t=>t.id===e.id||t.rdns===e.info?.rdns||t.name===e.name);return e.explorerWallet=i??e.explorerWallet,e})}processConnectorsByType(e,t=!0){let i=C.C.sortConnectorsByExplorerWallet([...e]);return t?i.filter(C.C.showConnector):i}connectorListTemplate(){let e=this.mapConnectorsToExplorerWallets(this.connectors,this.explorerWallets??[]),t=C.C.getConnectorsByType(e,this.recommended,this.featured),i=this.processConnectorsByType(t.announced.filter(e=>"walletConnect"!==e.id)),r=this.processConnectorsByType(t.injected),n=this.processConnectorsByType(t.multiChain.filter(e=>"WalletConnect"!==e.name),!1),l=t.custom,s=t.recent,c=this.processConnectorsByType(t.external.filter(e=>e.id!==h.b.CONNECTOR_ID.COINBASE_SDK)),d=t.recommended,u=t.featured,p=C.C.getConnectorTypeOrder({custom:l,recent:s,announced:i,injected:r,multiChain:n,recommended:d,featured:u,external:c}),g=this.connectors.find(e=>"walletConnect"===e.id),w=a.j.isMobile(),m=[];for(let e of p)switch(e){case"walletConnect":!w&&g&&m.push({kind:"connector",subtype:"walletConnect",connector:g});break;case"recent":{let e=C.C.getFilteredRecentWallets();e.forEach(e=>m.push({kind:"wallet",subtype:"recent",wallet:e}));break}case"injected":n.forEach(e=>m.push({kind:"connector",subtype:"multiChain",connector:e})),i.forEach(e=>m.push({kind:"connector",subtype:"announced",connector:e})),r.forEach(e=>m.push({kind:"connector",subtype:"injected",connector:e}));break;case"featured":u.forEach(e=>m.push({kind:"wallet",subtype:"featured",wallet:e}));break;case"custom":{let e=C.C.getFilteredCustomWallets(l??[]);e.forEach(e=>m.push({kind:"wallet",subtype:"custom",wallet:e}));break}case"external":c.forEach(e=>m.push({kind:"connector",subtype:"external",connector:e}));break;case"recommended":{let e=C.C.getCappedRecommendedWallets(d);e.forEach(e=>m.push({kind:"wallet",subtype:"recommended",wallet:e}));break}default:console.warn(`Unknown connector type: ${e}`)}return m.map((e,t)=>"connector"===e.kind?this.renderConnector(e,t):this.renderWallet(e,t))}renderConnector(e,t){let i,n;let a=e.connector,l=_.f.getConnectorImage(a)||this.connectorImages[a?.imageId??""],s=this.connections.get(a.chain)??[],c=s.some(e=>v.g.isLowerCaseMatch(e.connectorId,a.id));"multiChain"===e.subtype?(i="multichain",n="info"):"walletConnect"===e.subtype?(i="qr code",n="accent"):"injected"===e.subtype||"announced"===e.subtype?(i=c?"connected":"installed",n=c?"info":"success"):(i=void 0,n=void 0);let d=g.ConnectionController.hasAnyConnection(h.b.CONNECTOR_ID.WALLET_CONNECT),p=("walletConnect"===e.subtype||"external"===e.subtype)&&d;return r.dy`
      <w3m-list-wallet
        displayIndex=${t}
        imageSrc=${(0,u.o)(l)}
        .installed=${!0}
        name=${a.name??"Unknown"}
        .tagVariant=${n}
        tagLabel=${(0,u.o)(i)}
        data-testid=${`wallet-selector-${a.id.toLowerCase()}`}
        size="sm"
        @click=${()=>this.onClickConnector(e)}
        tabIdx=${(0,u.o)(this.tabIdx)}
        ?disabled=${p}
        rdnsId=${(0,u.o)(a.explorerWallet?.rdns||void 0)}
        walletRank=${(0,u.o)(a.explorerWallet?.order)}
      >
      </w3m-list-wallet>
    `}onClickConnector(e){let t=m.RouterController.state.data?.redirectView;if("walletConnect"===e.subtype){p.ConnectorController.setActiveConnector(e.connector),a.j.isMobile()?m.RouterController.push("AllWallets"):m.RouterController.push("ConnectingWalletConnect",{redirectView:t});return}if("multiChain"===e.subtype){p.ConnectorController.setActiveConnector(e.connector),m.RouterController.push("ConnectingMultiChain",{redirectView:t});return}if("injected"===e.subtype){p.ConnectorController.setActiveConnector(e.connector),m.RouterController.push("ConnectingExternal",{connector:e.connector,redirectView:t,wallet:e.connector.explorerWallet});return}if("announced"===e.subtype){if("walletConnect"===e.connector.id){a.j.isMobile()?m.RouterController.push("AllWallets"):m.RouterController.push("ConnectingWalletConnect",{redirectView:t});return}m.RouterController.push("ConnectingExternal",{connector:e.connector,redirectView:t,wallet:e.connector.explorerWallet});return}m.RouterController.push("ConnectingExternal",{connector:e.connector,redirectView:t})}renderWallet(e,t){let i=e.wallet,n=_.f.getWalletImage(i),a=g.ConnectionController.hasAnyConnection(h.b.CONNECTOR_ID.WALLET_CONNECT),l=this.loadingTelegram,s="recent"===e.subtype?"recent":void 0,c="recent"===e.subtype?"info":void 0;return r.dy`
      <w3m-list-wallet
        displayIndex=${t}
        imageSrc=${(0,u.o)(n)}
        name=${i.name??"Unknown"}
        @click=${()=>this.onClickWallet(e)}
        size="sm"
        data-testid=${`wallet-selector-${i.id}`}
        tabIdx=${(0,u.o)(this.tabIdx)}
        ?loading=${l}
        ?disabled=${a}
        rdnsId=${(0,u.o)(i.rdns||void 0)}
        walletRank=${(0,u.o)(i.order)}
        tagLabel=${(0,u.o)(s)}
        .tagVariant=${c}
      >
      </w3m-list-wallet>
    `}onClickWallet(e){let t=m.RouterController.state.data?.redirectView;if("featured"===e.subtype){p.ConnectorController.selectWalletConnector(e.wallet);return}if("recent"===e.subtype){if(this.loadingTelegram)return;p.ConnectorController.selectWalletConnector(e.wallet);return}if("custom"===e.subtype){if(this.loadingTelegram)return;m.RouterController.push("ConnectingWalletConnect",{wallet:e.wallet,redirectView:t});return}if(this.loadingTelegram)return;let i=p.ConnectorController.getConnector({id:e.wallet.id,rdns:e.wallet.rdns});i?m.RouterController.push("ConnectingExternal",{connector:i,redirectView:t}):m.RouterController.push("ConnectingWalletConnect",{wallet:e.wallet,redirectView:t})}};$.styles=x,w3m_connector_list_decorate([(0,n.Cb)({type:Number})],$.prototype,"tabIdx",void 0),w3m_connector_list_decorate([(0,n.SB)()],$.prototype,"connectors",void 0),w3m_connector_list_decorate([(0,n.SB)()],$.prototype,"recommended",void 0),w3m_connector_list_decorate([(0,n.SB)()],$.prototype,"featured",void 0),w3m_connector_list_decorate([(0,n.SB)()],$.prototype,"explorerWallets",void 0),w3m_connector_list_decorate([(0,n.SB)()],$.prototype,"connections",void 0),w3m_connector_list_decorate([(0,n.SB)()],$.prototype,"connectorImages",void 0),w3m_connector_list_decorate([(0,n.SB)()],$.prototype,"loadingTelegram",void 0),$=w3m_connector_list_decorate([(0,d.Mo)("w3m-connector-list")],$);var k=i(41838),R=i(79874),E=i(35128),S=i(25707),T=i(9210),A=i(27726),B=i(28938),I=i(49300);i(98512),i(19492);var P=i(31816),j=P.iv`
  :host {
    flex: 1;
    height: 100%;
  }

  button {
    width: 100%;
    height: 100%;
    display: inline-flex;
    align-items: center;
    padding: ${({spacing:e})=>e[1]} ${({spacing:e})=>e[2]};
    column-gap: ${({spacing:e})=>e[1]};
    color: ${({tokens:e})=>e.theme.textSecondary};
    border-radius: ${({borderRadius:e})=>e[20]};
    background-color: transparent;
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  button[data-active='true'] {
    color: ${({tokens:e})=>e.theme.textPrimary};
    background-color: ${({tokens:e})=>e.theme.foregroundTertiary};
  }

  button:hover:enabled:not([data-active='true']),
  button:active:enabled:not([data-active='true']) {
    wui-text,
    wui-icon {
      color: ${({tokens:e})=>e.theme.textPrimary};
    }
  }
`,wui_tab_item_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let L={lg:"lg-regular",md:"md-regular",sm:"sm-regular"},O={lg:"md",md:"sm",sm:"sm"},W=class extends r.oi{constructor(){super(...arguments),this.icon="mobile",this.size="md",this.label="",this.active=!1}render(){return r.dy`
      <button data-active=${this.active}>
        ${this.icon?r.dy`<wui-icon size=${O[this.size]} name=${this.icon}></wui-icon>`:""}
        <wui-text variant=${L[this.size]}> ${this.label} </wui-text>
      </button>
    `}};W.styles=[B.ET,B.ZM,j],wui_tab_item_decorate([(0,n.Cb)()],W.prototype,"icon",void 0),wui_tab_item_decorate([(0,n.Cb)()],W.prototype,"size",void 0),wui_tab_item_decorate([(0,n.Cb)()],W.prototype,"label",void 0),wui_tab_item_decorate([(0,n.Cb)({type:Boolean})],W.prototype,"active",void 0),W=wui_tab_item_decorate([(0,I.M)("wui-tab-item")],W);var M=P.iv`
  :host {
    display: inline-flex;
    align-items: center;
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    border-radius: ${({borderRadius:e})=>e[32]};
    padding: ${({spacing:e})=>e["01"]};
    box-sizing: border-box;
  }

  :host([data-size='sm']) {
    height: 26px;
  }

  :host([data-size='md']) {
    height: 36px;
  }
`,wui_tabs_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let N=class extends r.oi{constructor(){super(...arguments),this.tabs=[],this.onTabChange=()=>null,this.size="md",this.activeTab=0}render(){return this.dataset.size=this.size,this.tabs.map((e,t)=>{let i=t===this.activeTab;return r.dy`
        <wui-tab-item
          @click=${()=>this.onTabClick(t)}
          icon=${e.icon}
          size=${this.size}
          label=${e.label}
          ?active=${i}
          data-active=${i}
          data-testid="tab-${e.label?.toLowerCase()}"
        ></wui-tab-item>
      `})}onTabClick(e){this.activeTab=e,this.onTabChange(e)}};N.styles=[B.ET,B.ZM,M],wui_tabs_decorate([(0,n.Cb)({type:Array})],N.prototype,"tabs",void 0),wui_tabs_decorate([(0,n.Cb)()],N.prototype,"onTabChange",void 0),wui_tabs_decorate([(0,n.Cb)()],N.prototype,"size",void 0),wui_tabs_decorate([(0,n.SB)()],N.prototype,"activeTab",void 0),N=wui_tabs_decorate([(0,I.M)("wui-tabs")],N);var w3m_connecting_header_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let D=class extends r.oi{constructor(){super(...arguments),this.platformTabs=[],this.unsubscribe=[],this.platforms=[],this.onSelectPlatfrom=void 0}disconnectCallback(){this.unsubscribe.forEach(e=>e())}render(){let e=this.generateTabs();return r.dy`
      <wui-flex justifyContent="center" .padding=${["0","0","4","0"]}>
        <wui-tabs .tabs=${e} .onTabChange=${this.onTabChange.bind(this)}></wui-tabs>
      </wui-flex>
    `}generateTabs(){let e=this.platforms.map(e=>"browser"===e?{label:"Browser",icon:"extension",platform:"browser"}:"mobile"===e?{label:"Mobile",icon:"mobile",platform:"mobile"}:"qrcode"===e?{label:"Mobile",icon:"mobile",platform:"qrcode"}:"web"===e?{label:"Webapp",icon:"browser",platform:"web"}:"desktop"===e?{label:"Desktop",icon:"desktop",platform:"desktop"}:{label:"Browser",icon:"extension",platform:"unsupported"});return this.platformTabs=e.map(({platform:e})=>e),e}onTabChange(e){let t=this.platformTabs[e];t&&this.onSelectPlatfrom?.(t)}};w3m_connecting_header_decorate([(0,n.Cb)({type:Array})],D.prototype,"platforms",void 0),w3m_connecting_header_decorate([(0,n.Cb)()],D.prototype,"onSelectPlatfrom",void 0),D=w3m_connecting_header_decorate([(0,d.Mo)("w3m-connecting-header")],D);var z=i(20428);i(49335),i(16120),i(528),i(3266);var U=P.iv`
  :host {
    display: block;
    width: 100px;
    height: 100px;
  }

  svg {
    width: 100px;
    height: 100px;
  }

  rect {
    fill: none;
    stroke: ${e=>e.colors.accent100};
    stroke-width: 3px;
    stroke-linecap: round;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`,wui_loading_thumbnail_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let q=class extends r.oi{constructor(){super(...arguments),this.radius=36}render(){return this.svgLoaderTemplate()}svgLoaderTemplate(){let e=this.radius>50?50:this.radius,t=36-e;return r.dy`
      <svg viewBox="0 0 110 110" width="110" height="110">
        <rect
          x="2"
          y="2"
          width="106"
          height="106"
          rx=${e}
          stroke-dasharray="${116+t} ${245+t}"
          stroke-dashoffset=${360+1.75*t}
        />
      </svg>
    `}};q.styles=[B.ET,U],wui_loading_thumbnail_decorate([(0,n.Cb)({type:Number})],q.prototype,"radius",void 0),q=wui_loading_thumbnail_decorate([(0,I.M)("wui-loading-thumbnail")],q),i(4745),i(81919),i(2119),i(68507);var F=P.iv`
  wui-flex {
    width: 100%;
    height: 52px;
    box-sizing: border-box;
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[5]};
    padding-left: ${({spacing:e})=>e[3]};
    padding-right: ${({spacing:e})=>e[3]};
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: ${({spacing:e})=>e[6]};
  }

  wui-text {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  wui-icon {
    width: 12px;
    height: 12px;
  }
`,wui_cta_button_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let H=class extends r.oi{constructor(){super(...arguments),this.disabled=!1,this.label="",this.buttonLabel=""}render(){return r.dy`
      <wui-flex justifyContent="space-between" alignItems="center">
        <wui-text variant="lg-regular" color="inherit">${this.label}</wui-text>
        <wui-button variant="accent-secondary" size="sm">
          ${this.buttonLabel}
          <wui-icon name="chevronRight" color="inherit" size="inherit" slot="iconRight"></wui-icon>
        </wui-button>
      </wui-flex>
    `}};H.styles=[B.ET,B.ZM,F],wui_cta_button_decorate([(0,n.Cb)({type:Boolean})],H.prototype,"disabled",void 0),wui_cta_button_decorate([(0,n.Cb)()],H.prototype,"label",void 0),wui_cta_button_decorate([(0,n.Cb)()],H.prototype,"buttonLabel",void 0),H=wui_cta_button_decorate([(0,I.M)("wui-cta-button")],H);var K=d.iv`
  :host {
    display: block;
    padding: 0 ${({spacing:e})=>e["5"]} ${({spacing:e})=>e["5"]};
  }
`,w3m_mobile_download_links_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let V=class extends r.oi{constructor(){super(...arguments),this.wallet=void 0}render(){if(!this.wallet)return this.style.display="none",null;let{name:e,app_store:t,play_store:i,chrome_store:n,homepage:l}=this.wallet,s=a.j.isMobile(),c=a.j.isIos(),u=a.j.isAndroid(),h=[t,i,l,n].filter(Boolean).length>1,p=d.Hg.getTruncateString({string:e,charsStart:12,charsEnd:0,truncate:"end"});return h&&!s?r.dy`
        <wui-cta-button
          label=${`Don't have ${p}?`}
          buttonLabel="Get"
          @click=${()=>m.RouterController.push("Downloads",{wallet:this.wallet})}
        ></wui-cta-button>
      `:!h&&l?r.dy`
        <wui-cta-button
          label=${`Don't have ${p}?`}
          buttonLabel="Get"
          @click=${this.onHomePage.bind(this)}
        ></wui-cta-button>
      `:t&&c?r.dy`
        <wui-cta-button
          label=${`Don't have ${p}?`}
          buttonLabel="Get"
          @click=${this.onAppStore.bind(this)}
        ></wui-cta-button>
      `:i&&u?r.dy`
        <wui-cta-button
          label=${`Don't have ${p}?`}
          buttonLabel="Get"
          @click=${this.onPlayStore.bind(this)}
        ></wui-cta-button>
      `:(this.style.display="none",null)}onAppStore(){this.wallet?.app_store&&a.j.openHref(this.wallet.app_store,"_blank")}onPlayStore(){this.wallet?.play_store&&a.j.openHref(this.wallet.play_store,"_blank")}onHomePage(){this.wallet?.homepage&&a.j.openHref(this.wallet.homepage,"_blank")}};V.styles=[K],w3m_mobile_download_links_decorate([(0,n.Cb)({type:Object})],V.prototype,"wallet",void 0),V=w3m_mobile_download_links_decorate([(0,d.Mo)("w3m-mobile-download-links")],V);var Y=d.iv`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-wallet-image {
    width: 56px;
    height: 56px;
  }

  wui-loading-thumbnail {
    position: absolute;
  }

  wui-icon-box {
    position: absolute;
    right: calc(${({spacing:e})=>e["1"]} * -1);
    bottom: calc(${({spacing:e})=>e["1"]} * -1);
    opacity: 0;
    transform: scale(0.5);
    transition-property: opacity, transform;
    transition-duration: ${({durations:e})=>e.lg};
    transition-timing-function: ${({easings:e})=>e["ease-out-power-2"]};
    will-change: opacity, transform;
  }

  wui-text[align='center'] {
    width: 100%;
    padding: 0px ${({spacing:e})=>e["4"]};
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms ${({easings:e})=>e["ease-out-power-2"]} both;
  }

  [data-retry='false'] wui-link {
    display: none;
  }

  [data-retry='true'] wui-link {
    display: block;
    opacity: 1;
  }

  w3m-mobile-download-links {
    padding: 0px;
    width: 100%;
  }
`,w3m_connecting_widget_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let W3mConnectingWidget=class W3mConnectingWidget extends r.oi{constructor(){super(),this.wallet=m.RouterController.state.data?.wallet,this.connector=m.RouterController.state.data?.connector,this.timeout=void 0,this.secondaryBtnIcon="refresh",this.onConnect=void 0,this.onRender=void 0,this.onAutoConnect=void 0,this.isWalletConnect=!0,this.unsubscribe=[],this.imageSrc=_.f.getConnectorImage(this.connector)??_.f.getWalletImage(this.wallet),this.name=this.wallet?.name??this.connector?.name??"Wallet",this.isRetrying=!1,this.uri=g.ConnectionController.state.wcUri,this.error=g.ConnectionController.state.wcError,this.ready=!1,this.showRetry=!1,this.label=void 0,this.secondaryBtnLabel="Try again",this.secondaryLabel="Accept connection request in the wallet",this.isLoading=!1,this.isMobile=!1,this.onRetry=void 0,this.unsubscribe.push(...[g.ConnectionController.subscribeKey("wcUri",e=>{this.uri=e,this.isRetrying&&this.onRetry&&(this.isRetrying=!1,this.onConnect?.())}),g.ConnectionController.subscribeKey("wcError",e=>this.error=e)]),(a.j.isTelegram()||a.j.isSafari())&&a.j.isIos()&&g.ConnectionController.state.wcUri&&this.onConnect?.()}firstUpdated(){this.onAutoConnect?.(),this.showRetry=!this.onAutoConnect}disconnectedCallback(){this.unsubscribe.forEach(e=>e()),g.ConnectionController.setWcError(!1),clearTimeout(this.timeout)}render(){this.onRender?.(),this.onShowRetry();let e=this.error?"Connection can be declined if a previous request is still active":this.secondaryLabel,t="";return this.label?t=this.label:(t=`Continue in ${this.name}`,this.error&&(t="Connection declined")),r.dy`
      <wui-flex
        data-error=${(0,u.o)(this.error)}
        data-retry=${this.showRetry}
        flexDirection="column"
        alignItems="center"
        .padding=${["10","5","5","5"]}
        gap="6"
      >
        <wui-flex gap="2" justifyContent="center" alignItems="center">
          <wui-wallet-image size="lg" imageSrc=${(0,u.o)(this.imageSrc)}></wui-wallet-image>

          ${this.error?null:this.loaderTemplate()}

          <wui-icon-box
            color="error"
            icon="close"
            size="sm"
            border
            borderColor="wui-color-bg-125"
          ></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="6"> <wui-flex
          flexDirection="column"
          alignItems="center"
          gap="2"
          .padding=${["2","0","0","0"]}
        >
          <wui-text align="center" variant="lg-medium" color=${this.error?"error":"primary"}>
            ${t}
          </wui-text>
          <wui-text align="center" variant="lg-regular" color="secondary">${e}</wui-text>
        </wui-flex>

        ${this.secondaryBtnLabel?r.dy`
                <wui-button
                  variant="neutral-secondary"
                  size="md"
                  ?disabled=${this.isRetrying||this.isLoading}
                  @click=${this.onTryAgain.bind(this)}
                  data-testid="w3m-connecting-widget-secondary-button"
                >
                  <wui-icon
                    color="inherit"
                    slot="iconLeft"
                    name=${this.secondaryBtnIcon}
                  ></wui-icon>
                  ${this.secondaryBtnLabel}
                </wui-button>
              `:null}
      </wui-flex>

      ${this.isWalletConnect?r.dy`
              <wui-flex .padding=${["0","5","5","5"]} justifyContent="center">
                <wui-link
                  @click=${this.onCopyUri}
                  variant="secondary"
                  icon="copy"
                  data-testid="wui-link-copy"
                >
                  Copy link
                </wui-link>
              </wui-flex>
            `:null}

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links></wui-flex>
      </wui-flex>
    `}onShowRetry(){if(this.error&&!this.showRetry){this.showRetry=!0;let e=this.shadowRoot?.querySelector("wui-button");e?.animate([{opacity:0},{opacity:1}],{fill:"forwards",easing:"ease"})}}onTryAgain(){g.ConnectionController.setWcError(!1),this.onRetry?(this.isRetrying=!0,this.onRetry?.()):this.onConnect?.()}loaderTemplate(){let e=z.ThemeController.state.themeVariables["--w3m-border-radius-master"],t=e?parseInt(e.replace("px",""),10):4;return r.dy`<wui-loading-thumbnail radius=${9*t}></wui-loading-thumbnail>`}onCopyUri(){try{this.uri&&(a.j.copyToClopboard(this.uri),E.SnackController.showSuccess("Link copied"))}catch{E.SnackController.showError("Failed to copy")}}};W3mConnectingWidget.styles=Y,w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"isRetrying",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"uri",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"error",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"ready",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"showRetry",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"label",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"secondaryBtnLabel",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"secondaryLabel",void 0),w3m_connecting_widget_decorate([(0,n.SB)()],W3mConnectingWidget.prototype,"isLoading",void 0),w3m_connecting_widget_decorate([(0,n.Cb)({type:Boolean})],W3mConnectingWidget.prototype,"isMobile",void 0),w3m_connecting_widget_decorate([(0,n.Cb)()],W3mConnectingWidget.prototype,"onRetry",void 0);let X=class extends W3mConnectingWidget{constructor(){if(super(),!this.wallet)throw Error("w3m-connecting-wc-browser: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onAutoConnect=this.onConnectProxy.bind(this),w.X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:m.RouterController.state.view}})}async onConnectProxy(){try{this.error=!1;let{connectors:e}=p.ConnectorController.state,t=e.find(e=>"ANNOUNCED"===e.type&&e.info?.rdns===this.wallet?.rdns||"INJECTED"===e.type||e.name===this.wallet?.name);if(t)await g.ConnectionController.connectExternal(t,t.chain);else throw Error("w3m-connecting-wc-browser: No connector found");S.I.close(),w.X.sendEvent({type:"track",event:"CONNECT_SUCCESS",properties:{method:"browser",name:this.wallet?.name||"Unknown",view:m.RouterController.state.view,walletRank:this.wallet?.order}})}catch(t){let e=t instanceof T.g&&t.originalName===k.jD.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST;e?w.X.sendEvent({type:"track",event:"USER_REJECTED",properties:{message:t.message}}):w.X.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:t?.message??"Unknown"}}),this.error=!0}}};X=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l}([(0,d.Mo)("w3m-connecting-wc-browser")],X);let J=class extends W3mConnectingWidget{constructor(){if(super(),!this.wallet)throw Error("w3m-connecting-wc-desktop: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onRender=this.onRenderProxy.bind(this),w.X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"desktop",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:m.RouterController.state.view}})}onRenderProxy(){!this.ready&&this.uri&&(this.ready=!0,this.onConnect?.())}onConnectProxy(){if(this.wallet?.desktop_link&&this.uri)try{this.error=!1;let{desktop_link:e,name:t}=this.wallet,{redirect:i,href:r}=a.j.formatNativeUrl(e,this.uri);g.ConnectionController.setWcLinking({name:t,href:r}),g.ConnectionController.setRecentWallet(this.wallet),a.j.openHref(i,"_blank")}catch{this.error=!0}}};J=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l}([(0,d.Mo)("w3m-connecting-wc-desktop")],J);var Q=i(75053),w3m_connecting_wc_mobile_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let G=class extends W3mConnectingWidget{constructor(){if(super(),this.btnLabelTimeout=void 0,this.redirectDeeplink=void 0,this.redirectUniversalLink=void 0,this.target=void 0,this.preferUniversalLinks=l.OptionsController.state.experimental_preferUniversalLinks,this.isLoading=!0,this.onConnect=()=>{if(this.wallet?.mobile_link&&this.uri)try{this.error=!1;let{mobile_link:e,link_mode:t,name:i}=this.wallet,{redirect:r,redirectUniversalLink:n,href:l}=a.j.formatNativeUrl(e,this.uri,t);this.redirectDeeplink=r,this.redirectUniversalLink=n,this.target=a.j.isIframe()?"_top":"_self",g.ConnectionController.setWcLinking({name:i,href:l}),g.ConnectionController.setRecentWallet(this.wallet),this.preferUniversalLinks&&this.redirectUniversalLink?a.j.openHref(this.redirectUniversalLink,this.target):a.j.openHref(this.redirectDeeplink,this.target)}catch(e){w.X.sendEvent({type:"track",event:"CONNECT_PROXY_ERROR",properties:{message:e instanceof Error?e.message:"Error parsing the deeplink",uri:this.uri,mobile_link:this.wallet.mobile_link,name:this.wallet.name}}),this.error=!0}},!this.wallet)throw Error("w3m-connecting-wc-mobile: No wallet provided");this.secondaryBtnLabel="Open",this.secondaryLabel=Q.bq.CONNECT_LABELS.MOBILE,this.secondaryBtnIcon="externalLink",this.onHandleURI(),this.unsubscribe.push(g.ConnectionController.subscribeKey("wcUri",()=>{this.onHandleURI()})),w.X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"mobile",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:m.RouterController.state.view}})}disconnectedCallback(){super.disconnectedCallback(),clearTimeout(this.btnLabelTimeout)}onHandleURI(){this.isLoading=!this.uri,!this.ready&&this.uri&&(this.ready=!0,this.onConnect?.())}onTryAgain(){g.ConnectionController.setWcError(!1),this.onConnect?.()}};w3m_connecting_wc_mobile_decorate([(0,n.SB)()],G.prototype,"redirectDeeplink",void 0),w3m_connecting_wc_mobile_decorate([(0,n.SB)()],G.prototype,"redirectUniversalLink",void 0),w3m_connecting_wc_mobile_decorate([(0,n.SB)()],G.prototype,"target",void 0),w3m_connecting_wc_mobile_decorate([(0,n.SB)()],G.prototype,"preferUniversalLinks",void 0),w3m_connecting_wc_mobile_decorate([(0,n.SB)()],G.prototype,"isLoading",void 0),G=w3m_connecting_wc_mobile_decorate([(0,d.Mo)("w3m-connecting-wc-mobile")],G),i(93193);var Z=i(92592);function isAdjecentDots(e,t,i){return e!==t&&(e-t<0?t-e:e-t)<=i+.1}let ee={generate({uri:e,size:t,logoSize:i,padding:n=8,dotColor:a="var(--apkt-colors-black)"}){let l=[],s=function(e,t){let i=Array.prototype.slice.call(Z.create(e,{errorCorrectionLevel:"Q"}).modules.data,0),r=Math.sqrt(i.length);return i.reduce((e,t,i)=>(i%r==0?e.push([t]):e[e.length-1].push(t))&&e,[])}(e,0),c=(t-2*n)/s.length,d=[{x:0,y:0},{x:1,y:0},{x:0,y:1}];d.forEach(({x:e,y:t})=>{let i=(s.length-7)*c*e+n,u=(s.length-7)*c*t+n;for(let e=0;e<d.length;e+=1){let t=c*(7-2*e);l.push(r.YP`
            <rect
              fill=${2===e?"var(--apkt-colors-black)":"var(--apkt-colors-white)"}
              width=${0===e?t-10:t}
              rx= ${0===e?(t-10)*.45:.45*t}
              ry= ${0===e?(t-10)*.45:.45*t}
              stroke=${a}
              stroke-width=${0===e?10:0}
              height=${0===e?t-10:t}
              x= ${0===e?u+c*e+5:u+c*e}
              y= ${0===e?i+c*e+5:i+c*e}
            />
          `)}});let u=Math.floor((i+25)/c),h=s.length/2-u/2,p=s.length/2+u/2-1,g=[];s.forEach((e,t)=>{e.forEach((e,i)=>{if(s[t][i]&&!(t<7&&i<7||t>s.length-8&&i<7||t<7&&i>s.length-8)&&!(t>h&&t<p&&i>h&&i<p)){let e=t*c+c/2+n,r=i*c+c/2+n;g.push([e,r])}})});let w={};return g.forEach(([e,t])=>{w[e]?w[e]?.push(t):w[e]=[t]}),Object.entries(w).map(([e,t])=>{let i=t.filter(e=>t.every(t=>!isAdjecentDots(e,t,c)));return[Number(e),i]}).forEach(([e,t])=>{t.forEach(t=>{l.push(r.YP`<circle cx=${e} cy=${t} fill=${a} r=${c/2.5} />`)})}),Object.entries(w).filter(([e,t])=>t.length>1).map(([e,t])=>{let i=t.filter(e=>t.some(t=>isAdjecentDots(e,t,c)));return[Number(e),i]}).map(([e,t])=>{t.sort((e,t)=>e<t?-1:1);let i=[];for(let e of t){let t=i.find(t=>t.some(t=>isAdjecentDots(e,t,c)));t?t.push(e):i.push([e])}return[e,i.map(e=>[e[0],e[e.length-1]])]}).forEach(([e,t])=>{t.forEach(([t,i])=>{l.push(r.YP`
              <line
                x1=${e}
                x2=${e}
                y1=${t}
                y2=${i}
                stroke=${a}
                stroke-width=${c/1.25}
                stroke-linecap="round"
              />
            `)})}),l}};var et=P.iv`
  :host {
    position: relative;
    user-select: none;
    display: block;
    overflow: hidden;
    aspect-ratio: 1 / 1;
    width: 100%;
    height: 100%;
    background-color: ${({colors:e})=>e.white};
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
  }

  :host {
    border-radius: ${({borderRadius:e})=>e[4]};
    display: flex;
    align-items: center;
    justify-content: center;
  }

  :host([data-clear='true']) > wui-icon {
    display: none;
  }

  svg:first-child,
  wui-image,
  wui-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateY(-50%) translateX(-50%);
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    box-shadow: inset 0 0 0 4px ${({tokens:e})=>e.theme.backgroundPrimary};
    border-radius: ${({borderRadius:e})=>e[6]};
  }

  wui-image {
    width: 25%;
    height: 25%;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  wui-icon {
    width: 100%;
    height: 100%;
    color: #3396ff !important;
    transform: translateY(-50%) translateX(-50%) scale(0.25);
  }

  wui-icon > svg {
    width: inherit;
    height: inherit;
  }
`,wui_qr_code_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let ei=class extends r.oi{constructor(){super(...arguments),this.uri="",this.size=500,this.theme="dark",this.imageSrc=void 0,this.alt=void 0,this.arenaClear=void 0,this.farcaster=void 0}render(){return this.dataset.theme=this.theme,this.dataset.clear=String(this.arenaClear),r.dy`<wui-flex
      alignItems="center"
      justifyContent="center"
      class="wui-qr-code"
      direction="column"
      gap="4"
      width="100%"
      style="height: 100%"
    >
      ${this.templateVisual()} ${this.templateSvg()}
    </wui-flex>`}templateSvg(){return r.YP`
      <svg viewBox="0 0 ${this.size} ${this.size}" width="100%" height="100%">
        ${ee.generate({uri:this.uri,size:this.size,logoSize:this.arenaClear?0:this.size/4})}
      </svg>
    `}templateVisual(){return this.imageSrc?r.dy`<wui-image src=${this.imageSrc} alt=${this.alt??"logo"}></wui-image>`:this.farcaster?r.dy`<wui-icon
        class="farcaster"
        size="inherit"
        color="inherit"
        name="farcaster"
      ></wui-icon>`:r.dy`<wui-icon size="inherit" color="inherit" name="walletConnect"></wui-icon>`}};ei.styles=[B.ET,et],wui_qr_code_decorate([(0,n.Cb)()],ei.prototype,"uri",void 0),wui_qr_code_decorate([(0,n.Cb)({type:Number})],ei.prototype,"size",void 0),wui_qr_code_decorate([(0,n.Cb)()],ei.prototype,"theme",void 0),wui_qr_code_decorate([(0,n.Cb)()],ei.prototype,"imageSrc",void 0),wui_qr_code_decorate([(0,n.Cb)()],ei.prototype,"alt",void 0),wui_qr_code_decorate([(0,n.Cb)({type:Boolean})],ei.prototype,"arenaClear",void 0),wui_qr_code_decorate([(0,n.Cb)({type:Boolean})],ei.prototype,"farcaster",void 0),ei=wui_qr_code_decorate([(0,I.M)("wui-qr-code")],ei);var eo=P.iv`
  :host {
    display: block;
    background: linear-gradient(
      90deg,
      ${({tokens:e})=>e.theme.foregroundSecondary} 0%,
      ${({tokens:e})=>e.theme.foregroundTertiary} 50%,
      ${({tokens:e})=>e.theme.foregroundSecondary} 100%
    );
    background-size: 200% 100%;
    animation: shimmer 1s ease-in-out infinite;
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  :host([data-rounded='true']) {
    border-radius: ${({borderRadius:e})=>e[16]};
  }

  @keyframes shimmer {
    0% {
      background-position: 200% 0;
    }
    100% {
      background-position: -200% 0;
    }
  }
`,wui_shimmer_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let er=class extends r.oi{constructor(){super(...arguments),this.width="",this.height="",this.variant="default",this.rounded=!1}render(){return this.style.cssText=`
      width: ${this.width};
      height: ${this.height};
    `,this.dataset.rounded=this.rounded?"true":"false",r.dy`<slot></slot>`}};er.styles=[eo],wui_shimmer_decorate([(0,n.Cb)()],er.prototype,"width",void 0),wui_shimmer_decorate([(0,n.Cb)()],er.prototype,"height",void 0),wui_shimmer_decorate([(0,n.Cb)()],er.prototype,"variant",void 0),wui_shimmer_decorate([(0,n.Cb)({type:Boolean})],er.prototype,"rounded",void 0),er=wui_shimmer_decorate([(0,I.M)("wui-shimmer")],er),i(79786);var en=d.iv`
  wui-shimmer {
    width: 100%;
    aspect-ratio: 1 / 1;
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-qr-code {
    opacity: 0;
    animation-duration: ${({durations:e})=>e.xl};
    animation-timing-function: ${({easings:e})=>e["ease-out-power-2"]};
    animation-name: fade-in;
    animation-fill-mode: forwards;
  }

  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
`,w3m_connecting_wc_qrcode_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let ea=class extends W3mConnectingWidget{constructor(){super(),this.basic=!1}firstUpdated(){this.basic||w.X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet?.name??"WalletConnect",platform:"qrcode",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:m.RouterController.state.view}})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.forEach(e=>e())}render(){return this.onRenderProxy(),r.dy`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["0","5","5","5"]}
        gap="5"
      >
        <wui-shimmer width="100%"> ${this.qrCodeTemplate()} </wui-shimmer>
        <wui-text variant="lg-medium" color="primary"> Scan this QR Code with your phone </wui-text>
        ${this.copyTemplate()}
      </wui-flex>
      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}onRenderProxy(){!this.ready&&this.uri&&(this.ready=!0)}qrCodeTemplate(){if(!this.uri||!this.ready)return null;let e=this.wallet?this.wallet.name:void 0;return g.ConnectionController.setWcLinking(void 0),g.ConnectionController.setRecentWallet(this.wallet),r.dy` <wui-qr-code
      theme=${z.ThemeController.state.themeMode}
      uri=${this.uri}
      imageSrc=${(0,u.o)(_.f.getWalletImage(this.wallet))}
      color=${(0,u.o)(z.ThemeController.state.themeVariables["--w3m-qr-color"])}
      alt=${(0,u.o)(e)}
      data-testid="wui-qr-code"
    ></wui-qr-code>`}copyTemplate(){let e=!this.uri||!this.ready;return r.dy`<wui-button
      .disabled=${e}
      @click=${this.onCopyUri}
      variant="neutral-secondary"
      size="sm"
      data-testid="copy-wc2-uri"
    >
      Copy link
      <wui-icon size="sm" color="inherit" name="copy" slot="iconRight"></wui-icon>
    </wui-button>`}};ea.styles=en,w3m_connecting_wc_qrcode_decorate([(0,n.Cb)({type:Boolean})],ea.prototype,"basic",void 0),ea=w3m_connecting_wc_qrcode_decorate([(0,d.Mo)("w3m-connecting-wc-qrcode")],ea);let el=class extends r.oi{constructor(){if(super(),this.wallet=m.RouterController.state.data?.wallet,!this.wallet)throw Error("w3m-connecting-wc-unsupported: No wallet provided");w.X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:m.RouterController.state.view}})}render(){return r.dy`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["10","5","5","5"]}
        gap="5"
      >
        <wui-wallet-image
          size="lg"
          imageSrc=${(0,u.o)(_.f.getWalletImage(this.wallet))}
        ></wui-wallet-image>

        <wui-text variant="md-regular" color="primary">Not Detected</wui-text>
      </wui-flex>

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}};el=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l}([(0,d.Mo)("w3m-connecting-wc-unsupported")],el);var w3m_connecting_wc_web_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let es=class extends W3mConnectingWidget{constructor(){if(super(),this.isLoading=!0,!this.wallet)throw Error("w3m-connecting-wc-web: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.secondaryBtnLabel="Open",this.secondaryLabel=Q.bq.CONNECT_LABELS.MOBILE,this.secondaryBtnIcon="externalLink",this.updateLoadingState(),this.unsubscribe.push(g.ConnectionController.subscribeKey("wcUri",()=>{this.updateLoadingState()})),w.X.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"web",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:m.RouterController.state.view}})}updateLoadingState(){this.isLoading=!this.uri}onConnectProxy(){if(this.wallet?.webapp_link&&this.uri)try{this.error=!1;let{webapp_link:e,name:t}=this.wallet,{redirect:i,href:r}=a.j.formatUniversalUrl(e,this.uri);g.ConnectionController.setWcLinking({name:t,href:r}),g.ConnectionController.setRecentWallet(this.wallet),a.j.openHref(i,"_blank")}catch{this.error=!0}}};w3m_connecting_wc_web_decorate([(0,n.SB)()],es.prototype,"isLoading",void 0),es=w3m_connecting_wc_web_decorate([(0,d.Mo)("w3m-connecting-wc-web")],es);var ec=d.iv`
  :host([data-mobile-fullscreen='true']) {
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  :host([data-mobile-fullscreen='true']) wui-ux-by-reown {
    margin-top: auto;
  }
`,w3m_connecting_wc_view_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let ed=class extends r.oi{constructor(){super(),this.wallet=m.RouterController.state.data?.wallet,this.unsubscribe=[],this.platform=void 0,this.platforms=[],this.isSiwxEnabled=!!l.OptionsController.state.siwx,this.remoteFeatures=l.OptionsController.state.remoteFeatures,this.displayBranding=!0,this.basic=!1,this.determinePlatforms(),this.initializeConnection(),this.unsubscribe.push(l.OptionsController.subscribeKey("remoteFeatures",e=>this.remoteFeatures=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return l.OptionsController.state.enableMobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),r.dy`
      ${this.headerTemplate()}
      <div class="platform-container">${this.platformTemplate()}</div>
      ${this.reownBrandingTemplate()}
    `}reownBrandingTemplate(){return this.remoteFeatures?.reownBranding&&this.displayBranding?r.dy`<wui-ux-by-reown></wui-ux-by-reown>`:null}async initializeConnection(e=!1){if("browser"!==this.platform&&(!l.OptionsController.state.manualWCControl||e))try{let{wcPairingExpiry:t,status:i}=g.ConnectionController.state,{redirectView:r}=m.RouterController.state.data??{};if(e||l.OptionsController.state.enableEmbedded||a.j.isPairingExpired(t)||"connecting"===i){let e=g.ConnectionController.getConnections(R.R.state.activeChain),t=this.remoteFeatures?.multiWallet,i=e.length>0;await g.ConnectionController.connectWalletConnect({cache:"never"}),this.isSiwxEnabled||(i&&t?(m.RouterController.replace("ProfileWallets"),E.SnackController.showSuccess("New Wallet Added")):r?m.RouterController.replace(r):S.I.close())}}catch(t){if(t instanceof Error&&t.message.includes("An error occurred when attempting to switch chain")&&!l.OptionsController.state.enableNetworkSwitch&&R.R.state.activeChain){R.R.setActiveCaipNetwork(A.f.getUnsupportedNetwork(`${R.R.state.activeChain}:${R.R.state.activeCaipNetwork?.id}`)),R.R.showUnsupportedChainUI();return}let e=t instanceof T.g&&t.originalName===k.jD.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST;e?w.X.sendEvent({type:"track",event:"USER_REJECTED",properties:{message:t.message}}):w.X.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:t?.message??"Unknown"}}),g.ConnectionController.setWcError(!0),E.SnackController.showError(t.message??"Connection error"),g.ConnectionController.resetWcConnection(),m.RouterController.goBack()}}determinePlatforms(){if(!this.wallet){this.platforms.push("qrcode"),this.platform="qrcode";return}if(this.platform)return;let{mobile_link:e,desktop_link:t,webapp_link:i,injected:r,rdns:n}=this.wallet,s=r?.map(({injected_id:e})=>e).filter(Boolean),c=[...n?[n]:s??[]],d=!l.OptionsController.state.isUniversalProvider&&c.length,u=g.ConnectionController.checkInstalled(c),h=d&&u,p=t&&!a.j.isMobile();h&&!R.R.state.noAdapters&&this.platforms.push("browser"),e&&this.platforms.push(a.j.isMobile()?"mobile":"qrcode"),i&&this.platforms.push("web"),p&&this.platforms.push("desktop"),h||!d||R.R.state.noAdapters||this.platforms.push("unsupported"),this.platform=this.platforms[0]}platformTemplate(){switch(this.platform){case"browser":return r.dy`<w3m-connecting-wc-browser></w3m-connecting-wc-browser>`;case"web":return r.dy`<w3m-connecting-wc-web></w3m-connecting-wc-web>`;case"desktop":return r.dy`
          <w3m-connecting-wc-desktop .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-desktop>
        `;case"mobile":return r.dy`
          <w3m-connecting-wc-mobile isMobile .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-mobile>
        `;case"qrcode":return r.dy`<w3m-connecting-wc-qrcode ?basic=${this.basic}></w3m-connecting-wc-qrcode>`;default:return r.dy`<w3m-connecting-wc-unsupported></w3m-connecting-wc-unsupported>`}}headerTemplate(){let e=this.platforms.length>1;return e?r.dy`
      <w3m-connecting-header
        .platforms=${this.platforms}
        .onSelectPlatfrom=${this.onSelectPlatform.bind(this)}
      >
      </w3m-connecting-header>
    `:null}async onSelectPlatform(e){let t=this.shadowRoot?.querySelector("div");t&&(await t.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.platform=e,t.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}};ed.styles=ec,w3m_connecting_wc_view_decorate([(0,n.SB)()],ed.prototype,"platform",void 0),w3m_connecting_wc_view_decorate([(0,n.SB)()],ed.prototype,"platforms",void 0),w3m_connecting_wc_view_decorate([(0,n.SB)()],ed.prototype,"isSiwxEnabled",void 0),w3m_connecting_wc_view_decorate([(0,n.SB)()],ed.prototype,"remoteFeatures",void 0),w3m_connecting_wc_view_decorate([(0,n.Cb)({type:Boolean})],ed.prototype,"displayBranding",void 0),w3m_connecting_wc_view_decorate([(0,n.Cb)({type:Boolean})],ed.prototype,"basic",void 0),ed=w3m_connecting_wc_view_decorate([(0,d.Mo)("w3m-connecting-wc-view")],ed);var w3m_connecting_wc_basic_view_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eu=class extends r.oi{constructor(){super(),this.unsubscribe=[],this.isMobile=a.j.isMobile(),this.remoteFeatures=l.OptionsController.state.remoteFeatures,this.unsubscribe.push(l.OptionsController.subscribeKey("remoteFeatures",e=>this.remoteFeatures=e))}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){if(this.isMobile){let{featured:e,recommended:t}=s.ApiController.state,{customWallets:i}=l.OptionsController.state,n=c.M.getRecentWallets(),a=e.length||t.length||i?.length||n.length;return r.dy`<wui-flex flexDirection="column" gap="2" .margin=${["1","3","3","3"]}>
        ${a?r.dy`<w3m-connector-list></w3m-connector-list>`:null}
        <w3m-all-wallets-widget></w3m-all-wallets-widget>
      </wui-flex>`}return r.dy`<wui-flex flexDirection="column" .padding=${["0","0","4","0"]}>
        <w3m-connecting-wc-view ?basic=${!0} .displayBranding=${!1}></w3m-connecting-wc-view>
        <wui-flex flexDirection="column" .padding=${["0","3","0","3"]}>
          <w3m-all-wallets-widget></w3m-all-wallets-widget>
        </wui-flex>
      </wui-flex>
      ${this.reownBrandingTemplate()} `}reownBrandingTemplate(){return this.remoteFeatures?.reownBranding?r.dy` <wui-flex flexDirection="column" .padding=${["1","0","1","0"]}>
      <wui-ux-by-reown></wui-ux-by-reown>
    </wui-flex>`:null}};w3m_connecting_wc_basic_view_decorate([(0,n.SB)()],eu.prototype,"isMobile",void 0),w3m_connecting_wc_basic_view_decorate([(0,n.SB)()],eu.prototype,"remoteFeatures",void 0),eu=w3m_connecting_wc_basic_view_decorate([(0,d.Mo)("w3m-connecting-wc-basic-view")],eu);var eh=i(33692);/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let{I:ep}=eh._$LH,directive_helpers_f=e=>void 0===e.strings;var eg=i(50875);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let async_directive_s=(e,t)=>{let i=e._$AN;if(void 0===i)return!1;for(let e of i)e._$AO?.(t,!1),async_directive_s(e,t);return!0},o=e=>{let t,i;do{if(void 0===(t=e._$AM))break;(i=t._$AN).delete(e),e=t}while(0===i?.size)},async_directive_r=e=>{for(let t;t=e._$AM;e=t){let i=t._$AN;if(void 0===i)t._$AN=i=new Set;else if(i.has(e))break;i.add(e),async_directive_c(t)}};function async_directive_h(e){void 0!==this._$AN?(o(this),this._$AM=e,async_directive_r(this)):this._$AM=e}function async_directive_n(e,t=!1,i=0){let r=this._$AH,n=this._$AN;if(void 0!==n&&0!==n.size){if(t){if(Array.isArray(r))for(let e=i;e<r.length;e++)async_directive_s(r[e],!1),o(r[e]);else null!=r&&(async_directive_s(r,!1),o(r))}else async_directive_s(this,e)}}let async_directive_c=e=>{e.type==eg.pX.CHILD&&(e._$AP??=async_directive_n,e._$AQ??=async_directive_h)};let f=class f extends eg.Xe{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,i){super._$AT(e,t,i),async_directive_r(this),this.isConnected=e._$AU}_$AO(e,t=!0){e!==this.isConnected&&(this.isConnected=e,e?this.reconnected?.():this.disconnected?.()),t&&(async_directive_s(this,e),o(this))}setValue(e){if(directive_helpers_f(this._$Ct))this._$Ct._$AI(e,this);else{let t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */let ref_e=()=>new ref_h;let ref_h=class ref_h{};let ew=new WeakMap,ef=(0,eg.XM)(class extends f{render(e){return eh.Ld}update(e,[t]){let i=t!==this.G;return i&&void 0!==this.G&&this.rt(void 0),(i||this.lt!==this.ct)&&(this.G=t,this.ht=e.options?.host,this.rt(this.ct=e.element)),eh.Ld}rt(e){if(this.isConnected||(e=void 0),"function"==typeof this.G){let t=this.ht??globalThis,i=ew.get(t);void 0===i&&(i=new WeakMap,ew.set(t,i)),void 0!==i.get(this.G)&&this.G.call(this.ht,void 0),i.set(this.G,e),void 0!==e&&this.G.call(this.ht,e)}else this.G.value=e}get lt(){return"function"==typeof this.G?ew.get(this.ht??globalThis)?.get(this.G):this.G?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}});var em=P.iv`
  :host {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  label {
    position: relative;
    display: inline-block;
    user-select: none;
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      color ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      border ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      box-shadow ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      width ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      height ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      transform ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      opacity ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, color, border, box-shadow, width, height, transform, opacity;
  }

  input {
    width: 0;
    height: 0;
    opacity: 0;
  }

  span {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: ${({colors:e})=>e.neutrals300};
    border-radius: ${({borderRadius:e})=>e.round};
    border: 1px solid transparent;
    will-change: border;
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      color ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      border ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      box-shadow ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      width ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      height ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]},
      transform ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      opacity ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, color, border, box-shadow, width, height, transform, opacity;
  }

  span:before {
    content: '';
    position: absolute;
    background-color: ${({colors:e})=>e.white};
    border-radius: 50%;
  }

  /* -- Sizes --------------------------------------------------------- */
  label[data-size='lg'] {
    width: 48px;
    height: 32px;
  }

  label[data-size='md'] {
    width: 40px;
    height: 28px;
  }

  label[data-size='sm'] {
    width: 32px;
    height: 22px;
  }

  label[data-size='lg'] > span:before {
    height: 24px;
    width: 24px;
    left: 4px;
    top: 3px;
  }

  label[data-size='md'] > span:before {
    height: 20px;
    width: 20px;
    left: 4px;
    top: 3px;
  }

  label[data-size='sm'] > span:before {
    height: 16px;
    width: 16px;
    left: 3px;
    top: 2px;
  }

  /* -- Focus states --------------------------------------------------- */
  input:focus-visible:not(:checked) + span,
  input:focus:not(:checked) + span {
    border: 1px solid ${({tokens:e})=>e.core.iconAccentPrimary};
    background-color: ${({tokens:e})=>e.theme.textTertiary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  input:focus-visible:checked + span,
  input:focus:checked + span {
    border: 1px solid ${({tokens:e})=>e.core.iconAccentPrimary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  /* -- Checked states --------------------------------------------------- */
  input:checked + span {
    background-color: ${({tokens:e})=>e.core.iconAccentPrimary};
  }

  label[data-size='lg'] > input:checked + span:before {
    transform: translateX(calc(100% - 9px));
  }

  label[data-size='md'] > input:checked + span:before {
    transform: translateX(calc(100% - 9px));
  }

  label[data-size='sm'] > input:checked + span:before {
    transform: translateX(calc(100% - 7px));
  }

  /* -- Hover states ------------------------------------------------------- */
  label:hover > input:not(:checked):not(:disabled) + span {
    background-color: ${({colors:e})=>e.neutrals400};
  }

  label:hover > input:checked:not(:disabled) + span {
    background-color: ${({colors:e})=>e.accent080};
  }

  /* -- Disabled state --------------------------------------------------- */
  label:has(input:disabled) {
    pointer-events: none;
    user-select: none;
  }

  input:not(:checked):disabled + span {
    background-color: ${({colors:e})=>e.neutrals700};
  }

  input:checked:disabled + span {
    background-color: ${({colors:e})=>e.neutrals700};
  }

  input:not(:checked):disabled + span::before {
    background-color: ${({colors:e})=>e.neutrals400};
  }

  input:checked:disabled + span::before {
    background-color: ${({tokens:e})=>e.theme.textTertiary};
  }
`,wui_toggle_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eb=class extends r.oi{constructor(){super(...arguments),this.inputElementRef=ref_e(),this.checked=!1,this.disabled=!1,this.size="md"}render(){return r.dy`
      <label data-size=${this.size}>
        <input
          ${ef(this.inputElementRef)}
          type="checkbox"
          ?checked=${this.checked}
          ?disabled=${this.disabled}
          @change=${this.dispatchChangeEvent.bind(this)}
        />
        <span></span>
      </label>
    `}dispatchChangeEvent(){this.dispatchEvent(new CustomEvent("switchChange",{detail:this.inputElementRef.value?.checked,bubbles:!0,composed:!0}))}};eb.styles=[B.ET,B.ZM,em],wui_toggle_decorate([(0,n.Cb)({type:Boolean})],eb.prototype,"checked",void 0),wui_toggle_decorate([(0,n.Cb)({type:Boolean})],eb.prototype,"disabled",void 0),wui_toggle_decorate([(0,n.Cb)()],eb.prototype,"size",void 0),eb=wui_toggle_decorate([(0,I.M)("wui-toggle")],eb);var ey=P.iv`
  :host {
    height: auto;
  }

  :host > wui-flex {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    column-gap: ${({spacing:e})=>e["2"]};
    padding: ${({spacing:e})=>e["2"]} ${({spacing:e})=>e["3"]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e["4"]};
    box-shadow: inset 0 0 0 1px ${({tokens:e})=>e.theme.foregroundPrimary};
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
    cursor: pointer;
  }

  wui-switch {
    pointer-events: none;
  }
`,wui_certified_switch_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let e_=class extends r.oi{constructor(){super(...arguments),this.checked=!1}render(){return r.dy`
      <wui-flex>
        <wui-icon size="xl" name="walletConnectBrown"></wui-icon>
        <wui-toggle
          ?checked=${this.checked}
          size="sm"
          @switchChange=${this.handleToggleChange.bind(this)}
        ></wui-toggle>
      </wui-flex>
    `}handleToggleChange(e){e.stopPropagation(),this.checked=e.detail,this.dispatchSwitchEvent()}dispatchSwitchEvent(){this.dispatchEvent(new CustomEvent("certifiedSwitchChange",{detail:this.checked,bubbles:!0,composed:!0}))}};e_.styles=[B.ET,B.ZM,ey],wui_certified_switch_decorate([(0,n.Cb)({type:Boolean})],e_.prototype,"checked",void 0),e_=wui_certified_switch_decorate([(0,I.M)("wui-certified-switch")],e_);var ev=P.iv`
  :host {
    position: relative;
    width: 100%;
    display: inline-flex;
    flex-direction: column;
    gap: ${({spacing:e})=>e[3]};
    color: ${({tokens:e})=>e.theme.textPrimary};
    caret-color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  .wui-input-text-container {
    position: relative;
    display: flex;
  }

  input {
    width: 100%;
    border-radius: ${({borderRadius:e})=>e[4]};
    color: inherit;
    background: transparent;
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
    caret-color: ${({tokens:e})=>e.core.textAccentPrimary};
    padding: ${({spacing:e})=>e[3]} ${({spacing:e})=>e[3]}
      ${({spacing:e})=>e[3]} ${({spacing:e})=>e[10]};
    font-size: ${({textSize:e})=>e.large};
    line-height: ${({typography:e})=>e["lg-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["lg-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
  }

  input[data-size='lg'] {
    padding: ${({spacing:e})=>e[4]} ${({spacing:e})=>e[3]}
      ${({spacing:e})=>e[4]} ${({spacing:e})=>e[10]};
  }

  @media (hover: hover) and (pointer: fine) {
    input:hover:enabled {
      border: 1px solid ${({tokens:e})=>e.theme.borderSecondary};
    }
  }

  input:disabled {
    cursor: unset;
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
  }

  input::placeholder {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  input:focus:enabled {
    border: 1px solid ${({tokens:e})=>e.theme.borderSecondary};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    -webkit-box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
    -moz-box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
    box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
  }

  div.wui-input-text-container:has(input:disabled) {
    opacity: 0.5;
  }

  wui-icon.wui-input-text-left-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
    left: ${({spacing:e})=>e[4]};
    color: ${({tokens:e})=>e.theme.iconDefault};
  }

  button.wui-input-text-submit-button {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: ${({spacing:e})=>e[3]};
    width: 24px;
    height: 24px;
    border: none;
    background: transparent;
    border-radius: ${({borderRadius:e})=>e[2]};
    color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  button.wui-input-text-submit-button:disabled {
    opacity: 1;
  }

  button.wui-input-text-submit-button.loading wui-icon {
    animation: spin 1s linear infinite;
  }

  button.wui-input-text-submit-button:hover {
    background: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  input:has(+ .wui-input-text-submit-button) {
    padding-right: ${({spacing:e})=>e[12]};
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  input[type='search']::-webkit-search-decoration,
  input[type='search']::-webkit-search-cancel-button,
  input[type='search']::-webkit-search-results-button,
  input[type='search']::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  /* -- Keyframes --------------------------------------------------- */
  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
`,wui_input_text_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eC=class extends r.oi{constructor(){super(...arguments),this.inputElementRef=ref_e(),this.disabled=!1,this.loading=!1,this.placeholder="",this.type="text",this.value="",this.size="md"}render(){return r.dy` <div class="wui-input-text-container">
        ${this.templateLeftIcon()}
        <input
          data-size=${this.size}
          ${ef(this.inputElementRef)}
          data-testid="wui-input-text"
          type=${this.type}
          enterkeyhint=${(0,u.o)(this.enterKeyHint)}
          ?disabled=${this.disabled}
          placeholder=${this.placeholder}
          @input=${this.dispatchInputChangeEvent.bind(this)}
          @keydown=${this.onKeyDown}
          .value=${this.value||""}
        />
        ${this.templateSubmitButton()}
        <slot class="wui-input-text-slot"></slot>
      </div>
      ${this.templateError()} ${this.templateWarning()}`}templateLeftIcon(){return this.icon?r.dy`<wui-icon
        class="wui-input-text-left-icon"
        size="md"
        data-size=${this.size}
        color="inherit"
        name=${this.icon}
      ></wui-icon>`:null}templateSubmitButton(){return this.onSubmit?r.dy`<button
        class="wui-input-text-submit-button ${this.loading?"loading":""}"
        @click=${this.onSubmit?.bind(this)}
        ?disabled=${this.disabled||this.loading}
      >
        ${this.loading?r.dy`<wui-icon name="spinner" size="md"></wui-icon>`:r.dy`<wui-icon name="chevronRight" size="md"></wui-icon>`}
      </button>`:null}templateError(){return this.errorText?r.dy`<wui-text variant="sm-regular" color="error">${this.errorText}</wui-text>`:null}templateWarning(){return this.warningText?r.dy`<wui-text variant="sm-regular" color="warning">${this.warningText}</wui-text>`:null}dispatchInputChangeEvent(){this.dispatchEvent(new CustomEvent("inputChange",{detail:this.inputElementRef.value?.value,bubbles:!0,composed:!0}))}};eC.styles=[B.ET,B.ZM,ev],wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"icon",void 0),wui_input_text_decorate([(0,n.Cb)({type:Boolean})],eC.prototype,"disabled",void 0),wui_input_text_decorate([(0,n.Cb)({type:Boolean})],eC.prototype,"loading",void 0),wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"placeholder",void 0),wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"type",void 0),wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"value",void 0),wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"errorText",void 0),wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"warningText",void 0),wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"onSubmit",void 0),wui_input_text_decorate([(0,n.Cb)()],eC.prototype,"size",void 0),wui_input_text_decorate([(0,n.Cb)({attribute:!1})],eC.prototype,"onKeyDown",void 0),eC=wui_input_text_decorate([(0,I.M)("wui-input-text")],eC);var ex=P.iv`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }

  wui-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: ${({spacing:e})=>e[3]};
    color: ${({tokens:e})=>e.theme.iconDefault};
    cursor: pointer;
    padding: ${({spacing:e})=>e[2]};
    background-color: transparent;
    border-radius: ${({borderRadius:e})=>e[4]};
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
  }

  @media (hover: hover) {
    wui-icon:hover {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }
`,wui_search_bar_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let e$=class extends r.oi{constructor(){super(...arguments),this.inputComponentRef=ref_e(),this.inputValue=""}render(){return r.dy`
      <wui-input-text
        ${ef(this.inputComponentRef)}
        placeholder="Search wallet"
        icon="search"
        type="search"
        enterKeyHint="search"
        size="sm"
        @inputChange=${this.onInputChange}
      >
        ${this.inputValue?r.dy`<wui-icon
              @click=${this.clearValue}
              color="inherit"
              size="sm"
              name="close"
            ></wui-icon>`:null}
      </wui-input-text>
    `}onInputChange(e){this.inputValue=e.detail||""}clearValue(){let e=this.inputComponentRef.value,t=e?.inputElementRef.value;t&&(t.value="",this.inputValue="",t.focus(),t.dispatchEvent(new Event("input")))}};e$.styles=[B.ET,ex],wui_search_bar_decorate([(0,n.Cb)()],e$.prototype,"inputValue",void 0),e$=wui_search_bar_decorate([(0,I.M)("wui-search-bar")],e$);let ek=r.YP`<svg  viewBox="0 0 48 54" fill="none">
  <path
    d="M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z"
  />
</svg>`;var eR=P.iv`
  :host {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 104px;
    width: 104px;
    row-gap: ${({spacing:e})=>e[2]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[5]};
    position: relative;
  }

  wui-shimmer[data-type='network'] {
    border: none;
    -webkit-clip-path: var(--apkt-path-network);
    clip-path: var(--apkt-path-network);
  }

  svg {
    position: absolute;
    width: 48px;
    height: 54px;
    z-index: 1;
  }

  svg > path {
    stroke: ${({tokens:e})=>e.theme.foregroundSecondary};
    stroke-width: 1px;
  }

  @media (max-width: 350px) {
    :host {
      width: 100%;
    }
  }
`,wui_card_select_loader_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eE=class extends r.oi{constructor(){super(...arguments),this.type="wallet"}render(){return r.dy`
      ${this.shimmerTemplate()}
      <wui-shimmer width="80px" height="20px"></wui-shimmer>
    `}shimmerTemplate(){return"network"===this.type?r.dy` <wui-shimmer data-type=${this.type} width="48px" height="54px"></wui-shimmer>
        ${ek}`:r.dy`<wui-shimmer width="56px" height="56px"></wui-shimmer>`}};eE.styles=[B.ET,B.ZM,eR],wui_card_select_loader_decorate([(0,n.Cb)()],eE.prototype,"type",void 0),eE=wui_card_select_loader_decorate([(0,I.M)("wui-card-select-loader")],eE);var eS=i(94650),eT=r.iv`
  :host {
    display: grid;
    width: inherit;
    height: inherit;
  }
`,wui_grid_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eA=class extends r.oi{render(){return this.style.cssText=`
      grid-template-rows: ${this.gridTemplateRows};
      grid-template-columns: ${this.gridTemplateColumns};
      justify-items: ${this.justifyItems};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      align-content: ${this.alignContent};
      column-gap: ${this.columnGap&&`var(--apkt-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap&&`var(--apkt-spacing-${this.rowGap})`};
      gap: ${this.gap&&`var(--apkt-spacing-${this.gap})`};
      padding-top: ${this.padding&&eS.H.getSpacingStyles(this.padding,0)};
      padding-right: ${this.padding&&eS.H.getSpacingStyles(this.padding,1)};
      padding-bottom: ${this.padding&&eS.H.getSpacingStyles(this.padding,2)};
      padding-left: ${this.padding&&eS.H.getSpacingStyles(this.padding,3)};
      margin-top: ${this.margin&&eS.H.getSpacingStyles(this.margin,0)};
      margin-right: ${this.margin&&eS.H.getSpacingStyles(this.margin,1)};
      margin-bottom: ${this.margin&&eS.H.getSpacingStyles(this.margin,2)};
      margin-left: ${this.margin&&eS.H.getSpacingStyles(this.margin,3)};
    `,r.dy`<slot></slot>`}};eA.styles=[B.ET,eT],wui_grid_decorate([(0,n.Cb)()],eA.prototype,"gridTemplateRows",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"gridTemplateColumns",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"justifyItems",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"alignItems",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"justifyContent",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"alignContent",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"columnGap",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"rowGap",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"gap",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"padding",void 0),wui_grid_decorate([(0,n.Cb)()],eA.prototype,"margin",void 0),eA=wui_grid_decorate([(0,I.M)("wui-grid")],eA);var eB=i(11874),eI=d.iv`
  button {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    width: 104px;
    row-gap: ${({spacing:e})=>e["2"]};
    padding: ${({spacing:e})=>e["3"]} ${({spacing:e})=>e["0"]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: clamp(0px, ${({borderRadius:e})=>e["4"]}, 20px);
    transition:
      color ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-1"]},
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-1"]},
      border-radius ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-1"]};
    will-change: background-color, color, border-radius;
    outline: none;
    border: none;
  }

  button > wui-flex > wui-text {
    color: ${({tokens:e})=>e.theme.textPrimary};
    max-width: 86px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    justify-content: center;
  }

  button > wui-flex > wui-text.certified {
    max-width: 66px;
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button:disabled > wui-flex > wui-text {
    color: ${({tokens:e})=>e.core.glass010};
  }

  [data-selected='true'] {
    background-color: ${({colors:e})=>e.accent020};
  }

  @media (hover: hover) and (pointer: fine) {
    [data-selected='true']:hover:enabled {
      background-color: ${({colors:e})=>e.accent010};
    }
  }

  [data-selected='true']:active:enabled {
    background-color: ${({colors:e})=>e.accent010};
  }

  @media (max-width: 350px) {
    button {
      width: 100%;
    }
  }
`,w3m_all_wallets_list_item_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eP=class extends r.oi{constructor(){super(),this.observer=new IntersectionObserver(()=>void 0),this.visible=!1,this.imageSrc=void 0,this.imageLoading=!1,this.isImpressed=!1,this.explorerId="",this.walletQuery="",this.certified=!1,this.displayIndex=0,this.wallet=void 0,this.observer=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting?(this.visible=!0,this.fetchImageSrc(),this.sendImpressionEvent()):this.visible=!1})},{threshold:.01})}firstUpdated(){this.observer.observe(this)}disconnectedCallback(){this.observer.disconnect()}render(){let e=this.wallet?.badge_type==="certified";return r.dy`
      <button>
        ${this.imageTemplate()}
        <wui-flex flexDirection="row" alignItems="center" justifyContent="center" gap="1">
          <wui-text
            variant="md-regular"
            color="inherit"
            class=${(0,u.o)(e?"certified":void 0)}
            >${this.wallet?.name}</wui-text
          >
          ${e?r.dy`<wui-icon size="sm" name="walletConnectBrown"></wui-icon>`:null}
        </wui-flex>
      </button>
    `}imageTemplate(){return(this.visible||this.imageSrc)&&!this.imageLoading?r.dy`
      <wui-wallet-image
        size="lg"
        imageSrc=${(0,u.o)(this.imageSrc)}
        name=${(0,u.o)(this.wallet?.name)}
        .installed=${this.wallet?.installed??!1}
        badgeSize="sm"
      >
      </wui-wallet-image>
    `:this.shimmerTemplate()}shimmerTemplate(){return r.dy`<wui-shimmer width="56px" height="56px"></wui-shimmer>`}async fetchImageSrc(){this.wallet&&(this.imageSrc=_.f.getWalletImage(this.wallet),this.imageSrc||(this.imageLoading=!0,this.imageSrc=await _.f.fetchWalletImage(this.wallet.image_id),this.imageLoading=!1))}sendImpressionEvent(){this.wallet&&!this.isImpressed&&(this.isImpressed=!0,w.X.sendWalletImpressionEvent({name:this.wallet.name,walletRank:this.wallet.order,explorerId:this.explorerId,view:m.RouterController.state.view,query:this.walletQuery,certified:this.certified,displayIndex:this.displayIndex}))}};eP.styles=eI,w3m_all_wallets_list_item_decorate([(0,n.SB)()],eP.prototype,"visible",void 0),w3m_all_wallets_list_item_decorate([(0,n.SB)()],eP.prototype,"imageSrc",void 0),w3m_all_wallets_list_item_decorate([(0,n.SB)()],eP.prototype,"imageLoading",void 0),w3m_all_wallets_list_item_decorate([(0,n.SB)()],eP.prototype,"isImpressed",void 0),w3m_all_wallets_list_item_decorate([(0,n.Cb)()],eP.prototype,"explorerId",void 0),w3m_all_wallets_list_item_decorate([(0,n.Cb)()],eP.prototype,"walletQuery",void 0),w3m_all_wallets_list_item_decorate([(0,n.Cb)()],eP.prototype,"certified",void 0),w3m_all_wallets_list_item_decorate([(0,n.Cb)()],eP.prototype,"displayIndex",void 0),w3m_all_wallets_list_item_decorate([(0,n.Cb)({type:Object})],eP.prototype,"wallet",void 0),eP=w3m_all_wallets_list_item_decorate([(0,d.Mo)("w3m-all-wallets-list-item")],eP);var ej=d.iv`
  wui-grid {
    max-height: clamp(360px, 400px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  :host([data-mobile-fullscreen='true']) wui-grid {
    max-height: none;
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  w3m-all-wallets-list-item {
    opacity: 0;
    animation-duration: ${({durations:e})=>e.xl};
    animation-timing-function: ${({easings:e})=>e["ease-inout-power-2"]};
    animation-name: fade-in;
    animation-fill-mode: forwards;
  }

  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  wui-loading-spinner {
    padding-top: ${({spacing:e})=>e["4"]};
    padding-bottom: ${({spacing:e})=>e["4"]};
    justify-content: center;
    grid-column: 1 / span 4;
  }
`,w3m_all_wallets_list_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eL="local-paginator",eO=class extends r.oi{constructor(){super(),this.unsubscribe=[],this.paginationObserver=void 0,this.loading=!s.ApiController.state.wallets.length,this.wallets=s.ApiController.state.wallets,this.recommended=s.ApiController.state.recommended,this.featured=s.ApiController.state.featured,this.filteredWallets=s.ApiController.state.filteredWallets,this.mobileFullScreen=l.OptionsController.state.enableMobileFullScreen,this.unsubscribe.push(...[s.ApiController.subscribeKey("wallets",e=>this.wallets=e),s.ApiController.subscribeKey("recommended",e=>this.recommended=e),s.ApiController.subscribeKey("featured",e=>this.featured=e),s.ApiController.subscribeKey("filteredWallets",e=>this.filteredWallets=e)])}firstUpdated(){this.initialFetch(),this.createPaginationObserver()}disconnectedCallback(){this.unsubscribe.forEach(e=>e()),this.paginationObserver?.disconnect()}render(){return this.mobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),r.dy`
      <wui-grid
        data-scroll=${!this.loading}
        .padding=${["0","3","3","3"]}
        gap="2"
        justifyContent="space-between"
      >
        ${this.loading?this.shimmerTemplate(16):this.walletsTemplate()}
        ${this.paginationLoaderTemplate()}
      </wui-grid>
    `}async initialFetch(){this.loading=!0;let e=this.shadowRoot?.querySelector("wui-grid");e&&(await s.ApiController.fetchWalletsByPage({page:1}),await e.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.loading=!1,e.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}shimmerTemplate(e,t){return[...Array(e)].map(()=>r.dy`
        <wui-card-select-loader type="wallet" id=${(0,u.o)(t)}></wui-card-select-loader>
      `)}getWallets(){let e=[...this.featured,...this.recommended];this.filteredWallets?.length>0?e.push(...this.filteredWallets):e.push(...this.wallets);let t=a.j.uniqueBy(e,"id"),i=eB.J.markWalletsAsInstalled(t);return eB.J.markWalletsWithDisplayIndex(i)}walletsTemplate(){let e=this.getWallets();return e.map((e,t)=>r.dy`
        <w3m-all-wallets-list-item
          data-testid="wallet-search-item-${e.id}"
          @click=${()=>this.onConnectWallet(e)}
          .wallet=${e}
          explorerId=${e.id}
          certified=${"certified"===this.badge}
          displayIndex=${t}
        ></w3m-all-wallets-list-item>
      `)}paginationLoaderTemplate(){let{wallets:e,recommended:t,featured:i,count:r,mobileFilteredOutWalletsLength:n}=s.ApiController.state,a=window.innerWidth<352?3:4,l=e.length+t.length,c=Math.ceil(l/a)*a-l+a;return(c-=e.length?i.length%a:0,0===r&&i.length>0)?null:0===r||[...i,...e,...t].length<r-(n??0)?this.shimmerTemplate(c,eL):null}createPaginationObserver(){let e=this.shadowRoot?.querySelector(`#${eL}`);e&&(this.paginationObserver=new IntersectionObserver(([e])=>{if(e?.isIntersecting&&!this.loading){let{page:e,count:t,wallets:i}=s.ApiController.state;i.length<t&&s.ApiController.fetchWalletsByPage({page:e+1})}}),this.paginationObserver.observe(e))}onConnectWallet(e){p.ConnectorController.selectWalletConnector(e)}};eO.styles=ej,w3m_all_wallets_list_decorate([(0,n.SB)()],eO.prototype,"loading",void 0),w3m_all_wallets_list_decorate([(0,n.SB)()],eO.prototype,"wallets",void 0),w3m_all_wallets_list_decorate([(0,n.SB)()],eO.prototype,"recommended",void 0),w3m_all_wallets_list_decorate([(0,n.SB)()],eO.prototype,"featured",void 0),w3m_all_wallets_list_decorate([(0,n.SB)()],eO.prototype,"filteredWallets",void 0),w3m_all_wallets_list_decorate([(0,n.SB)()],eO.prototype,"badge",void 0),w3m_all_wallets_list_decorate([(0,n.SB)()],eO.prototype,"mobileFullScreen",void 0),eO=w3m_all_wallets_list_decorate([(0,d.Mo)("w3m-all-wallets-list")],eO),i(36518);var eW=r.iv`
  wui-grid,
  wui-loading-spinner,
  wui-flex {
    height: 360px;
  }

  wui-grid {
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  :host([data-mobile-fullscreen='true']) wui-grid {
    max-height: none;
    height: auto;
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  wui-loading-spinner {
    justify-content: center;
    align-items: center;
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }
`,w3m_all_wallets_search_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eM=class extends r.oi{constructor(){super(...arguments),this.prevQuery="",this.prevBadge=void 0,this.loading=!0,this.mobileFullScreen=l.OptionsController.state.enableMobileFullScreen,this.query=""}render(){return this.mobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),this.onSearch(),this.loading?r.dy`<wui-loading-spinner color="accent-primary"></wui-loading-spinner>`:this.walletsTemplate()}async onSearch(){(this.query.trim()!==this.prevQuery.trim()||this.badge!==this.prevBadge)&&(this.prevQuery=this.query,this.prevBadge=this.badge,this.loading=!0,await s.ApiController.searchWallet({search:this.query,badge:this.badge}),this.loading=!1)}walletsTemplate(){let{search:e}=s.ApiController.state,t=eB.J.markWalletsAsInstalled(e);return e.length?r.dy`
      <wui-grid
        data-testid="wallet-list"
        .padding=${["0","3","3","3"]}
        rowGap="4"
        columngap="2"
        justifyContent="space-between"
      >
        ${t.map((e,t)=>r.dy`
            <w3m-all-wallets-list-item
              @click=${()=>this.onConnectWallet(e)}
              .wallet=${e}
              data-testid="wallet-search-item-${e.id}"
              explorerId=${e.id}
              certified=${"certified"===this.badge}
              walletQuery=${this.query}
              displayIndex=${t}
            ></w3m-all-wallets-list-item>
          `)}
      </wui-grid>
    `:r.dy`
        <wui-flex
          data-testid="no-wallet-found"
          justifyContent="center"
          alignItems="center"
          gap="3"
          flexDirection="column"
        >
          <wui-icon-box size="lg" color="default" icon="wallet"></wui-icon-box>
          <wui-text data-testid="no-wallet-found-text" color="secondary" variant="md-medium">
            No Wallet found
          </wui-text>
        </wui-flex>
      `}onConnectWallet(e){p.ConnectorController.selectWalletConnector(e)}};eM.styles=eW,w3m_all_wallets_search_decorate([(0,n.SB)()],eM.prototype,"loading",void 0),w3m_all_wallets_search_decorate([(0,n.SB)()],eM.prototype,"mobileFullScreen",void 0),w3m_all_wallets_search_decorate([(0,n.Cb)()],eM.prototype,"query",void 0),w3m_all_wallets_search_decorate([(0,n.Cb)()],eM.prototype,"badge",void 0),eM=w3m_all_wallets_search_decorate([(0,d.Mo)("w3m-all-wallets-search")],eM);var w3m_all_wallets_view_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let eN=class extends r.oi{constructor(){super(...arguments),this.search="",this.badge=void 0,this.onDebouncedSearch=a.j.debounce(e=>{this.search=e})}render(){let e=this.search.length>=2;return r.dy`
      <wui-flex .padding=${["1","3","3","3"]} gap="2" alignItems="center">
        <wui-search-bar @inputChange=${this.onInputChange.bind(this)}></wui-search-bar>
        <wui-certified-switch
          ?checked=${"certified"===this.badge}
          @certifiedSwitchChange=${this.onCertifiedSwitchChange.bind(this)}
          data-testid="wui-certified-switch"
        ></wui-certified-switch>
        ${this.qrButtonTemplate()}
      </wui-flex>
      ${e||this.badge?r.dy`<w3m-all-wallets-search
            query=${this.search}
            .badge=${this.badge}
          ></w3m-all-wallets-search>`:r.dy`<w3m-all-wallets-list .badge=${this.badge}></w3m-all-wallets-list>`}
    `}onInputChange(e){this.onDebouncedSearch(e.detail)}onCertifiedSwitchChange(e){e.detail?(this.badge="certified",E.SnackController.showSvg("Only WalletConnect certified",{icon:"walletConnectBrown",iconColor:"accent-100"})):this.badge=void 0}qrButtonTemplate(){return a.j.isMobile()?r.dy`
        <wui-icon-box
          size="xl"
          iconSize="xl"
          color="accent-primary"
          icon="qrCode"
          border
          borderColor="wui-accent-glass-010"
          @click=${this.onWalletConnectQr.bind(this)}
        ></wui-icon-box>
      `:null}onWalletConnectQr(){m.RouterController.push("ConnectingWalletConnect")}};w3m_all_wallets_view_decorate([(0,n.SB)()],eN.prototype,"search",void 0),w3m_all_wallets_view_decorate([(0,n.SB)()],eN.prototype,"badge",void 0),eN=w3m_all_wallets_view_decorate([(0,d.Mo)("w3m-all-wallets-view")],eN);var eD=P.iv`
  :host {
    width: 100%;
  }

  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    border-radius: ${({borderRadius:e})=>e[4]};
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      scale ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, scale;
  }

  wui-text {
    text-transform: capitalize;
  }

  wui-image {
    color: ${({tokens:e})=>e.theme.textPrimary};
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,wui_list_item_decorate=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l};let ez=class extends r.oi{constructor(){super(...arguments),this.imageSrc="google",this.loading=!1,this.disabled=!1,this.rightIcon=!0,this.rounded=!1,this.fullSize=!1}render(){return this.dataset.rounded=this.rounded?"true":"false",r.dy`
      <button
        ?disabled=${!!this.loading||!!this.disabled}
        data-loading=${this.loading}
        tabindex=${(0,u.o)(this.tabIdx)}
      >
        <wui-flex gap="2" alignItems="center">
          ${this.templateLeftIcon()}
          <wui-flex gap="1">
            <slot></slot>
          </wui-flex>
        </wui-flex>
        ${this.templateRightIcon()}
      </button>
    `}templateLeftIcon(){return this.icon?r.dy`<wui-image
        icon=${this.icon}
        iconColor=${(0,u.o)(this.iconColor)}
        ?boxed=${!0}
        ?rounded=${this.rounded}
      ></wui-image>`:r.dy`<wui-image
      ?boxed=${!0}
      ?rounded=${this.rounded}
      ?fullSize=${this.fullSize}
      src=${this.imageSrc}
    ></wui-image>`}templateRightIcon(){return this.rightIcon?this.loading?r.dy`<wui-loading-spinner size="md" color="accent-primary"></wui-loading-spinner>`:r.dy`<wui-icon name="chevronRight" size="lg" color="default"></wui-icon>`:null}};ez.styles=[B.ET,B.ZM,eD],wui_list_item_decorate([(0,n.Cb)()],ez.prototype,"imageSrc",void 0),wui_list_item_decorate([(0,n.Cb)()],ez.prototype,"icon",void 0),wui_list_item_decorate([(0,n.Cb)()],ez.prototype,"iconColor",void 0),wui_list_item_decorate([(0,n.Cb)({type:Boolean})],ez.prototype,"loading",void 0),wui_list_item_decorate([(0,n.Cb)()],ez.prototype,"tabIdx",void 0),wui_list_item_decorate([(0,n.Cb)({type:Boolean})],ez.prototype,"disabled",void 0),wui_list_item_decorate([(0,n.Cb)({type:Boolean})],ez.prototype,"rightIcon",void 0),wui_list_item_decorate([(0,n.Cb)({type:Boolean})],ez.prototype,"rounded",void 0),wui_list_item_decorate([(0,n.Cb)({type:Boolean})],ez.prototype,"fullSize",void 0),ez=wui_list_item_decorate([(0,I.M)("wui-list-item")],ez);let eU=class extends r.oi{constructor(){super(...arguments),this.wallet=m.RouterController.state.data?.wallet}render(){if(!this.wallet)throw Error("w3m-downloads-view");return r.dy`
      <wui-flex gap="2" flexDirection="column" .padding=${["3","3","4","3"]}>
        ${this.chromeTemplate()} ${this.iosTemplate()} ${this.androidTemplate()}
        ${this.homepageTemplate()}
      </wui-flex>
    `}chromeTemplate(){return this.wallet?.chrome_store?r.dy`<wui-list-item
      variant="icon"
      icon="chromeStore"
      iconVariant="square"
      @click=${this.onChromeStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">Chrome Extension</wui-text>
    </wui-list-item>`:null}iosTemplate(){return this.wallet?.app_store?r.dy`<wui-list-item
      variant="icon"
      icon="appStore"
      iconVariant="square"
      @click=${this.onAppStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">iOS App</wui-text>
    </wui-list-item>`:null}androidTemplate(){return this.wallet?.play_store?r.dy`<wui-list-item
      variant="icon"
      icon="playStore"
      iconVariant="square"
      @click=${this.onPlayStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">Android App</wui-text>
    </wui-list-item>`:null}homepageTemplate(){return this.wallet?.homepage?r.dy`
      <wui-list-item
        variant="icon"
        icon="browser"
        iconVariant="square-blue"
        @click=${this.onHomePage.bind(this)}
        chevron
      >
        <wui-text variant="md-medium" color="primary">Website</wui-text>
      </wui-list-item>
    `:null}openStore(e){e.href&&this.wallet&&(w.X.sendEvent({type:"track",event:"GET_WALLET",properties:{name:this.wallet.name,walletRank:this.wallet.order,explorerId:this.wallet.id,type:e.type}}),a.j.openHref(e.href,"_blank"))}onChromeStore(){this.wallet?.chrome_store&&this.openStore({href:this.wallet.chrome_store,type:"chrome_store"})}onAppStore(){this.wallet?.app_store&&this.openStore({href:this.wallet.app_store,type:"app_store"})}onPlayStore(){this.wallet?.play_store&&this.openStore({href:this.wallet.play_store,type:"play_store"})}onHomePage(){this.wallet?.homepage&&this.openStore({href:this.wallet.homepage,type:"homepage"})}};eU=function(e,t,i,r){var n,a=arguments.length,l=a<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)l=Reflect.decorate(e,t,i,r);else for(var s=e.length-1;s>=0;s--)(n=e[s])&&(l=(a<3?n(l):a>3?n(t,i,l):n(t,i))||l);return a>3&&l&&Object.defineProperty(t,i,l),l}([(0,d.Mo)("w3m-downloads-view")],eU)}}]);