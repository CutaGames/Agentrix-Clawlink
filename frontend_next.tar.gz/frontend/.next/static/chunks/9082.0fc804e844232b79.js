"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9082],{79082:function(t,e,r){r.r(e),r.d(e,{PhCaretLeft:function(){return c}}),r(87556);var l=r(95910),a=r(43420),i=r(87642),o=r(86709),h=r(24904),p=Object.defineProperty,n=Object.getOwnPropertyDescriptor,s=(t,e,r,l)=>{for(var a,i=l>1?void 0:l?n(e,r):e,o=t.length-1;o>=0;o--)(a=t[o])&&(i=(l?a(e,r,i):a(i))||i);return l&&i&&p(e,r,i),i};let c=class extends a.oi{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return l.dy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",l.YP`<path d="M162.83,205.17a4,4,0,0,1-5.66,5.66l-80-80a4,4,0,0,1,0-5.66l80-80a4,4,0,1,1,5.66,5.66L85.66,128Z"/>`],["light",l.YP`<path d="M164.24,203.76a6,6,0,1,1-8.48,8.48l-80-80a6,6,0,0,1,0-8.48l80-80a6,6,0,0,1,8.48,8.48L88.49,128Z"/>`],["regular",l.YP`<path d="M165.66,202.34a8,8,0,0,1-11.32,11.32l-80-80a8,8,0,0,1,0-11.32l80-80a8,8,0,0,1,11.32,11.32L91.31,128Z"/>`],["bold",l.YP`<path d="M168.49,199.51a12,12,0,0,1-17,17l-80-80a12,12,0,0,1,0-17l80-80a12,12,0,0,1,17,17L97,128Z"/>`],["fill",l.YP`<path d="M168,48V208a8,8,0,0,1-13.66,5.66l-80-80a8,8,0,0,1,0-11.32l80-80A8,8,0,0,1,168,48Z"/>`],["duotone",l.YP`<path d="M160,48V208L80,128Z" opacity="0.2"/><path d="M163.06,40.61a8,8,0,0,0-8.72,1.73l-80,80a8,8,0,0,0,0,11.32l80,80A8,8,0,0,0,168,208V48A8,8,0,0,0,163.06,40.61ZM152,188.69,91.31,128,152,67.31Z"/>`]]),c.styles=h.iv`
    :host {
      display: contents;
    }
  `,s([(0,o.C)({type:String,reflect:!0})],c.prototype,"size",2),s([(0,o.C)({type:String,reflect:!0})],c.prototype,"weight",2),s([(0,o.C)({type:String,reflect:!0})],c.prototype,"color",2),s([(0,o.C)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=s([(0,i.M)("ph-caret-left")],c)}}]);