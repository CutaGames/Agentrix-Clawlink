"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6389],{86389:function(t,e,r){r.r(e),r.d(e,{PhArrowUp:function(){return c}}),r(87556);var a=r(95910),l=r(43420),i=r(87642),s=r(86709),h=r(24904),p=Object.defineProperty,n=Object.getOwnPropertyDescriptor,o=(t,e,r,a)=>{for(var l,i=a>1?void 0:a?n(e,r):e,s=t.length-1;s>=0;s--)(l=t[s])&&(i=(a?l(e,r,i):l(i))||i);return a&&i&&p(e,r,i),i};let c=class extends l.oi{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return a.dy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",a.YP`<path d="M202.83,114.83a4,4,0,0,1-5.66,0L132,49.66V216a4,4,0,0,1-8,0V49.66L58.83,114.83a4,4,0,0,1-5.66-5.66l72-72a4,4,0,0,1,5.66,0l72,72A4,4,0,0,1,202.83,114.83Z"/>`],["light",a.YP`<path d="M204.24,116.24a6,6,0,0,1-8.48,0L134,54.49V216a6,6,0,0,1-12,0V54.49L60.24,116.24a6,6,0,0,1-8.48-8.48l72-72a6,6,0,0,1,8.48,0l72,72A6,6,0,0,1,204.24,116.24Z"/>`],["regular",a.YP`<path d="M205.66,117.66a8,8,0,0,1-11.32,0L136,59.31V216a8,8,0,0,1-16,0V59.31L61.66,117.66a8,8,0,0,1-11.32-11.32l72-72a8,8,0,0,1,11.32,0l72,72A8,8,0,0,1,205.66,117.66Z"/>`],["bold",a.YP`<path d="M208.49,120.49a12,12,0,0,1-17,0L140,69V216a12,12,0,0,1-24,0V69L64.49,120.49a12,12,0,0,1-17-17l72-72a12,12,0,0,1,17,0l72,72A12,12,0,0,1,208.49,120.49Z"/>`],["fill",a.YP`<path d="M207.39,115.06A8,8,0,0,1,200,120H136v96a8,8,0,0,1-16,0V120H56a8,8,0,0,1-5.66-13.66l72-72a8,8,0,0,1,11.32,0l72,72A8,8,0,0,1,207.39,115.06Z"/>`],["duotone",a.YP`<path d="M200,112H56l72-72Z" opacity="0.2"/><path d="M205.66,106.34l-72-72a8,8,0,0,0-11.32,0l-72,72A8,8,0,0,0,56,120h64v96a8,8,0,0,0,16,0V120h64a8,8,0,0,0,5.66-13.66ZM75.31,104,128,51.31,180.69,104Z"/>`]]),c.styles=h.iv`
    :host {
      display: contents;
    }
  `,o([(0,s.C)({type:String,reflect:!0})],c.prototype,"size",2),o([(0,s.C)({type:String,reflect:!0})],c.prototype,"weight",2),o([(0,s.C)({type:String,reflect:!0})],c.prototype,"color",2),o([(0,s.C)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=o([(0,i.M)("ph-arrow-up")],c)}}]);