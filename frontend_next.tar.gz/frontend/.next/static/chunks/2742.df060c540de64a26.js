"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2742],{72742:function(t,e,r){r.r(e),r.d(e,{PhArrowUpRight:function(){return c}}),r(87556);var i=r(95910),o=r(43420),a=r(87642),h=r(86709),p=r(24904),l=Object.defineProperty,n=Object.getOwnPropertyDescriptor,s=(t,e,r,i)=>{for(var o,a=i>1?void 0:i?n(e,r):e,h=t.length-1;h>=0;h--)(o=t[h])&&(a=(i?o(e,r,a):o(a))||a);return i&&a&&l(e,r,a),a};let c=class extends o.oi{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return i.dy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",i.YP`<path d="M196,64V168a4,4,0,0,1-8,0V73.66L66.83,194.83a4,4,0,0,1-5.66-5.66L182.34,68H88a4,4,0,0,1,0-8H192A4,4,0,0,1,196,64Z"/>`],["light",i.YP`<path d="M198,64V168a6,6,0,0,1-12,0V78.48L68.24,196.24a6,6,0,0,1-8.48-8.48L177.52,70H88a6,6,0,0,1,0-12H192A6,6,0,0,1,198,64Z"/>`],["regular",i.YP`<path d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"/>`],["bold",i.YP`<path d="M204,64V168a12,12,0,0,1-24,0V93L72.49,200.49a12,12,0,0,1-17-17L163,76H88a12,12,0,0,1,0-24H192A12,12,0,0,1,204,64Z"/>`],["fill",i.YP`<path d="M200,64V168a8,8,0,0,1-13.66,5.66L140,127.31,69.66,197.66a8,8,0,0,1-11.32-11.32L128.69,116,82.34,69.66A8,8,0,0,1,88,56H192A8,8,0,0,1,200,64Z"/>`],["duotone",i.YP`<path d="M192,64V168L88,64Z" opacity="0.2"/><path d="M192,56H88a8,8,0,0,0-5.66,13.66L128.69,116,58.34,186.34a8,8,0,0,0,11.32,11.32L140,127.31l46.34,46.35A8,8,0,0,0,200,168V64A8,8,0,0,0,192,56Zm-8,92.69-38.34-38.34h0L107.31,72H184Z"/>`]]),c.styles=p.iv`
    :host {
      display: contents;
    }
  `,s([(0,h.C)({type:String,reflect:!0})],c.prototype,"size",2),s([(0,h.C)({type:String,reflect:!0})],c.prototype,"weight",2),s([(0,h.C)({type:String,reflect:!0})],c.prototype,"color",2),s([(0,h.C)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=s([(0,a.M)("ph-arrow-up-right")],c)}}]);