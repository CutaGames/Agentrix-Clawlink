"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9894],{29894:function(t,e,r){r.r(e),r.d(e,{PhBrowser:function(){return H}}),r(87556);var o=r(95910),a=r(43420),i=r(87642),h=r(86709),p=r(24904),V=Object.defineProperty,l=Object.getOwnPropertyDescriptor,s=(t,e,r,o)=>{for(var a,i=o>1?void 0:o?l(e,r):e,h=t.length-1;h>=0;h--)(a=t[h])&&(i=(o?a(e,r,i):a(i))||i);return o&&i&&V(e,r,i),i};let H=class extends a.oi{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return o.dy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${H.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};H.weightsMap=new Map([["thin",o.YP`<path d="M216,44H40A12,12,0,0,0,28,56V200a12,12,0,0,0,12,12H216a12,12,0,0,0,12-12V56A12,12,0,0,0,216,44ZM40,52H216a4,4,0,0,1,4,4V92H36V56A4,4,0,0,1,40,52ZM216,204H40a4,4,0,0,1-4-4V100H220V200A4,4,0,0,1,216,204Z"/>`],["light",o.YP`<path d="M216,42H40A14,14,0,0,0,26,56V200a14,14,0,0,0,14,14H216a14,14,0,0,0,14-14V56A14,14,0,0,0,216,42ZM40,54H216a2,2,0,0,1,2,2V90H38V56A2,2,0,0,1,40,54ZM216,202H40a2,2,0,0,1-2-2V102H218v98A2,2,0,0,1,216,202Z"/>`],["regular",o.YP`<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,16V88H40V56Zm0,144H40V104H216v96Z"/>`],["bold",o.YP`<path d="M216,36H40A20,20,0,0,0,20,56V200a20,20,0,0,0,20,20H216a20,20,0,0,0,20-20V56A20,20,0,0,0,216,36Zm-4,24V84H44V60ZM44,196V108H212v88Z"/>`],["fill",o.YP`<path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,16V88H40V56Z"/>`],["duotone",o.YP`<path d="M224,56V96H32V56a8,8,0,0,1,8-8H216A8,8,0,0,1,224,56Z" opacity="0.2"/><path d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,16V88H40V56Zm0,144H40V104H216v96Z"/>`]]),H.styles=p.iv`
    :host {
      display: contents;
    }
  `,s([(0,h.C)({type:String,reflect:!0})],H.prototype,"size",2),s([(0,h.C)({type:String,reflect:!0})],H.prototype,"weight",2),s([(0,h.C)({type:String,reflect:!0})],H.prototype,"color",2),s([(0,h.C)({type:Boolean,reflect:!0})],H.prototype,"mirrored",2),H=s([(0,i.M)("ph-browser")],H)}}]);