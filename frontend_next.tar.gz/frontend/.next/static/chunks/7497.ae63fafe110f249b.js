"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7497],{47497:function(t,e,r){r.r(e),r.d(e,{PhCaretUp:function(){return c}}),r(87556);var l=r(95910),a=r(43420),i=r(87642),o=r(86709),p=r(24904),h=Object.defineProperty,n=Object.getOwnPropertyDescriptor,s=(t,e,r,l)=>{for(var a,i=l>1?void 0:l?n(e,r):e,o=t.length-1;o>=0;o--)(a=t[o])&&(i=(l?a(e,r,i):a(i))||i);return l&&i&&h(e,r,i),i};let c=class extends a.oi{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return l.dy`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",l.YP`<path d="M210.83,162.83a4,4,0,0,1-5.66,0L128,85.66,50.83,162.83a4,4,0,0,1-5.66-5.66l80-80a4,4,0,0,1,5.66,0l80,80A4,4,0,0,1,210.83,162.83Z"/>`],["light",l.YP`<path d="M212.24,164.24a6,6,0,0,1-8.48,0L128,88.49,52.24,164.24a6,6,0,0,1-8.48-8.48l80-80a6,6,0,0,1,8.48,0l80,80A6,6,0,0,1,212.24,164.24Z"/>`],["regular",l.YP`<path d="M213.66,165.66a8,8,0,0,1-11.32,0L128,91.31,53.66,165.66a8,8,0,0,1-11.32-11.32l80-80a8,8,0,0,1,11.32,0l80,80A8,8,0,0,1,213.66,165.66Z"/>`],["bold",l.YP`<path d="M216.49,168.49a12,12,0,0,1-17,0L128,97,56.49,168.49a12,12,0,0,1-17-17l80-80a12,12,0,0,1,17,0l80,80A12,12,0,0,1,216.49,168.49Z"/>`],["fill",l.YP`<path d="M215.39,163.06A8,8,0,0,1,208,168H48a8,8,0,0,1-5.66-13.66l80-80a8,8,0,0,1,11.32,0l80,80A8,8,0,0,1,215.39,163.06Z"/>`],["duotone",l.YP`<path d="M208,160H48l80-80Z" opacity="0.2"/><path d="M213.66,154.34l-80-80a8,8,0,0,0-11.32,0l-80,80A8,8,0,0,0,48,168H208a8,8,0,0,0,5.66-13.66ZM67.31,152,128,91.31,188.69,152Z"/>`]]),c.styles=p.iv`
    :host {
      display: contents;
    }
  `,s([(0,o.C)({type:String,reflect:!0})],c.prototype,"size",2),s([(0,o.C)({type:String,reflect:!0})],c.prototype,"weight",2),s([(0,o.C)({type:String,reflect:!0})],c.prototype,"color",2),s([(0,o.C)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=s([(0,i.M)("ph-caret-up")],c)}}]);