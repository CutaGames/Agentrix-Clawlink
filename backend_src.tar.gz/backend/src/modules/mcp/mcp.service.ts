import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import { ListToolsRequestSchema, CallToolRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { SkillService } from '../skill/skill.service';
import { MarketplaceService } from '../marketplace/marketplace.service';
import { PaymentService } from '../payment/payment.service';
import { WalletService } from '../wallet/wallet.service';
import { AgentService } from '../agent/agent.service';
import { AirdropService } from '../airdrop/airdrop.service';
import { AutoEarnService } from '../auto-earn/auto-earn.service';

@Injectable()
export class McpService implements OnModuleInit {
  private readonly logger = new Logger(McpService.name);
  private server: Server;

  constructor(
    private readonly skillService: SkillService,
    private readonly marketplaceService: MarketplaceService,
    private readonly paymentService: PaymentService,
    private readonly walletService: WalletService,
    private readonly agentService: AgentService,
    private readonly airdropService: AirdropService,
    private readonly autoEarnService: AutoEarnService,
  ) {
    this.server = new Server(
      {
        name: 'agentrix-mcp-server',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
          // 启用 authentication 能力，允许 ChatGPT 等平台进行 OAuth 认证
          authentication: {
            type: 'oauth2',
            flows: ['authorization_code'],
          },
        },
      },
    );
  }

  async onModuleInit() {
    this.setupTools();
    this.logger.log('MCP Server initialized');
  }

  private setupTools() {
    // 1. 处理 Tool 列表请求
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      const tools = await this.getAllTools();
      return { tools };
    });

    // 2. 处理 Tool 调用
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;
      return this.handleCallTool(name, args);
    });
  }

  /**
   * 获取所有可用的 Tools 列表
   */
  private async getAllTools() {
    const skills = await this.skillService.findAll();
    const dynamicTools = skills.map(skill => ({
      name: skill.name.replace(/[^a-zA-Z0-9_]/g, '_'),
      description: skill.description,
      inputSchema: {
        type: 'object',
        properties: skill.inputSchema.properties,
        required: skill.inputSchema.required || [],
      },
    }));

    const staticTools = [
      {
        name: 'search_products',
        description: 'Search products in Agentrix Marketplace',
        inputSchema: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Search query' },
            assetType: { type: 'string', enum: ['physical', 'service', 'nft', 'ft', 'game_asset', 'rwa'] },
            limit: { type: 'number', default: 10 }
          },
          required: ['query']
        }
      },
      {
        name: 'create_pay_intent',
        description: 'Create a payment intent for a product',
        inputSchema: {
          type: 'object',
          properties: {
            productId: { type: 'string', description: 'Product ID' },
            quantity: { type: 'number', default: 1 }
          },
          required: ['productId']
        }
      },
      {
        name: 'get_balance',
        description: 'Get user wallet balance',
        inputSchema: {
          type: 'object',
          properties: {
            userId: { type: 'string', description: 'User ID' },
            currency: { type: 'string', description: 'Currency (e.g. BNB, USDT)' }
          },
          required: ['userId']
        }
      },
      {
        name: 'agent_authorize',
        description: 'Create a payment authorization for an AI Agent',
        inputSchema: {
          type: 'object',
          properties: {
            agentId: { type: 'string', description: 'Agent ID' },
            userId: { type: 'string', description: 'User ID' },
            singleLimit: { type: 'number', description: 'Single transaction limit' },
            dailyLimit: { type: 'number', description: 'Daily transaction limit' }
          },
          required: ['agentId', 'userId', 'singleLimit', 'dailyLimit']
        }
      },
      {
        name: 'airdrop_discover',
        description: 'Discover available crypto airdrops',
        inputSchema: {
          type: 'object',
          properties: {
            userId: { type: 'string', description: 'User ID' }
          },
          required: ['userId']
        }
      },
      {
        name: 'autoearn_stats',
        description: 'Get auto-earn statistics',
        inputSchema: {
          type: 'object',
          properties: {
            userId: { type: 'string', description: 'User ID' }
          },
          required: ['userId']
        }
      }
    ];

    return [...staticTools, ...dynamicTools];
  }

  /**
   * 统一处理 Tool 调用逻辑
   */
  private async handleCallTool(name: string, args: any) {
    this.logger.log(`Tool Call: ${name} with args: ${JSON.stringify(args)}`);

    try {
      if (name === 'search_products') {
        const results = await this.marketplaceService.getAssets({
          search: (args as any).query,
          type: (args as any).assetType,
          pageSize: (args as any).limit
        });
        return {
          content: [{ type: 'text', text: JSON.stringify(results) }],
        };
      }

      if (name === 'create_pay_intent') {
        const intent = await this.paymentService.createPaymentIntent(undefined, args as any);
        return {
          content: [{ type: 'text', text: JSON.stringify(intent) }],
        };
      }

      if (name === 'get_balance') {
        const balance = await this.walletService.getBalance(args.userId, args.currency);
        return {
          content: [{ type: 'text', text: JSON.stringify(balance) }],
        };
      }

      if (name === 'agent_authorize') {
        const auth = await this.agentService.authorizeAgent(args);
        return {
          content: [{ type: 'text', text: JSON.stringify(auth) }],
        };
      }

      if (name === 'airdrop_discover') {
        const airdrops = await this.airdropService.discover(args.userId);
        return {
          content: [{ type: 'text', text: JSON.stringify(airdrops) }],
        };
      }

      if (name === 'autoearn_stats') {
        const stats = await this.autoEarnService.getStats(args.userId);
        return {
          content: [{ type: 'text', text: JSON.stringify(stats) }],
        };
      }

      // 尝试动态 Skills
      const skills = await this.skillService.findAll();
      const skill = skills.find(s => s.name.replace(/[^a-zA-Z0-9_]/g, '_') === name);
      if (skill) {
        const result = await this.skillService.execute(skill.id, args);
        return {
          content: [{ type: 'text', text: JSON.stringify(result) }],
        };
      }

      return {
        isError: true,
        content: [{ type: 'text', text: `Unknown tool: ${name}` }],
      };
    } catch (error: any) {
      this.logger.error(`Tool execution failed: ${error.message}`);
      return {
        isError: true,
        content: [{ type: 'text', text: `Error: ${error.message}` }],
      };
    }
  }

  /**
   * 连接 Transport
   */
  async connectTransport(transport: any) {
    await this.server.connect(transport);
  }

  /**
   * REST 桥接：执行 Tool 调用
   */
  async callTool(name: string, args: any) {
    return this.handleCallTool(name, args);
  }

  /**
   * 获取 OpenAPI Schema (用于 Gemini/Grok)
   */
  async getOpenApiSchema() {
    const tools = await this.getAllTools();

    const paths = {};
    for (const tool of tools) {
      paths[`/api/mcp/tool/${tool.name}`] = {
        post: {
          operationId: tool.name,
          summary: tool.description,
          requestBody: {
            content: {
              'application/json': {
                schema: tool.inputSchema,
              },
            },
          },
          responses: {
            '200': {
              description: 'Successful response',
              content: {
                'application/json': {
                  schema: { type: 'object' },
                },
              },
            },
          },
        },
      };
    }

    return {
      openapi: '3.1.0',
      info: {
        title: 'Agentrix MCP Tools API',
        version: '1.0.0',
        description: 'REST API bridge for Agentrix MCP Tools',
      },
      paths,
    };
  }
}

import { AutoEarnService } from '../auto-earn/auto-earn.service';
import { AirdropService } from '../auto-earn/airdrop.service';
import { MPCWalletService } from '../mpc-wallet/mpc-wallet.service';

@Injectable()
export class McpService implements OnModuleInit {
  private readonly logger = new Logger(McpService.name);
  private server: Server;
  private sseTransport: SSEServerTransport;

  constructor(
    private skillService: SkillService,
    private skillExecutor: SkillExecutorService,
    private marketplaceService: MarketplaceService,
    private paymentService: PaymentService,
    private agentAuthService: AgentAuthorizationService,
    private autoEarnService: AutoEarnService,
    private airdropService: AirdropService,
    private mpcWalletService: MPCWalletService,
  ) {
    this.server = new Server(
      {
        name: 'agentrix-mcp-server',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
          resources: {},
          // 声明支持 OAuth 认证
          // OpenAI MCP 规范要求在 capabilities 中声明 authentication
          authentication: {
            type: 'oauth2',
            flows: ['authorization_code'],
          },
        } as any,
      },
    );
  }

  async onModuleInit() {
    this.setupTools();
    this.logger.log('MCP Server initialized');
  }

  async connectTransport(transport: any) {
    await this.server.connect(transport);
  }

  private setupTools() {
    // 1. 处理 Tool 列表请求
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      const tools = await this.getAllTools();
      return { tools };
    });

    // 2. 处理 Tool 调用
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;
      this.logger.log(`MCP Tool Call: ${name} with args: ${JSON.stringify(args)}`);

      try {
        if (name === 'search_products') {
          const results = await this.marketplaceService.getAssets({
            search: (args as any).query,
            type: (args as any).assetType,
            pageSize: (args as any).limit
          });
          return {
            content: [{ type: 'text', text: JSON.stringify(results) }],
          };
        }

        if (name === 'create_pay_intent') {
          const intent = await this.paymentService.createPaymentIntent(undefined, args as any);
          return {
            content: [{ type: 'text', text: JSON.stringify(intent) }],
          };
        }

        if (name === 'agent_authorize') {
          const auth = await this.agentAuthService.createAgentAuthorization(args as any);
          return {
            content: [{ type: 'text', text: JSON.stringify(auth) }],
          };
        }

        if (name === 'airdrop_discover') {
          const airdrops = await this.airdropService.discoverAirdrops((args as any).userId);
          return {
            content: [{ type: 'text', text: JSON.stringify(airdrops) }],
          };
        }

        if (name === 'autoearn_stats') {
          const stats = await this.autoEarnService.getStats((args as any).userId);
          return {
            content: [{ type: 'text', text: JSON.stringify(stats) }],
          };
        }

        // 尝试匹配动态 Skill
        const skills = await this.skillService.findAll();
        const skill = skills.find(s => s.name.replace(/[^a-zA-Z0-9_]/g, '_') === name);
        
        if (skill) {
          const result = await this.skillExecutor.execute(skill.id, args);
          return {
            content: [{ type: 'text', text: JSON.stringify(result) }],
          };
        }

        throw new Error(`Tool not found: ${name}`);
      } catch (error) {
        this.logger.error(`MCP Tool Error: ${error.message}`);
        return {
          isError: true,
          content: [{ type: 'text', text: error.message }],
        };
      }
    });
  }

  /**
   * 获取 SSE 传输层处理器
   */
  getSseHandler() {
    return this.sseTransport;
  }

  /**
   * 处理 SSE 连接
   */
  async handleSseConnection(transport: SSEServerTransport) {
    // 已经在 onModuleInit 中连接过了，这里不需要重复连接
    // SSEServerTransport 会自动处理新的 SSE 请求
  }

  /**
   * 获取所有可用的 Tools 列表
   */
  private async getAllTools() {
    const skills = await this.skillService.findAll();
    const dynamicTools = skills.map(skill => ({
      name: skill.name.replace(/[^a-zA-Z0-9_]/g, '_'),
      description: skill.description,
      inputSchema: {
        type: 'object',
        properties: skill.inputSchema.properties,
        required: skill.inputSchema.required || [],
      },
    }));

    const staticTools = [
      {
        name: 'search_products',
        description: 'Search products in Agentrix Marketplace',
        inputSchema: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Search query' },
            assetType: { type: 'string', enum: ['physical', 'service', 'nft', 'ft', 'game_asset', 'rwa'] },
            limit: { type: 'number', default: 10 }
          },
          required: ['query']
        }
      },
      {
        name: 'create_pay_intent',
        description: 'Create a payment intent for a product',
        inputSchema: {
          type: 'object',
          properties: {
            productId: { type: 'string', description: 'Product ID' },
            quantity: { type: 'number', default: 1 }
          },
          required: ['productId']
        }
      },
      {
        name: 'get_balance',
        description: 'Get user wallet balance',
        inputSchema: {
          type: 'object',
          properties: {
            userId: { type: 'string', description: 'User ID' },
            currency: { type: 'string', description: 'Currency (e.g. BNB, USDT)' }
          },
          required: ['userId']
        }
      },
      {
        name: 'agent_authorize',
        description: 'Create a payment authorization for an AI Agent',
        inputSchema: {
          type: 'object',
          properties: {
            agentId: { type: 'string', description: 'Agent ID' },
            userId: { type: 'string', description: 'User ID' },
            singleLimit: { type: 'number', description: 'Single transaction limit' },
            dailyLimit: { type: 'number', description: 'Daily transaction limit' }
          },
          required: ['agentId', 'userId', 'singleLimit', 'dailyLimit']
        }
      },
      {
        name: 'airdrop_discover',
        description: 'Discover available crypto airdrops',
        inputSchema: {
          type: 'object',
          properties: {
            userId: { type: 'string', description: 'User ID' }
          },
          required: ['userId']
        }
      },
      {
        name: 'autoearn_stats',
        description: 'Get auto-earn statistics',
        inputSchema: {
          type: 'object',
          properties: {
            userId: { type: 'string', description: 'User ID' }
          },
          required: ['userId']
        }
      }
    ];

    return [...staticTools, ...dynamicTools];
  }

  /**
   * 获取 OpenAPI Schema (用于 Gemini/Grok)
   */
  async getOpenApiSchema() {
    const tools = await this.getAllTools();

    const paths = {};
    for (const tool of tools) {
      paths[`/api/mcp/tool/${tool.name}`] = {
        post: {
          operationId: tool.name,
          summary: tool.description,
          requestBody: {
            content: {
              'application/json': {
                schema: tool.inputSchema,
              },
            },
          },
          responses: {
            '200': {
              description: 'Successful response',
              content: {
                'application/json': {
                  schema: { type: 'object' },
                },
              },
            },
          },
        },
      };
    }

    return {
      openapi: '3.1.0',
      info: {
        title: 'Agentrix MCP Tools API',
        version: '1.0.0',
        description: 'REST API bridge for Agentrix MCP Tools',
      },
      paths,
    };
  }
}
