ALTER TABLE commission_settlements_v4 ADD COLUMN IF NOT EXISTS merchant_id VARCHAR;
