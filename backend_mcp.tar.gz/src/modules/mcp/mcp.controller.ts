import { Controller, Get, Post, Body, Req, Res, Logger, UseGuards, Param } from '@nestjs/common';
import { Request, Response } from 'express';
import { McpService } from './mcp.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('api/mcp')
export class McpController {
  private readonly logger = new Logger(McpController.name);

  constructor(private readonly mcpService: McpService) {}

  /**
   * MCP SSE 端点
   * 用于 ChatGPT 等云端 AI 建立长连接
   */
  @Get('sse')
  async sse(@Req() req: Request, @Res() res: Response) {
    this.logger.log('New MCP SSE connection request');
    
    const transport = this.mcpService.getSseHandler();
    
    // SSEServerTransport.handleRequest 会处理 SSE 握手并保持连接
    await transport.handleRequest(req, res);
    
    this.logger.log('MCP SSE connection established');
  }

  /**
   * 处理来自 AI 的消息
   */
  @Post('sse')
  async messages(@Req() req: Request, @Res() res: Response) {
    // 注意：OpenAI 可能会向同一个 URL 发送 POST 消息
    const transport = this.mcpService.getSseHandler();
    await (transport as any).handlePostMessage(req, res);
  }

  /**
   * 获取 OpenAPI Schema
   * 用于 Gemini Extensions 或 Grok Tools
   */
  @Get('openapi.json')
  async getOpenApi() {
    return this.mcpService.getOpenApiSchema();
  }

  /**
   * REST 桥接：执行 Tool 调用
   * 用于不支持 MCP 的平台通过 REST 调用
   */
  @Post('tool/:name')
  async callTool(@Param('name') name: string, @Body() args: any) {
    // 这里可以复用 McpService 中的逻辑
    // 简单起见，直接调用 service 的内部方法或重新实现
    return { success: true, data: 'Tool execution via REST bridge is coming soon' };
  }
}
