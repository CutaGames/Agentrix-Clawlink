INSERT INTO migrations (timestamp, name) VALUES (1771100000000, 'AddAppleIdAndTwitterIdToUsers1771100000000');
